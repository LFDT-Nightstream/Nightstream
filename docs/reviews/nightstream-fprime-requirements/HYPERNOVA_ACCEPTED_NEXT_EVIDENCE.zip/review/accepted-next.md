# Accepted-next source review

Reviewed `/tmp/HyperNovaAcceptedNext.lean`, SHA-256
`ab4710e3e2205e5e1bd5c02d69bdaee8a121927a7b97d81d72bbffd64dc5dfec`,
against `/tmp/SelectedAssignmentCompleteness.lean`, SHA-256
`5c618420c77427cf39617fda2c23abf3843b2ffe0b59b03c25e134977dfbf4ad`.
No builds or source changes were made. The three helper bodies remain the
previously checked prefix (SHA `e54d4891cd6958d73550894edc98427f75007039c88810fccc12fc37219779c9`).

No statement or witness-custody mismatch was found.

- Recursive branch, lines 132–208: `HyperNovaCompleteness.recursive_nifs_of_sampler_success`
  derives source membership from the accepted payload's actual running/fresh
  openings. Its C messages and full C output are fixed before the actual R
  sampler condition. The returned proof, verifier result and all 16 child
  assignments are the same values placed in the next envelope. StepData
  supplies framing/public-link/step facts; the selected assignment theorem
  supplies the actual fresh carrier. The new fresh commitment is computed
  from this carrier, whose fresh opening is proved by the checked helper.
- Base branch, lines 215–320: bottom acceptance supplies iteration zero,
  `zi = z0` and both state widths. The exact sampler input is defaultRunning,
  baseFresh of the displayed prior, and zeroProof. canonicalInput changes
  only dummy advice and preserves the actual state/advice fields. Its NIFS
  dummy result is used for physical-row construction. The next envelope
  instead contains defaultRunning and PilotZeroRunning.defaultRunning_holds
  on the zero assignments. No opening of baseFresh or of the dummy result's
  children is used or assumed.
- The four-word advice condition appears in both public statements. The
  recursive statement requires the next counter below the field modulus.
  At base, this bound follows from iteration zero. Both statements remain
  conditional on their actual bounded sampler returning some rho; neither
  claims that the sampler must return.
- The complete theorem's argument order and all five returned facts match
  both calls (lines 194 and 307). In the base call, recursiveResult is proved
  by contradiction from iteration zero. In the recursive call, resultEq is
  supplied by StepData. No row-validity, environment-agreement, full-history,
  completeness callback or child-validity hypothesis has been added to either
  public statement.

## Required integration and exact conversion boundaries

At placement, replace the now-transitive ApplicationWitnessCompleteness import
with `NightstreamFPrime.Export.Stage1.SelectedAssignmentCompleteness`. The
current draft intentionally lacks that import while the owner is pending.
Keep the already checked three helpers unchanged.

The following equalities are true from current definitions, but the two full
branch bodies have not yet been checked. They are the narrow transport points
if Lean reports a conversion error:

1. `before.witness = advice` in each branch: only HyperNovaStepData.input or
   canonicalInput/seeded record fields are involved.
2. In the base branch,
   `priorHashPreimage (setup relation productionAjtaiKey context.toList) before = prior`.
   Both have the same context, iteration, states, default running vector and
   pc one. This equality discharges freshPublic and beforeVerified. If the
   latter's `simpa only` fails, name this typed record equality first and
   transport baseFresh/verify with congrArg. Do not unfold stateHash or the
   production key to compare their values.
3. `context.toList = PerApplicationCanonicalPackage.verifierContextDigest fits productionSetup`
   is the existing digest4 projection by definition. It aligns seededStep,
   StepData and both next hashes; it does not require an identity pin or hash
   computation.
4. `PerApplicationCanonicalPackage.commitmentKey productionSetup = productionAjtaiKey`
   is the existing Setup/ajtaiKey alias. At the terminal helper calls, use only
   these small wrappers if Lean needs explicit transport; no key matrix is
   evaluated. The fresh-opening helper's complete-carrier extension transport
   is already checked.

The source supports conditional deterministic accepted-successor construction
once SelectedAssignmentCompleteness and the full branch bodies pass. It does
not establish native runtime, sampler-totality, extraction work or a numerical
security bound.
