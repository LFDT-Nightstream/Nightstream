# CO25 additive transcript review

Independent reviewer: Worker 3 (`/root/conformance_review`). Date: 2026-09-10.
Scope: the 2026-03-27 Chiesa–Orrù revision and the current additive transcript.
No model was adopted. No build or protocol execution was performed.

Paper: [/tmp/nightstream-chiesa-orru-2025-536.txt](/tmp/nightstream-chiesa-orru-2025-536.txt),
SHA256 `66d1cdd23bf6f18f5f93b08aabe6d0339ef79c0f3b58cfddc980966bd57903e7`.
Source hashes: `Spec/Poseidon2.lean` =
`552706034df8a5f6b59ac6740426a5905b254e195f1205c6762cef1b73a1bbbc`;
`Lifecycle/Transcript.lean` =
`c202204c451ca96c03e6c27e0320970a6fe4d867e99d486284dcd887f99c6d32`.

## Finding

The triangular translation is a plausible deterministic bridge. It does not
instantiate the codec in Definition 4.1. That definition fixes
`cdc(lambda,n) = (ellP,ellV,phi,psi)`, with
`phi_i : M_P,i -> Sigma^(ellP(i))`. There is no prefix or permutation argument.
Construction 4.3 evaluates `phi_i(alpha_i)` before absorbing the message.
See [Definition 4.1](/tmp/nightstream-chiesa-orru-2025-536.txt:1561) and
[Construction 4.3](/tmp/nightstream-chiesa-orru-2025-536.txt:1578).

The proof uses this restriction. D2SQuery tests membership in `Im(phi_i)`;
D2SAlgo and D2STrace invert each message separately. Claim 5.23 then identifies
two random-oracle laws by fixed injective relabeling. A permutation-dependent
translation needs a new causal, joint cache argument at this point. Fixing a
permutation to prove a bijection does not prove independence when that same
permutation is sampled in the security experiment. See
[D2SQuery/D2SAlgo](/tmp/nightstream-chiesa-orru-2025-536.txt:1970),
[D2STrace](/tmp/nightstream-chiesa-orru-2025-536.txt:2196), and
[Claim 5.23](/tmp/nightstream-chiesa-orru-2025-536.txt:3085).

## Exact deterministic candidate

Write a width-eight state as `S=(S_R,S_C)`, with four lanes in each part.
For a rate block `b` padded to four lanes, set

```
E_S(b) = S_R + b
A_p(S,b) = p(S_R+b,S_C)
OverwriteThenPermute_p(S,E_S(b)) = A_p(S,b)
D_S(e) = e-S_R
```

For fixed `p` and initial state, these block translations give a triangular
bijection on fixed-length block sequences: reconstruct each parent state
before decoding the next block. For typed messages, the inverse must also
check the exact framing, labels and padding. The relevant source is
[Poseidon2.absorbBlock](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Poseidon2.lean:106).

The call schedule also needs a bridge. Nightstream flushes every partial
absorb call immediately. Paper Construction 3.3 retains absorb and squeeze
cursors and delays a permutation until the next symbol requires it. Its
empty Absorb also resets the squeeze cursor. Thus concatenating unpadded
typed calls is not the current computation. Each current chunk must retain
its four-lane boundary; padding translates to the old rate value in unused
lanes, not to zero overwrite words. See
[current absorb/squeeze](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/Transcript.lean:26) and
[Construction 3.3](/tmp/nightstream-chiesa-orru-2025-536.txt:1044).

A concrete cursor lemma can cover an absorb run followed by a squeeze run.
For one block, start the paper at `(S,0,4)`, absorb `E_S(b)`, and put
`A=p(S_R+b,S_C)`. Paper Squeeze of `4*(h+1)` symbols returns

```
A_R || p(A)_R || ... || p^h(A)_R
```

and state `(p^h(A),0,4)`. Retaining symbol `4*j`, for `j<h`, gives exactly
`h` current `squeezeF` outputs and the same final full state. For `squeezeK`,
use comparison length 12 and positions 0 and 4. For eight R digest steps,
use comparison length 36, retain the first 32 symbols, and discard the final
four symbols. These lengths are derived from the eager final permutation;
they are not proposed protocol changes. Consecutive current absorbs can be
grouped into one padded encode run before this squeeze. The complete event
map, including empty/final messages, still needs proof. See
[squeezeK](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/Transcript.lean:48) and
[R digestBlock](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/Transcript.lean:150).

## Unproved lemma interfaces

1. **Block and message inverse:** for each fixed public schedule and prior
   state, prove `decodePrefix(p,encodePrefix(p,messages)) = messages`, the
   reverse identity on the accepted image, and exact parsing rejection.
   Preserve call boundaries, field lengths and all message fields.
2. **Cursor and state refinement:** under equal initial states, prove that
   the translated paper execution has the same retained C/R outputs and
   full successor states as the actual calls. State the pending-permutation
   relation at absorb-only boundaries. Repeated replay must preserve both
   values and states. The comparison lengths must be derived from this map.
3. **Initialization coupling:** couple the actual zero-state, domain-tag and
   digest-only statement prefix to the paper initialization, with one shared
   permutation and all shared hash queries. The paper starts at
   `((0^4,h(x)),0,4)`. Current code absorbs the 43-word domain, framed prior
   digest, fresh commitment and fresh public input. The prior digest binds
   the selected key and running statement through its existing checked
   owner; it is not authority merely because it is self-consistent. Remark
   2.1 discusses instance hashing with the same permutation, but does not
   prove this additive prefix or supply a state-dependent message codec.
   See [Remark 2.1](/tmp/nightstream-chiesa-orru-2025-536.txt:503),
   [publicInputBlocks](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/ProductionKey.lean:109),
   and [initialTranscriptState](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/ProductionKey.lean:207).
4. **Adaptive prefix/cache coupling:** define a joint map of unencoded
   prefixes, encoded prefixes, raw squeeze values and full sponge states.
   Prove unique cached encodings, causal decoding before the current fresh
   challenge, consistent repeated queries, and trace conversion for arbitrary
   forward/inverse query order. Decoded C coins alone do not determine the
   state: unused rate lanes and capacities matter. Extend the image tests,
   Claim 5.23 and verifier-acceptance comparison. The coupling must cover
   invalid paths, capacity ambiguity, hash collisions and the selected
   abort events; a pointwise bijection is insufficient.
5. **Joint decoder/preimage law:** retain the raw output and successor
   state together with each decoded coin. The added discarded four lanes
   multiply each decoder fiber by `q^4`; they do not remove the R sampler's
   bias or abort. The C projection from 12 uniform fields has uniform K
   output. The R projection still needs the existing abort-aware law and
   cached conditional-preimage sampler. Preserve the known Claim 5.22 gap:
   uniform fiber resampling after a uniform decoded value is uniform raw
   input only for balanced fibers. See the
   [existing model note](/home/nicoarq/develop/Nightstream-nifs-proof-links/docs/reviews/nightstream-fprime-requirements/NIFS_FIAT_SHAMIR_MODEL_DECISION.md:373).
6. **Query and work refinement:** derive bounds for actual encode/decode,
   prefix reconstruction, permutation simulation, raw preimage sampling,
   trace/cache work and rewinds. An eager stateful encoder may query `p`
   while constructing later blocks and repeat those queries during paper
   absorption. Those calls require a cache or explicit charges. Recompute
   `L_P,L_V,L` and symbolic query bounds before using Lemma 5.1 or Theorem
   6.2. No concrete query budget or retry rule is selected here.

## Security scope

Theorem 6.2 requires the specified DS oracle experiment, the specified
DSFS construction, a valid codec, and state-restoration knowledge of the
underlying public-coin IP. The new coupling above is missing; the existing
interactive extraction law does not by itself provide state-restoration
knowledge. The witness-bearing NIFS reduction and its exact final children
also need their existing game/acceptance link. A theorem for the ideal
permutation would still require a separate concrete Poseidon2 transfer.

The paper leaves superposition-query security open in
[Section 1.3](/tmp/nightstream-chiesa-orru-2025-536.txt:303).
The local SuperNeo paper also explicitly uses classical adversaries and
rewinding. No QROM or post-quantum extraction conclusion follows. This note
establishes neither a security transfer nor an impossibility result.
