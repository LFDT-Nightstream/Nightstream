# Selected commitment criterion stopped

2026-09-10. Complete historical draft restored and repaired under the unchanged full value/work contract.

Round1 used Lean-captured stderr markers; it could not show current declaration progress. Root stopped it and retained the complete source/log.
Round2 used direct /dev/stderr and environment-check barriers. Every declaration through check completed; the next check_value declaration did not. Root stopped it and retained the diagnostic source/log.
Round3 removed all diagnostics, proved row acceptance separately, and used a symbolic Bool conversion before the selected equality. It again remained in prolonged elaboration/kernel checking without a terminal theorem result. Root stopped it after approximately14minutes with about7.3GiB RSS; the root process returned exit1 after the Lean child received SIGTERM. The snapshot and stopJSON contain exact measured data. This was a stopped check, not a theorem error or a passed validation. No new timeout/memory acceptance gate was introduced.

The full criterion is stopped under the project's three-round rule. The complete292-line repair is preserved as drafts/NIFS_STORED_COMMITMENT_CHECK_RESUMED.lean.txt; the original273-line historical draft remains unchanged. There is no active import or audit and the selected consumer still requires its commitment and matrix premises. No fourth or narrower commitment check may run in this continuation. The source-only independent review is evidence for intended scope, not kernel validation.
