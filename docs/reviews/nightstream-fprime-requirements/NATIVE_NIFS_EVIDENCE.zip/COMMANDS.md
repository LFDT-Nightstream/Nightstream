# Recorded stage recipe

Run native commands sequentially from the repository root. Output directories
must be fresh. The paths below identify this evidence run; choose fresh paths
for a new run. No expected Lean result is passed to a producer stage.
The six active indices are derived from this run's checked split; do not
assume that later inputs have the same active indices.

```sh
nifs_package=formal/nightstream-fprime/artifacts/nightstream-fprime-stage1-poseidon2-hash-chain-v1.json
nifs_base=formal/nightstream-fprime/artifacts/nightstream-fprime-stage1-base-step-fixture-v1.json
nifs_parent=/tmp/nightstream-native-parent-actual-1
nifs_material=/tmp/nightstream-native-parent-material-1
nifs_openings=/tmp/nightstream-native-child-openings-1
nifs_result=/tmp/nightstream-native-staged-nifs-1

timeout --signal=KILL 300 cargo build -p neo-fold-clean --release --bin generate_pi_ccs_fixture
timeout --signal=KILL 300 target/release/generate_pi_ccs_fixture prove-owned-parent "$nifs_package" "$nifs_base" "$nifs_parent"
timeout --signal=KILL 300 target/release/generate_pi_ccs_fixture check-owned-parent "$nifs_package" "$nifs_base" "$nifs_parent" "$nifs_material"
mkdir "$nifs_openings"
for nifs_child in 0 1 2 3 4 5; do
  timeout --signal=KILL 300 target/release/generate_pi_ccs_fixture open-owned-child "$nifs_package" "$nifs_base" "$nifs_parent" "$nifs_material" "$nifs_child" "$nifs_openings/child-$nifs_child.json" || break
done
timeout --signal=KILL 300 target/release/generate_pi_ccs_fixture assemble-owned-nifs "$nifs_package" "$nifs_base" "$nifs_parent" "$nifs_material" "$nifs_openings" "$nifs_result"
```

Run the independent Lean command from `formal/nightstream-fprime`:

```sh
timeout --signal=KILL 1500 scripts/validate.sh pi-dec-input-check \
  9705822157724451396 520958727644325895 9285622073986934000 874020794279380938 \
  /tmp/nightstream-native-staged-nifs-1/pi_ccs_input.json \
  /tmp/nightstream-native-staged-nifs-1/children.json \
  /tmp/nightstream-native-staged-nifs-1/lean-result.json
```

From the repository root, compare the saved result or run the retained test:

```sh
timeout --signal=KILL 300 target/release/generate_pi_ccs_fixture check-owned-nifs \
  formal/nightstream-fprime/artifacts/nightstream-fprime-stage1-poseidon2-hash-chain-v1.json \
  /tmp/nightstream-native-staged-nifs-1 \
  /tmp/nightstream-native-staged-nifs-1/lean-result.json
timeout --signal=KILL 300 cargo test -p neo-fold-clean --release \
  --test nifs_stage1_nifs selected_nifs_saved_actual_result_matches_lean \
  -- --exact --nocapture
```

Final gates ran from `formal/nightstream-fprime`, in order:

```sh
timeout --signal=KILL 1500 scripts/validate.sh static
timeout --signal=KILL 1500 scripts/validate.sh build
timeout --signal=KILL 1500 scripts/validate.sh axioms
```
