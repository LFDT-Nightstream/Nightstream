# Historical matrix-entry evidence

This archive seals the completed historical code cut
361a4d7fc4e7869b19374872177e3723b4314719, parent
225b271fb2bd5a0a0b979beafacfab8761af0878. It adds no proof, build,
model approval, status promotion, source change, or publication.

The passed owner covers the complete 1,188-row PiDEC commitment block at
global rows [6021547, 6022735), all 14 ports, all 54 coefficient positions,
and every completed-carrier column. Its 892400 bound composes declared
Result.work counters. It is not a complete source-operation or runtime bound.
It does not install the full selected matrix dispatcher.

The exact historical audit has 405 complete records: the unchanged ordered
402-record parent prefix and three new matrix-entry exports. The audit source
and consumed/restored owner snapshots came from git show at this code cut.
No current 424-record audit was substituted. The static text says all checks
passed; its terminal exit 0 is recorded in the coordinator/reviewer note,
not an invented footer in that log.

All three full matrix-entry attempts are retained; the third passed. Round 2
source bytes were recovered by removing the final meaningfulPortCount simp
line from the final Git source and matching the contemporaneous recorded
SHA-256. The manifest labels that reconstruction explicitly.

All three inverse-interface audits and all three selected commitment-consumer
attempts failed. The four complete final drafts remain under drafts/. A prior
ten-second symbolic file check and completed kernel markers do not make the
later full consumer pass. Equal temporary copies of the final drafts are
recorded as origin aliases. The active historical selected checker still has
the commitment and matrix premises. Historical global-inverse draft sources
remain unvalidated and are retained only to support their handoff record.

The source-clock review records the declared-counter/runtime gap. The CO25
notes are mathematical analysis with explicit open transfer/model obligations.
Their third-party full text is intentionally not copied. No large fixtures,
build products, or directory-wide /tmp collection are included.

MANIFEST.json lists every other ZIP entry by path, bytes, SHA-256, scope,
historical code commit, and source origin. The code_commit field associates
each item with this milestone; it does not assert that temporary drafts or
logs were committed. Manifest and archive hashes are in the external
producer/verification logs. Hashes check byte identity, not proof authority.
The archive is an evidence bundle, not a standalone dependency/build image.
