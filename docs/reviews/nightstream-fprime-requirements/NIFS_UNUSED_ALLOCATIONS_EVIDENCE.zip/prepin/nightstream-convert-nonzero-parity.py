#!/usr/bin/env python3
"""Reshape the existing selected parity inputs for the cumulative checkers.

Framing follows tests/nifs/pi_ccs_lean_nonzero_parity.rs::statement_claims.
The output carries fixture proof messages, not actual native prover evidence.
No production pin or source artifact is changed.
"""
import hashlib
import json
import sys
from pathlib import Path

Q = 0xFFFFFFFF00000001
D, MATRICES, RUNNING, ROUNDS, PUBLIC, COMMITMENT = 54, 14, 16, 28, 270, 22 * 54
TAG = list(b"HyperNova/NIVC/state/v1")


def require(ok, message):
    if not ok:
        raise ValueError(message)


def canonical(value):
    if isinstance(value, list):
        for item in value:
            canonical(item)
    else:
        require(type(value) is int and 0 <= value < Q, "noncanonical field word")


def read(path):
    data = path.read_bytes()
    value = json.loads(data)
    canonical(value)
    encoding = json.dumps(value, separators=(",", ":")).encode()
    require(data in (encoding, encoding + b"\n"), f"noncanonical JSON: {path}")
    return value


def pairs(words):
    require(len(words) % 2 == 0, "odd extension-word count")
    return [words[i:i + 2] for i in range(0, len(words), 2)]


def convert(fixtures, destination):
    require(not destination.exists(), "use a fresh conversion directory")
    names = ["binding.json", "piccs-parity.json", "pirlc-parity.json", "pidec-parity.json"]
    binding, ccs, rlc, dec = [read(fixtures / name) for name in names]
    require(len(binding) == 6 and binding[0] == 1, "binding schema")
    require(len(ccs) == 3 and ccs[0] == 8, "PiCCS parity schema8")
    require(len(rlc) == 3 and rlc[0] == 3, "PiRLC parity schema3")
    require(len(dec) == 3 and dec[0] == 2, "PiDEC parity schema2")
    inp, result = ccs[1:]
    require(len(inp) == 11 and len(result) == 16, "complete PiCCS fields")
    require(inp[0] == inp[1], "current fixture's identical framed preimage copies")
    preimage = inp[0]
    require(preimage[:len(TAG)] == TAG, "state domain tag")
    cursor = len(TAG)

    def framed(count):
        nonlocal cursor
        require(cursor < len(preimage) and preimage[cursor] == count, "frame length")
        values = preimage[cursor + 1:cursor + 1 + count]
        require(len(values) == count, "complete framed payload")
        cursor += count + 1
        return values

    require(framed(4) == inp[4], "verifier-context frame")
    require(cursor < len(preimage), "iteration word")
    cursor += 1
    framed(4)  # z0
    framed(4)  # current state
    point = pairs(framed(ROUNDS * 2))
    commitments, public, eval_k, eval_a = [], [], [], []
    for _ in range(RUNNING):
        commitments.append(framed(COMMITMENT))
        public.append(framed(PUBLIC))
        evaluations = pairs(framed((MATRICES + 1) * D * 2))
        eval_k.append(evaluations[:D])
        eval_a.append([evaluations[D + matrix * D:D + (matrix + 1) * D] for matrix in range(MATRICES)])
    require(preimage[cursor:] == [1], "exact pc=1 and complete preimage consumption")
    require(len(inp[2]) == PUBLIC and inp[2][0] == 1, "public encHash shape")
    require(all(bit in (0, 1) for bit in inp[2][1:257]) and all(word == 0 for word in inp[2][257:]), "public digest bit encoding")
    digest = [sum(inp[2][1 + lane * 64 + bit] << bit for bit in range(64)) for lane in range(4)]
    require(digest == inp[3], "public digest words")
    require(inp[9] == [inp[3], inp[5], inp[2]], "complete public transcript blocks")
    claimed = [word for coefficient in range(D) for source in range(RUNNING) for word in eval_k[source][coefficient]]
    claimed += [word for coefficient in range(D) for matrix in range(MATRICES) for source in range(RUNNING) for word in eval_a[source][matrix][coefficient]]
    require(inp[10] == [[word for value in point for word in value], claimed], "semantic verifier-input blocks and order")
    require(len(inp[5]) == COMMITMENT and len(inp[6]) == ROUNDS and all(len(row) == 10 for row in inp[6]), "fresh commitment and complete rounds")
    require(len(inp[7]) == RUNNING + 1 and all(len(row) == D for row in inp[7]), "all output Eval_K families")
    require(len(inp[8]) == RUNNING + 1 and all(len(rows) == MATRICES and all(len(row) == D for row in rows) for rows in inp[8]), "all output Eval_A families")
    running = [point, commitments, public, eval_k, eval_a]
    converted = [2, inp[5], inp[2], inp[6], inp[7], inp[8], running]
    require(result[0] == 1 and result[15] == [1] * 4, "valid nonzero PiCCS fixture")
    require(result[10] == [inp[5]] + commitments and result[11] == [inp[2]] + public, "C commitment/public source order")
    require(result[12:14] == inp[7:9], "C output evaluation messages")
    require(rlc[1] == [result[14], result[6], result[10], result[11], result[12], result[13], binding[2]], "exact C-to-R input and package identity")
    require(len(rlc[2]) == 11 and rlc[2][0] == 1 and rlc[2][10] == [1] * 4, "valid nonzero R fixture")
    din, dout = dec[1:]
    require(len(din) == 7 and len(dout) == 19, "complete D parity fields")
    require(din[0] == [rlc[2][3], rlc[2][4], rlc[2][5], rlc[2][6], rlc[2][7], 1], "exact R-to-D parent")
    require(din[5] == rlc[2][9] and din[6] == binding[2], "D outgoing state and package identity")
    require(dout[0] == 1 and dout[1] == 1 and dout[15] == 1 and dout[16] == [1] * 6, "valid nonzero D and strict-bound rejection")
    children = [din[0][2], din[1], din[4], din[2], din[3]]
    require(all(len(family) == RUNNING for family in children[1:]), "all D child families")
    require(dout[2] == din[4] and dout[14] == din[5], "computed D public digits and state")
    require(dout[13] == [[din[1][i], din[4][i], din[0][2], din[2][i], din[3][i], 0] for i in range(RUNNING)], "all complete D child claims")
    destination.mkdir()
    for name, value in [("piccs-input.json", converted), ("children.json", children)]:
        (destination / name).write_text(json.dumps(value, separators=(",", ":")) + "\n")
    report = {"scope": "schema conversion and data handoff only; no verifier or prover ran", "sources": {name: hashlib.sha256((fixtures / name).read_bytes()).hexdigest() for name in names}, "state_words_consumed": cursor + 1, "outputs": ["piccs-input.json", "children.json"]}
    (destination / "conversion.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    require(len(sys.argv) == 3, "usage: nightstream-convert-nonzero-parity.py <fixture-dir> <fresh-output-dir>")
    convert(Path(sys.argv[1]), Path(sys.argv[2]))
