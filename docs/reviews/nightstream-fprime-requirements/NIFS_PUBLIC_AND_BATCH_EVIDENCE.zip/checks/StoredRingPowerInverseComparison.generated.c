// Lean compiler output
// Module: tests.StoredRingPowerInverseComparison
// Imports: public import Init public meta import Init public import NightstreamFPrime.Spec.Phi81Relation.EvaluationHomomorphism.StoredRingPowerInverse public import NightstreamFPrime.Spec.Phi81Relation.EvaluationHomomorphism.StoredRingInverse
#include <lean/lean.h>
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wunused-parameter"
#pragma clang diagnostic ignored "-Wunused-label"
#elif defined(__GNUC__) && !defined(__CLANG__)
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wunused-label"
#pragma GCC diagnostic ignored "-Wunused-but-set-variable"
#endif
#ifdef __cplusplus
extern "C" {
#endif
lean_object* lean_nat_mod(lean_object*, lean_object*);
lean_object* lean_io_mono_nanos_now();
uint8_t lean_nat_dec_eq(lean_object*, lean_object*);
lean_object* l_Nat_reprFast(lean_object*);
lean_object* lp_mathlib_Nat_fast__choose(lean_object*, lean_object*);
lean_object* l_Array_ofFn___redArg(lean_object*, lean_object*);
lean_object* lean_st_mk_ref(lean_object*);
lean_object* lp_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingInverse_candidate(lean_object*);
lean_object* lean_st_ref_set(lean_object*, lean_object*);
lean_object* lp_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingPowerInverse_inverse(lean_object*);
lean_object* lean_st_ref_get(lean_object*);
lean_object* lean_nat_sub(lean_object*, lean_object*);
lean_object* lean_array_fget_borrowed(lean_object*, lean_object*);
lean_object* lean_string_append(lean_object*, lean_object*);
lean_object* lp_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingArithmetic_multiply(lean_object*, lean_object*);
uint8_t lean_nat_dec_lt(lean_object*, lean_object*);
lean_object* lean_nat_add(lean_object*, lean_object*);
lean_object* lp_nightstream__fprime_NightstreamFPrime_Spec_ringFOne(lean_object*);
uint8_t lean_nat_dec_le(lean_object*, lean_object*);
lean_object* l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___lam__0();
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___lam__0___boxed(lean_object*);
static const lean_string_object lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 41, .m_capacity = 41, .m_length = 40, .m_data = ": inverse product failed at coefficient "};
static const lean_object* lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg___closed__0 = (const lean_object*)&lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg___closed__0_value;
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0___redArg(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0___redArg___boxed(lean_object*, lean_object*, lean_object*);
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 28, .m_capacity = 28, .m_length = 27, .m_data = ": inverse candidates differ"};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__0 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__0_value;
static const lean_ctor_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_ctor_object) + sizeof(void*)*3 + 0, .m_other = 3, .m_tag = 0}, .m_objs = {((lean_object*)(((size_t)(0) << 1) | 1)),((lean_object*)(((size_t)(54) << 1) | 1)),((lean_object*)(((size_t)(1) << 1) | 1))}};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__1 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__1_value;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__2_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 37, .m_capacity = 37, .m_length = 36, .m_data = ": inverse clock exceeds proved bound"};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__2 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__2_value;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 7, .m_capacity = 7, .m_length = 6, .m_data = ": all "};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__3 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__3_value;
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__4_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__4;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__5_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 51, .m_capacity = 51, .m_length = 50, .m_data = " inverse and product coefficients passed; xgcd_ns="};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__5 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__5_value;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 12, .m_capacity = 12, .m_length = 11, .m_data = "; power_ns="};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__6 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__6_value;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 14, .m_capacity = 14, .m_length = 13, .m_data = "; power_work="};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__7 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__7_value;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__8_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 9, .m_capacity = 9, .m_length = 8, .m_data = "; bound="};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__8 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__8_value;
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__9_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__9;
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___boxed(lean_object*, lean_object*, lean_object*);
LEAN_EXPORT uint8_t lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___boxed(lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*, lean_object*);
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0;
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1;
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__2;
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0(lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___boxed(lean_object*);
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___closed__0_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___closed__0;
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1(lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__2(lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__2___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__3(lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__3___boxed(lean_object*);
static const lean_closure_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__0_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__0 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__0_value;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__1_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 11, .m_capacity = 11, .m_length = 10, .m_data = "constant 2"};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__1 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__1_value;
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__2_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__2;
static const lean_closure_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__3_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__3 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__3_value;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__4_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 2, .m_capacity = 2, .m_length = 1, .m_data = "X"};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__4 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__4_value;
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__5_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__5;
static const lean_closure_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__6_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__2___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__6 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__6_value;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__7_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 6, .m_capacity = 6, .m_length = 5, .m_data = "1 + X"};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__7 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__7_value;
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__8_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__8;
static const lean_closure_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__9_value = {.m_header = {.m_rc = 0, .m_cs_sz = sizeof(lean_closure_object) + sizeof(void*)*0, .m_other = 0, .m_tag = 245}, .m_fun = (void*)lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__3___boxed, .m_arity = 1, .m_num_fixed = 0, .m_objs = {} };
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__9 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__9_value;
static const lean_string_object lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__10_value = {.m_header = {.m_rc = 0, .m_cs_sz = 0, .m_other = 0, .m_tag = 249}, .m_size = 17, .m_capacity = 17, .m_length = 16, .m_data = "dense (1 + X)^53"};
static const lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__10 = (const lean_object*)&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__10_value;
static lean_once_cell_t lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__11_once = LEAN_ONCE_CELL_INITIALIZER;
static lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__11;
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg();
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___boxed(lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression(lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___boxed(lean_object*, lean_object*);
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___lam__0(){
_start:
{
lean_object* v___x_2_; lean_object* v___x_3_; 
v___x_2_ = lean_io_mono_nanos_now();
v___x_3_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_3_, 0, v___x_2_);
return v___x_3_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___lam__0___boxed(lean_object* v___y_4_){
_start:
{
lean_object* v_res_5_; 
v_res_5_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___lam__0();
return v_res_5_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg(lean_object* v___x_7_, lean_object* v_name_8_, lean_object* v_range_9_, lean_object* v_b_10_, lean_object* v_i_11_){
_start:
{
lean_object* v_stop_13_; lean_object* v_step_14_; uint8_t v___x_15_; 
v_stop_13_ = lean_ctor_get(v_range_9_, 1);
v_step_14_ = lean_ctor_get(v_range_9_, 2);
v___x_15_ = lean_nat_dec_lt(v_i_11_, v_stop_13_);
if (v___x_15_ == 0)
{
lean_object* v___x_16_; 
lean_dec(v_i_11_);
lean_dec_ref(v_name_8_);
v___x_16_ = lean_alloc_ctor(0, 1, 0);
lean_ctor_set(v___x_16_, 0, v_b_10_);
return v___x_16_;
}
else
{
lean_object* v___x_17_; lean_object* v___x_18_; uint8_t v___x_22_; 
v___x_17_ = lean_unsigned_to_nat(54u);
v___x_18_ = lean_box(0);
v___x_22_ = lean_nat_dec_lt(v_i_11_, v___x_17_);
if (v___x_22_ == 0)
{
goto v___jp_19_;
}
else
{
lean_object* v_value_23_; lean_object* v___x_24_; lean_object* v___x_25_; uint8_t v___x_26_; 
v_value_23_ = lean_ctor_get(v___x_7_, 0);
v___x_24_ = lean_array_fget_borrowed(v_value_23_, v_i_11_);
v___x_25_ = lp_nightstream__fprime_NightstreamFPrime_Spec_ringFOne(v_i_11_);
v___x_26_ = lean_nat_dec_eq(v___x_24_, v___x_25_);
lean_dec(v___x_25_);
if (v___x_26_ == 0)
{
lean_object* v___x_27_; lean_object* v___x_28_; lean_object* v___x_29_; lean_object* v___x_30_; lean_object* v___x_31_; lean_object* v___x_32_; 
v___x_27_ = ((lean_object*)(lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg___closed__0));
v___x_28_ = lean_string_append(v_name_8_, v___x_27_);
v___x_29_ = l_Nat_reprFast(v_i_11_);
v___x_30_ = lean_string_append(v___x_28_, v___x_29_);
lean_dec_ref(v___x_29_);
v___x_31_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v___x_31_, 0, v___x_30_);
v___x_32_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v___x_32_, 0, v___x_31_);
return v___x_32_;
}
else
{
goto v___jp_19_;
}
}
v___jp_19_:
{
lean_object* v___x_20_; 
v___x_20_ = lean_nat_add(v_i_11_, v_step_14_);
lean_dec(v_i_11_);
v_b_10_ = v___x_18_;
v_i_11_ = v___x_20_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg___boxed(lean_object* v___x_33_, lean_object* v_name_34_, lean_object* v_range_35_, lean_object* v_b_36_, lean_object* v_i_37_, lean_object* v___y_38_){
_start:
{
lean_object* v_res_39_; 
v_res_39_ = lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg(v___x_33_, v_name_34_, v_range_35_, v_b_36_, v_i_37_);
lean_dec_ref(v_range_35_);
lean_dec_ref(v___x_33_);
return v_res_39_;
}
}
LEAN_EXPORT uint8_t lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0___redArg(lean_object* v_xs_40_, lean_object* v_ys_41_, lean_object* v_x_42_){
_start:
{
lean_object* v_zero_43_; uint8_t v_isZero_44_; 
v_zero_43_ = lean_unsigned_to_nat(0u);
v_isZero_44_ = lean_nat_dec_eq(v_x_42_, v_zero_43_);
if (v_isZero_44_ == 1)
{
lean_dec(v_x_42_);
return v_isZero_44_;
}
else
{
lean_object* v_one_45_; lean_object* v_n_46_; lean_object* v___x_47_; lean_object* v___x_48_; uint8_t v___x_49_; 
v_one_45_ = lean_unsigned_to_nat(1u);
v_n_46_ = lean_nat_sub(v_x_42_, v_one_45_);
lean_dec(v_x_42_);
v___x_47_ = lean_array_fget_borrowed(v_xs_40_, v_n_46_);
v___x_48_ = lean_array_fget_borrowed(v_ys_41_, v_n_46_);
v___x_49_ = lean_nat_dec_eq(v___x_47_, v___x_48_);
if (v___x_49_ == 0)
{
lean_dec(v_n_46_);
return v___x_49_;
}
else
{
v_x_42_ = v_n_46_;
goto _start;
}
}
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0___redArg___boxed(lean_object* v_xs_51_, lean_object* v_ys_52_, lean_object* v_x_53_){
_start:
{
uint8_t v_res_54_; lean_object* v_r_55_; 
v_res_54_ = lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0___redArg(v_xs_51_, v_ys_52_, v_x_53_);
lean_dec_ref(v_ys_52_);
lean_dec_ref(v_xs_51_);
v_r_55_ = lean_box(v_res_54_);
return v_r_55_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__4(void){
_start:
{
lean_object* v___x_63_; lean_object* v___x_64_; 
v___x_63_ = lean_unsigned_to_nat(54u);
v___x_64_ = l_Nat_reprFast(v___x_63_);
return v___x_64_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__9(void){
_start:
{
lean_object* v___x_69_; lean_object* v___x_70_; 
v___x_69_ = lean_unsigned_to_nat(579844861u);
v___x_70_ = l_Nat_reprFast(v___x_69_);
return v___x_70_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check(lean_object* v_name_71_, lean_object* v_value_72_){
_start:
{
lean_object* v___x_74_; lean_object* v___x_75_; lean_object* v___x_76_; lean_object* v___x_77_; lean_object* v___x_78_; lean_object* v_a_79_; lean_object* v___x_80_; lean_object* v___x_81_; lean_object* v___x_82_; lean_object* v_a_83_; lean_object* v___x_85_; uint8_t v_isShared_86_; uint8_t v_isSharedCheck_152_; 
lean_inc_ref_n(v_value_72_, 2);
v___x_74_ = lean_st_mk_ref(v_value_72_);
v___x_75_ = lean_unsigned_to_nat(0u);
v___x_76_ = lean_alloc_ctor(0, 2, 0);
lean_ctor_set(v___x_76_, 0, v_value_72_);
lean_ctor_set(v___x_76_, 1, v___x_75_);
v___x_77_ = lean_st_mk_ref(v___x_76_);
v___x_78_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___lam__0();
v_a_79_ = lean_ctor_get(v___x_78_, 0);
lean_inc(v_a_79_);
lean_dec_ref(v___x_78_);
v___x_80_ = lp_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingInverse_candidate(v_value_72_);
v___x_81_ = lean_st_ref_set(v___x_74_, v___x_80_);
v___x_82_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___lam__0();
v_a_83_ = lean_ctor_get(v___x_82_, 0);
v_isSharedCheck_152_ = !lean_is_exclusive(v___x_82_);
if (v_isSharedCheck_152_ == 0)
{
v___x_85_ = v___x_82_;
v_isShared_86_ = v_isSharedCheck_152_;
goto v_resetjp_84_;
}
else
{
lean_inc(v_a_83_);
lean_dec(v___x_82_);
v___x_85_ = lean_box(0);
v_isShared_86_ = v_isSharedCheck_152_;
goto v_resetjp_84_;
}
v_resetjp_84_:
{
lean_object* v___x_87_; lean_object* v_a_88_; lean_object* v___x_90_; uint8_t v_isShared_91_; uint8_t v_isSharedCheck_151_; 
v___x_87_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___lam__0();
v_a_88_ = lean_ctor_get(v___x_87_, 0);
v_isSharedCheck_151_ = !lean_is_exclusive(v___x_87_);
if (v_isSharedCheck_151_ == 0)
{
v___x_90_ = v___x_87_;
v_isShared_91_ = v_isSharedCheck_151_;
goto v_resetjp_89_;
}
else
{
lean_inc(v_a_88_);
lean_dec(v___x_87_);
v___x_90_ = lean_box(0);
v_isShared_91_ = v_isSharedCheck_151_;
goto v_resetjp_89_;
}
v_resetjp_89_:
{
lean_object* v___x_92_; lean_object* v___x_93_; lean_object* v___x_94_; lean_object* v___x_95_; lean_object* v___x_96_; lean_object* v_value_97_; lean_object* v_work_98_; lean_object* v___x_99_; uint8_t v___x_100_; 
lean_inc_ref(v_value_72_);
v___x_92_ = lp_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingPowerInverse_inverse(v_value_72_);
v___x_93_ = lean_st_ref_set(v___x_77_, v___x_92_);
v___x_94_ = lean_io_mono_nanos_now();
v___x_95_ = lean_st_ref_get(v___x_74_);
lean_dec(v___x_74_);
v___x_96_ = lean_st_ref_get(v___x_77_);
lean_dec(v___x_77_);
v_value_97_ = lean_ctor_get(v___x_96_, 0);
lean_inc(v_value_97_);
v_work_98_ = lean_ctor_get(v___x_96_, 1);
lean_inc(v_work_98_);
lean_dec(v___x_96_);
v___x_99_ = lean_unsigned_to_nat(54u);
v___x_100_ = lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0___redArg(v___x_95_, v_value_97_, v___x_99_);
lean_dec(v___x_95_);
if (v___x_100_ == 0)
{
lean_object* v___x_101_; lean_object* v___x_102_; lean_object* v___x_104_; 
lean_dec(v_work_98_);
lean_dec(v_value_97_);
lean_dec(v___x_94_);
lean_dec(v_a_88_);
lean_dec(v_a_83_);
lean_dec(v_a_79_);
lean_dec_ref(v_value_72_);
v___x_101_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__0));
v___x_102_ = lean_string_append(v_name_71_, v___x_101_);
if (v_isShared_86_ == 0)
{
lean_ctor_set_tag(v___x_85_, 18);
lean_ctor_set(v___x_85_, 0, v___x_102_);
v___x_104_ = v___x_85_;
goto v_reusejp_103_;
}
else
{
lean_object* v_reuseFailAlloc_108_; 
v_reuseFailAlloc_108_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_108_, 0, v___x_102_);
v___x_104_ = v_reuseFailAlloc_108_;
goto v_reusejp_103_;
}
v_reusejp_103_:
{
lean_object* v___x_106_; 
if (v_isShared_91_ == 0)
{
lean_ctor_set_tag(v___x_90_, 1);
lean_ctor_set(v___x_90_, 0, v___x_104_);
v___x_106_ = v___x_90_;
goto v_reusejp_105_;
}
else
{
lean_object* v_reuseFailAlloc_107_; 
v_reuseFailAlloc_107_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_107_, 0, v___x_104_);
v___x_106_ = v_reuseFailAlloc_107_;
goto v_reusejp_105_;
}
v_reusejp_105_:
{
return v___x_106_;
}
}
}
else
{
lean_object* v___x_109_; lean_object* v___x_110_; lean_object* v___x_111_; lean_object* v___x_112_; 
lean_del_object(v___x_90_);
v___x_109_ = lp_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingArithmetic_multiply(v_value_97_, v_value_72_);
v___x_110_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__1));
v___x_111_ = lean_box(0);
lean_inc_ref(v_name_71_);
v___x_112_ = lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg(v___x_109_, v_name_71_, v___x_110_, v___x_111_, v___x_75_);
lean_dec_ref(v___x_109_);
if (lean_obj_tag(v___x_112_) == 0)
{
lean_object* v___x_114_; uint8_t v_isShared_115_; uint8_t v_isSharedCheck_149_; 
v_isSharedCheck_149_ = !lean_is_exclusive(v___x_112_);
if (v_isSharedCheck_149_ == 0)
{
lean_object* v_unused_150_; 
v_unused_150_ = lean_ctor_get(v___x_112_, 0);
lean_dec(v_unused_150_);
v___x_114_ = v___x_112_;
v_isShared_115_ = v_isSharedCheck_149_;
goto v_resetjp_113_;
}
else
{
lean_dec(v___x_112_);
v___x_114_ = lean_box(0);
v_isShared_115_ = v_isSharedCheck_149_;
goto v_resetjp_113_;
}
v_resetjp_113_:
{
lean_object* v___x_116_; uint8_t v___x_117_; 
v___x_116_ = lean_unsigned_to_nat(579844861u);
v___x_117_ = lean_nat_dec_le(v_work_98_, v___x_116_);
if (v___x_117_ == 0)
{
lean_object* v___x_118_; lean_object* v___x_119_; lean_object* v___x_121_; 
lean_dec(v_work_98_);
lean_dec(v___x_94_);
lean_dec(v_a_88_);
lean_dec(v_a_83_);
lean_dec(v_a_79_);
v___x_118_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__2));
v___x_119_ = lean_string_append(v_name_71_, v___x_118_);
if (v_isShared_86_ == 0)
{
lean_ctor_set_tag(v___x_85_, 18);
lean_ctor_set(v___x_85_, 0, v___x_119_);
v___x_121_ = v___x_85_;
goto v_reusejp_120_;
}
else
{
lean_object* v_reuseFailAlloc_125_; 
v_reuseFailAlloc_125_ = lean_alloc_ctor(18, 1, 0);
lean_ctor_set(v_reuseFailAlloc_125_, 0, v___x_119_);
v___x_121_ = v_reuseFailAlloc_125_;
goto v_reusejp_120_;
}
v_reusejp_120_:
{
lean_object* v___x_123_; 
if (v_isShared_115_ == 0)
{
lean_ctor_set_tag(v___x_114_, 1);
lean_ctor_set(v___x_114_, 0, v___x_121_);
v___x_123_ = v___x_114_;
goto v_reusejp_122_;
}
else
{
lean_object* v_reuseFailAlloc_124_; 
v_reuseFailAlloc_124_ = lean_alloc_ctor(1, 1, 0);
lean_ctor_set(v_reuseFailAlloc_124_, 0, v___x_121_);
v___x_123_ = v_reuseFailAlloc_124_;
goto v_reusejp_122_;
}
v_reusejp_122_:
{
return v___x_123_;
}
}
}
else
{
lean_object* v___x_126_; lean_object* v___x_127_; lean_object* v___x_128_; lean_object* v___x_129_; lean_object* v___x_130_; lean_object* v___x_131_; lean_object* v___x_132_; lean_object* v___x_133_; lean_object* v___x_134_; lean_object* v___x_135_; lean_object* v___x_136_; lean_object* v___x_137_; lean_object* v___x_138_; lean_object* v___x_139_; lean_object* v___x_140_; lean_object* v___x_141_; lean_object* v___x_142_; lean_object* v___x_143_; lean_object* v___x_144_; lean_object* v___x_145_; lean_object* v___x_146_; lean_object* v___x_147_; lean_object* v___x_148_; 
lean_del_object(v___x_114_);
lean_del_object(v___x_85_);
v___x_126_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__3));
v___x_127_ = lean_string_append(v_name_71_, v___x_126_);
v___x_128_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__4, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__4_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__4);
v___x_129_ = lean_string_append(v___x_127_, v___x_128_);
v___x_130_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__5));
v___x_131_ = lean_string_append(v___x_129_, v___x_130_);
v___x_132_ = lean_nat_sub(v_a_83_, v_a_79_);
lean_dec(v_a_79_);
lean_dec(v_a_83_);
v___x_133_ = l_Nat_reprFast(v___x_132_);
v___x_134_ = lean_string_append(v___x_131_, v___x_133_);
lean_dec_ref(v___x_133_);
v___x_135_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__6));
v___x_136_ = lean_string_append(v___x_134_, v___x_135_);
v___x_137_ = lean_nat_sub(v___x_94_, v_a_88_);
lean_dec(v_a_88_);
lean_dec(v___x_94_);
v___x_138_ = l_Nat_reprFast(v___x_137_);
v___x_139_ = lean_string_append(v___x_136_, v___x_138_);
lean_dec_ref(v___x_138_);
v___x_140_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__7));
v___x_141_ = lean_string_append(v___x_139_, v___x_140_);
v___x_142_ = l_Nat_reprFast(v_work_98_);
v___x_143_ = lean_string_append(v___x_141_, v___x_142_);
lean_dec_ref(v___x_142_);
v___x_144_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__8));
v___x_145_ = lean_string_append(v___x_143_, v___x_144_);
v___x_146_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__9, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__9_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___closed__9);
v___x_147_ = lean_string_append(v___x_145_, v___x_146_);
v___x_148_ = l_IO_println___at___00__private_Lean_Shell_0__Lean_ShellOptions_process_spec__3(v___x_147_);
return v___x_148_;
}
}
}
else
{
lean_dec(v_work_98_);
lean_dec(v___x_94_);
lean_dec(v_a_88_);
lean_del_object(v___x_85_);
lean_dec(v_a_83_);
lean_dec(v_a_79_);
lean_dec_ref(v_name_71_);
return v___x_112_;
}
}
}
}
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check___boxed(lean_object* v_name_153_, lean_object* v_value_154_, lean_object* v_a_155_){
_start:
{
lean_object* v_res_156_; 
v_res_156_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check(v_name_153_, v_value_154_);
return v_res_156_;
}
}
LEAN_EXPORT uint8_t lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0(lean_object* v_xs_157_, lean_object* v_ys_158_, lean_object* v_hsz_159_, lean_object* v_x_160_, lean_object* v_x_161_){
_start:
{
uint8_t v___x_162_; 
v___x_162_ = lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0___redArg(v_xs_157_, v_ys_158_, v_x_160_);
return v___x_162_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0___boxed(lean_object* v_xs_163_, lean_object* v_ys_164_, lean_object* v_hsz_165_, lean_object* v_x_166_, lean_object* v_x_167_){
_start:
{
uint8_t v_res_168_; lean_object* v_r_169_; 
v_res_168_ = lp_nightstream__fprime_Array_isEqvAux___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__0(v_xs_163_, v_ys_164_, v_hsz_165_, v_x_166_, v_x_167_);
lean_dec_ref(v_ys_164_);
lean_dec_ref(v_xs_163_);
v_r_169_ = lean_box(v_res_168_);
return v_r_169_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1(lean_object* v___x_170_, lean_object* v_name_171_, lean_object* v_range_172_, lean_object* v_b_173_, lean_object* v_i_174_, lean_object* v_hs_175_, lean_object* v_hl_176_){
_start:
{
lean_object* v___x_178_; 
v___x_178_ = lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___redArg(v___x_170_, v_name_171_, v_range_172_, v_b_173_, v_i_174_);
return v___x_178_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1___boxed(lean_object* v___x_179_, lean_object* v_name_180_, lean_object* v_range_181_, lean_object* v_b_182_, lean_object* v_i_183_, lean_object* v_hs_184_, lean_object* v_hl_185_, lean_object* v___y_186_){
_start:
{
lean_object* v_res_187_; 
v_res_187_ = lp_nightstream__fprime___private_Init_Data_Range_Basic_0__Std_Legacy_Range_forIn_x27_loop___at___00__private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check_spec__1(v___x_179_, v_name_180_, v_range_181_, v_b_182_, v_i_183_, v_hs_184_, v_hl_185_);
lean_dec_ref(v_range_181_);
lean_dec_ref(v___x_179_);
return v_res_187_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0(void){
_start:
{
lean_object* v___x_188_; 
v___x_188_ = lean_cstr_to_nat("18446744069414584321");
return v___x_188_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1(void){
_start:
{
lean_object* v___x_189_; lean_object* v___x_190_; lean_object* v___x_191_; 
v___x_189_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0);
v___x_190_ = lean_unsigned_to_nat(0u);
v___x_191_ = lean_nat_mod(v___x_190_, v___x_189_);
return v___x_191_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__2(void){
_start:
{
lean_object* v___x_192_; lean_object* v___x_193_; lean_object* v___x_194_; 
v___x_192_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0);
v___x_193_ = lean_unsigned_to_nat(2u);
v___x_194_ = lean_nat_mod(v___x_193_, v___x_192_);
return v___x_194_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0(lean_object* v_i_195_){
_start:
{
lean_object* v___x_196_; uint8_t v___x_197_; 
v___x_196_ = lean_unsigned_to_nat(0u);
v___x_197_ = lean_nat_dec_eq(v_i_195_, v___x_196_);
if (v___x_197_ == 0)
{
lean_object* v___x_198_; 
v___x_198_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1);
return v___x_198_;
}
else
{
lean_object* v___x_199_; 
v___x_199_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__2, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__2_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__2);
return v___x_199_;
}
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___boxed(lean_object* v_i_200_){
_start:
{
lean_object* v_res_201_; 
v_res_201_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0(v_i_200_);
lean_dec(v_i_200_);
return v_res_201_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___closed__0(void){
_start:
{
lean_object* v___x_202_; lean_object* v___x_203_; lean_object* v___x_204_; 
v___x_202_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0);
v___x_203_ = lean_unsigned_to_nat(1u);
v___x_204_ = lean_nat_mod(v___x_203_, v___x_202_);
return v___x_204_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1(lean_object* v_i_205_){
_start:
{
lean_object* v___x_206_; uint8_t v___x_207_; 
v___x_206_ = lean_unsigned_to_nat(1u);
v___x_207_ = lean_nat_dec_eq(v_i_205_, v___x_206_);
if (v___x_207_ == 0)
{
lean_object* v___x_208_; 
v___x_208_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1);
return v___x_208_;
}
else
{
lean_object* v___x_209_; 
v___x_209_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___closed__0, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___closed__0_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___closed__0);
return v___x_209_;
}
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___boxed(lean_object* v_i_210_){
_start:
{
lean_object* v_res_211_; 
v_res_211_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1(v_i_210_);
lean_dec(v_i_210_);
return v_res_211_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__2(lean_object* v_i_212_){
_start:
{
lean_object* v___x_213_; uint8_t v___x_214_; 
v___x_213_ = lean_unsigned_to_nat(1u);
v___x_214_ = lean_nat_dec_le(v_i_212_, v___x_213_);
if (v___x_214_ == 0)
{
lean_object* v___x_215_; 
v___x_215_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__1);
return v___x_215_;
}
else
{
lean_object* v___x_216_; 
v___x_216_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___closed__0, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___closed__0_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__1___closed__0);
return v___x_216_;
}
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__2___boxed(lean_object* v_i_217_){
_start:
{
lean_object* v_res_218_; 
v_res_218_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__2(v_i_217_);
lean_dec(v_i_217_);
return v_res_218_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__3(lean_object* v_i_219_){
_start:
{
lean_object* v___x_220_; lean_object* v___x_221_; lean_object* v___x_222_; lean_object* v___x_223_; 
v___x_220_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__0___closed__0);
v___x_221_ = lean_unsigned_to_nat(53u);
v___x_222_ = lp_mathlib_Nat_fast__choose(v___x_221_, v_i_219_);
v___x_223_ = lean_nat_mod(v___x_222_, v___x_220_);
lean_dec(v___x_222_);
return v___x_223_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__3___boxed(lean_object* v_i_224_){
_start:
{
lean_object* v_res_225_; 
v_res_225_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___lam__3(v_i_224_);
lean_dec(v_i_224_);
return v_res_225_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__2(void){
_start:
{
lean_object* v___f_228_; lean_object* v___x_229_; lean_object* v___x_230_; 
v___f_228_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__0));
v___x_229_ = lean_unsigned_to_nat(54u);
v___x_230_ = l_Array_ofFn___redArg(v___x_229_, v___f_228_);
return v___x_230_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__5(void){
_start:
{
lean_object* v___f_233_; lean_object* v___x_234_; lean_object* v___x_235_; 
v___f_233_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__3));
v___x_234_ = lean_unsigned_to_nat(54u);
v___x_235_ = l_Array_ofFn___redArg(v___x_234_, v___f_233_);
return v___x_235_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__8(void){
_start:
{
lean_object* v___f_238_; lean_object* v___x_239_; lean_object* v___x_240_; 
v___f_238_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__6));
v___x_239_ = lean_unsigned_to_nat(54u);
v___x_240_ = l_Array_ofFn___redArg(v___x_239_, v___f_238_);
return v___x_240_;
}
}
static lean_object* _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__11(void){
_start:
{
lean_object* v___f_243_; lean_object* v___x_244_; lean_object* v___x_245_; 
v___f_243_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__9));
v___x_244_ = lean_unsigned_to_nat(54u);
v___x_245_ = l_Array_ofFn___redArg(v___x_244_, v___f_243_);
return v___x_245_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg(){
_start:
{
lean_object* v___x_247_; lean_object* v___x_248_; lean_object* v___x_249_; 
v___x_247_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__1));
v___x_248_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__2, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__2_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__2);
v___x_249_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check(v___x_247_, v___x_248_);
if (lean_obj_tag(v___x_249_) == 0)
{
lean_object* v___x_250_; lean_object* v___x_251_; lean_object* v___x_252_; 
lean_dec_ref(v___x_249_);
v___x_250_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__4));
v___x_251_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__5, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__5_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__5);
v___x_252_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check(v___x_250_, v___x_251_);
if (lean_obj_tag(v___x_252_) == 0)
{
lean_object* v___x_253_; lean_object* v___x_254_; lean_object* v___x_255_; 
lean_dec_ref(v___x_252_);
v___x_253_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__7));
v___x_254_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__8, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__8_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__8);
v___x_255_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check(v___x_253_, v___x_254_);
if (lean_obj_tag(v___x_255_) == 0)
{
lean_object* v___x_256_; lean_object* v___x_257_; lean_object* v___x_258_; 
lean_dec_ref(v___x_255_);
v___x_256_ = ((lean_object*)(lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__10));
v___x_257_ = lean_obj_once(&lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__11, &lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__11_once, _init_lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___closed__11);
v___x_258_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_check(v___x_256_, v___x_257_);
return v___x_258_;
}
else
{
return v___x_255_;
}
}
else
{
return v___x_252_;
}
}
else
{
return v___x_249_;
}
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg___boxed(lean_object* v_a_259_){
_start:
{
lean_object* v_res_260_; 
v_res_260_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg();
return v_res_260_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression(lean_object* v_x_261_){
_start:
{
lean_object* v___x_263_; 
v___x_263_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___redArg();
return v___x_263_;
}
}
LEAN_EXPORT lean_object* lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression___boxed(lean_object* v_x_264_, lean_object* v_a_265_){
_start:
{
lean_object* v_res_266_; 
v_res_266_ = lp_nightstream__fprime___private_tests_StoredRingPowerInverseComparison_0__NightstreamFPrime_Tests_StoredRingPowerInverseComparison_regression(v_x_264_);
return v_res_266_;
}
}
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_Init(uint8_t builtin);
lean_object* initialize_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingPowerInverse(uint8_t builtin);
lean_object* initialize_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingInverse(uint8_t builtin);
static bool _G_initialized = false;
LEAN_EXPORT lean_object* initialize_nightstream__fprime_tests_StoredRingPowerInverseComparison(uint8_t builtin) {
lean_object * res;
if (_G_initialized) return lean_io_result_mk_ok(lean_box(0));
_G_initialized = true;
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_Init(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingPowerInverse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
res = initialize_nightstream__fprime_NightstreamFPrime_Spec_Phi81Relation_EvaluationHomomorphism_StoredRingInverse(builtin);
if (lean_io_result_is_error(res)) return res;
lean_dec_ref(res);
return lean_io_result_mk_ok(lean_box(0));
}
#ifdef __cplusplus
}
#endif
