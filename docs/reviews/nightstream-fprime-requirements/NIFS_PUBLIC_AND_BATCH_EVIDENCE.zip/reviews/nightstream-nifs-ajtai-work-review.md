# Independent Ajtai coefficient-work review

Reviewer: Worker 3 (`/root/conformance_review`), independent of the author
of the new counted generator. Date: 2026-09-10.

No defect was found in the stated value and named-operation work claims.
The function computes the actual indexed coefficient and returns the count
from the same calls. The bound includes seed-list access, the complete
ChaCha block, packing and reduction. It is not a machine-time, bit-operation
or gas bound, and it is not the work bound for a complete dense commitment.

This review read the full frozen work file and the relevant authoritative
generator, word-law, index-framing and selected-key source. No active source
was edited. No build, test, prover, backend or PaperExact command was run by
this reviewer. This finding does not extend the immutable `773f3d0f` review.

## Source identities

Paths are relative to
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/`.

| Source | Lines | SHA-256 |
|---|---:|---|
| `Spec/AjtaiSetupV1/Work.lean` | 543 | `70fb5515ac20ca03dda5b260654b1ed6738f515d2009440c0a0007a0d4a8e561` |
| `Spec/AjtaiSetupV1.lean` | 93 | `9c030df54f54e26770f8cf7384de8c7ee349de18935ffe99cc76d1d9da691a60` |
| `Spec/AjtaiSetupV1/ChaCha20.lean` | 82 | `76b7361cc7a44acd7019c5dbb184f79812e38a981c83413986f80569527ce470` |
| `Spec/AjtaiSetupV1/WordOperations.lean` | 206 | `b9e0f0ac4a780874387fa672b12ab125b7a903be8128de6980a9f8e4bd008c61` |
| `Spec/AjtaiSetupV1/IndexEncoding.lean` | 119 | `07937d840c7a4ec3ad34aba6097a820fdf2d2686c1baa669b5be1083f8ed81fb` |
| `Export/Stage1/Poseidon2HashChainV1Setup.lean` | 177 | `b8fedbdd75c8730eb4f25bf39ee6e55b9b7e009a956078067aa9f324eda0d168` |

These hashes identify the reviewed source. They are not evidence that a
carried digest or a selected seed has semantic authority.

## Exact generated value

`Work.coefficient_value` at line 525 equates the returned field value with
`setup.verifierKey row blockIndex lane` for every typed setup and coordinate.
Its proof uses the value lemmas for the actual counted implementation,
ending at `wideCoefficientNat`, `Setup.coefficientNat` and `Setup.verifierKey`.
There is no honest-witness, sparse-input, cache, sampled-value or successful
opening premise.

The path was checked operation by operation:

- `readByte` at line 183 traverses the seed list to the requested offset.
  It refines the actual `List.getD offset 0` lookup. `littleEndian` at line
  208 preserves offsets and the weights 1, 256, 65536 and 16777216.
- `initial` at line 232 reads seed words at offsets 0, 4, ..., 28. It puts
  the four existing constants in positions 0–3, the eight seed words in
  positions 4–11, the lane counter in position 12, the row in position 13,
  and low/high block words in positions 14–15. All reductions and the block
  quotient match `ChaCha20.initialState`.
- `quarter` at line 71 preserves the five original array reads, including
  the second read of B. It performs four additions, four XORs and rotations
  by 16, 12, 8 and 7, then the same four array writes. `quarter_value` reaches
  the existing `ChaCha20.quarterRound` directly.
- `double` at line 117 retains all four column rounds followed by all four
  diagonal rounds in their exact order. `rounds` at line 157 performs ten
  double rounds in the block caller: all 80 quarter rounds.
- `block` at line 354 builds the exact index list 0–15 and executes every
  modular feed-forward addition using the corresponding original state
  word. It does not omit the upper eight feed-forward words.
- `first256` at line 468 takes the first eight words only after that full
  block, reverses them, and folds by radix `2^32`. This gives
  `w0 + 2^32*w1 + ... + 2^224*w7`, the original little-endian first 256 bits.
- `coefficient` at line 513 applies the original Goldilocks modulo reduction
  once to this integer and returns the canonical field element. The `Fin
  (2^256)` proof wrapper does not execute another generation call.

The existing `WordOperations` lemmas connect addition, XOR and rotation to
32-bit `BitVec` operations, preserve canonical words and array size, and
identify the round schedule and feed-forward. `first256_lt` in the new
module additionally proves the packed integer is below `2^256`, using all
eight canonical words. These are deterministic value facts. They add no
ChaCha20 pseudorandomness assumption or theorem.

## Derived operation count

The public theorem `coefficient_work_le` at line 535 bounds the returned
clock by `coefficientWork = 27509`. The reviewed arithmetic is:

| Component | Bound in named operations |
|---|---:|
| Seed words and initial 16-cell array | 2,735 |
| One quarter round | 302 |
| One double round | 2,417 |
| Ten double rounds with recursion | 24,202 |
| Construct ordered indices 0–15 | 115 |
| All 16 feed-forward words | 290 |
| Complete block, including return | 27,343 |
| Block plus take/reverse/packing | 27,499 |
| Setup/index reads, wide wrapper, reduction and return | 10 |
| One coefficient | 27,509 |

The byte reads are not treated as constant array lookups. The 32 offsets
cause 496 list-prefix descents in total; the proved read clocks sum to
2,608. Word assembly and nonce/array construction give the 2,735 initial
bound. `indices` uses direct `List.ofFnM` indices and charges the final
reverse as well as the forward pass.

Each quarter-round write is charged by `3 * state.size + 5`. At size 16,
four writes contribute 212 operations. This includes allocation and a
read/write copy of every cell; it does not assume unique ownership of the
current buffer. The size-preservation lemmas justify using 16 after every
update. All actual quarter-round indices are within that array. No
out-of-bounds array-update behavior is needed by the coefficient caller.

The eight-word take, reverse and Horner pack are counted as separate
traversals. Their bounds are 60, 44 and 51, followed by one return. This
accounts for the full 27,499 intermediate bound rather than only the
final modulo operation.

## Fixed-word and selected-owner scope

`Seed` stores exactly 32 canonical bytes; its length and byte bounds are
part of the input type. The lane is `Fin 54`. The public work theorem also
requires `row.val < 2^32` and `blockIndex.val < 2^64`, matching the existing
row32/block64 nonce framing. These are existing representation boundaries,
not new limits. `IndexEncoding.initialState_index_injective` separately
shows why those ranges matter for coordinate framing.

The two range arguments have leading underscores and are not used by the
counter-arithmetic proof. The defined counter can be bounded even for
larger natural indices, because it counts named arithmetic calls. That
fact does not establish constant machine cost on unbounded naturals. The
range premises correctly remain in the public interface for its fixed-word
interpretation. Canonical state words, 32-bit rotations, at most 64-bit
nonce input, and the proved 256-bit packed value keep the actual selected
arithmetic operands bounded.

The final reduction counts one 256-bit-by-Goldilocks modulo operation. It
does not prove the internal bit-operation cost of `Nat.mod`, nor that a
named operation takes one machine instruction. Allocation, reference
counting, compiler behavior, machine time and gas do not follow from the
clock theorem alone.

The selected source link is intact: `Poseidon2HashChainV1Setup.productionAjtaiKey`
uses `ajtaiKey productionSetup`; `PerApplicationCanonicalPackage.commitmentKey`
at line 47 is exactly `setup.verifierKey`. The selected dimensions are 22
rows and 4,708,530 message blocks, so every selected row/block index meets
the public range conditions. The Work module itself is generic and does
not yet supply a complete selected dense-commitment consumer.

One invocation generates one coefficient. A 54-lane key block requires 54
invocations, plus its storage work. A dense arbitrary-witness commitment
also needs all key blocks, ring products, accumulation, witness reads and
comparison work. This review does not turn the coefficient bound into an
uncharged key-function call, a whole-key cache, or a closed commitmentCheck.
No production setup, profile, hash binding or protocol operation changed.

## Retained validation

The first log records a proof-alignment failure in `block_work_le`: the
bound used `List.range 16` while the goal still used `(indices 16).value`.
The frozen source rewrites both with the proved `indices_value` equality.
The second focused build passed, reporting module time 789ms and command
time 1s, bounded at 1,500 seconds with terminal exit zero. Only linter
warnings remain. This reviewer read both records and ran neither command.

| Record under `/tmp/` | SHA-256 |
|---|---|
| `nightstream-nifs-ajtai-setup-work-1.log` | `8d9808f352e3e8226171f614855293d4ab6e6d5818b7f6ddbf42b8df8f6bd8c1` |
| `nightstream-nifs-ajtai-setup-work-2.log` | `d6af6095f65d5a8a752a9ac8c51b6fbbb53b267241b8dfec6698a0891ad85bdf` |

The two new exported theorems are `coefficient_value` and
`coefficient_work_le`. No final combined allowed-axiom/static audit for
this milestone was supplied to this review. This finding does not approve
full extractor runtime or broad Stage 1 closure.
