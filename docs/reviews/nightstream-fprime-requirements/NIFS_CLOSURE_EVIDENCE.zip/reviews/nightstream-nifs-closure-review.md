# Scoped NIFS closure review

Checked source cut: `88d394fb4b24cfba21fd1a995bff16c3449312a8` on
`nico/nifs-proof-links`, observed on 2026-09-10 at 20:18 UTC. The source and
test trees had no difference from this cut at the final observation.
Workspace: `/home/nicoarq/develop/Nightstream-nifs-proof-links`.

This note records Worker 2's source reviews and a read of the retained gate
logs. No new build, test, backend execution, source edit, site edit, or commit
was performed for this note. The density modules were authored by Worker 2;
root independently reviewed those modules and reported no semantic issue.
Worker 2 independently reviewed the other new consumers named below.

No required source repair was found within the stated value and declared-clock
scope. This is not an approval of the external Fiat–Shamir assumption or a
numerical security claim.

**Proved local links.**

- `NifsBinding.bindingEvent_to_shortKernel` consumes the actual selected
  observation binding event. It preserves the collision's commitment, scalar
  membership, equations, norm bounds and nonzero condition when calling the
  selected fixed-setup reduction. Its conclusion identifies a nonzero short
  integer kernel vector at `productionAjtaiKey` with the existing
  `productionGlobalParams.msisNormBound`. This value theorem does not itself
  supply an algorithm clock or a numerical MSIS success bound.
- `PiCCSStoredWitnessCheck.finishValue_source_iff` identifies the selected
  stored checked return with the existing relaxed-success and source-validity
  event. The actual public/ambient checker, selected relation, Ajtai key,
  matrix functions and verifier-owned public prefixes are used. Abort and
  rejection remain `none`; source validity is not assumed as input.
- `PiCCSStoredSourceProbability` proves check/access correctness for the
  selected source program, preserves the stored probe and witness views,
  and proves the exact `finish_value` equation. Its source-probability
  equality uses the same causal prefix, captured state, suffix law, consumed
  weak endpoint, raw certificate lists and ordered values on both sides.
  It does not replace an observed result with a chosen source witness.
- `PiRLCExtractionPrimitives.program_correct` proves the four selected
  primitive values. Inversion executes the existing stored ring inverse;
  the primitive receives a scalar, not a supplied inverse. Unit evidence is
  used in the proof. The inverse's returned named work is retained and the
  declared adapter clock is added. The selected subtraction and scalar-action
  operations retain their existing values.
- `FieldDensityLaw` uses a finite quotient/remainder injection and the
  already proved bit-decoder Option mixture. It proves successful-event
  density at most `((M^2)/q)^32` against uniform scalars, where `M=2^32` and
  `q=M^2-M+1`. `SamplerDensityLaw` transports this to the existing scalar
  conversion. The field input space remains all `q^32` inputs: the proof
  excludes abort from the event without conditioning or renormalizing the
  distribution. No Poseidon2 input law is asserted. The existing TV estimate
  is therefore not an unavoidable additive soundness loss.
- `VerifierErrorBudget` proves the selected test numerator `13257`, transports
  the existing field-comparison batch-abort bound, and applies the finite
  union bound to supplied test and abort events in one probability space.
  Its per-call hypotheses must be justified for that trace experiment.
  Independence is not needed. The user's `100000000`-call example gives a
  bound of `2^-87` for these named events only. It excludes Fiat–Shamir,
  hash/MSIS attacks, and the strong-extraction square-root loss. It is not
  a deployment default or a complete NIFS security estimate.

**Generic and selected Fiat–Shamir consumers.**

`FiatShamirTransfer.RealSuccess` runs the actual `ProductionKey` verifier and
requires witnesses for every exact returned child. Its separate child
correspondence theorem uses the existing PiDEC result equation and the
order-preserving `Fin.cast`; there is no omitted or prover-selected child.
The real law includes failed outputs. `contextLaw` is its `Prod.fst` marginal,
and the same running/fresh projections, relation and key parameterize the
interactive experiment.

`FiatShamirModel` assumes only
`g Q p_real - deltaFS Q <= p_interactive`. It contains no source-witness
conclusion, checker correctness, primitive correctness, call refinement, or
work bound. The binding and MSIS probability bridges are valid inequality
composition with `SupportedExtraction`. The corrected second-round proof
only fixes the order of an addition; the theorem statements are unchanged.

`NifsFiatShamir.finishValue_probability_and_expected_work` discharges both
local `Correct` obligations using the selected primitive and source owners.
Its final probability event is exactly `SourceReturned` of the selected
`finishValue (storeOutcome outcome)`. It retains the same real success event,
context marginal and input projections. No probability, source, or clock
hypothesis is hidden by the specialization.

**Declared-clock limits.**

The source checker/access and the primitive adapters receive explicit clock
functions. `Bounded`, low-norm invertibility, preparation/call value
refinement, access bounds, summability and polynomial moment bounds remain
visible hypotheses. The prepared theorem charges the supplied preparation
call and the existing prepared extraction/MSIS clocks. Equality of the
preparation context law is required. A TV or event bound is not used to infer
expected work.

`PaperForkExtractionWork.Result` now states this scope explicitly: it stores
a value and a declared clock; it does not automatically charge all function
applications, allocation, conversions, setup or arithmetic. The theorem is
not a Lean/Rust machine-time claim or a time bound for an unspecified
adversary translator. The selected source/value and conditional work links
can be recorded as connected under the revised declared-clock scope. This
does not prove an older full-runtime criterion if that wording is retained.

**Review of the current owner proposal.**

The reviewed file is
`docs/reviews/nightstream-fprime-requirements/FIAT_SHAMIR_MODEL.md`, not a
root-level `docs/FIAT_SHAMIR_MODEL.md`. It correctly proposes parametric
approval and asserts no model instance. It defines `Q` as total permutation
queries in the declared experiment, including extractor replays, and keeps
any base-query inflation separate. It covers adaptive classical adversaries,
the fixed public seed/code, forward and inverse queries, shared Poseidon2
uses, adaptive statements, and persistent raw answers/state at repeated
complete prefixes.

The proposed translation and success inequality are an additional external
FS/SuperNeo game-transfer contract. This is non-circular as stated: source
witnesses are obtained only after applying the proved SuperNeo extraction
theorem. It is stronger than collision resistance. The proposal correctly
does not claim that CO25's overwrite construction already covers the actual
additive absorption and initialization.

The context marginal proves equality of the input distribution, not a
coupling or an executable translation of each adversary run. Approval must
apply to the declared family of admissible adversaries and translations,
with `law` equal to their actual output law. The Lean record alone does not
construct that family, count its queries, or supply useful `g`/`deltaFS`
functions. The proposal states this limitation and does not choose identity
`g` or a numerical error.

A finite deployed overall-security claim still needs useful quantitative
bounds for the approved transfer functions, the exact oracle/adversary scope,
and a valid total query accounting. If replays have no deterministic cap,
the external theorem must handle their query distribution or account for a
stated truncation tail; an expected call count is not a hard query bound.
The claim also needs the applicable MSIS bound, the actual per-call laws for
the named sampler/test events, and the relevant history/iteration composition.
The strong-extraction square-root loss cannot be replaced by the isolated
test numerator. None of these quantities is selected by this review.

**Preserved conformance scope.**

The retained evidence remains the nonzero selected-key Lean/optimized Rust
C/R/D and complete NIFS comparison, including final children, the returned
R parent cache, full eight-word transcript state, canonical proof bytes,
and the recorded rejection mutations. The earlier conformance review and
`NIFS_COMPLETE_REPLAY_EVIDENCE.zip` identify that execution cut and its inputs.
The current source changes above are Lean proof/consumer and clock-scope
changes; no fresh optimized or PaperExact execution was performed here.
The retained optimized result is not expanded into an arbitrary-input
runtime proof, same-input PaperExact R/D result, backend result, or a
full-history extraction theorem.

**Retained gate observations.**

The following logs were read. Build/audit records end in successful completion
and `exit=0`; static records state that all boundary checks passed. Existing
linter warnings remain in several logs. Audited declarations report only
`propext`, `Classical.choice`, and `Quot.sound`.

| Scope | Retained logs |
|---|---|
| Selected binding event | `/tmp/nightstream-nifs-binding-link-build-1.log`, `/tmp/nightstream-nifs-binding-link-axioms-1.log`, `/tmp/nightstream-nifs-binding-link-static-1.log` |
| Stored checked return | `/tmp/nightstream-nifs-value-return-build-1.log`, `/tmp/nightstream-nifs-value-scope-axioms-1.log`, `/tmp/nightstream-nifs-value-scope-static-1.log` |
| Source probability adapter | `/tmp/nightstream-nifs-source-probability-build-1.log`, `/tmp/nightstream-nifs-source-probability-axioms-1.log`, `/tmp/nightstream-nifs-source-probability-static-1.log` |
| Density | `/tmp/nightstream-nifs-density-build-1.log`, `/tmp/nightstream-nifs-density-axioms-1.log`, `/tmp/nightstream-nifs-density-static-1.log` |
| Generic FS bridge | `/tmp/nightstream-nifs-fs-transfer-build-2.log`, `/tmp/nightstream-nifs-fs-transfer-axioms-2.log`, `/tmp/nightstream-nifs-fs-transfer-static-2.log` |
| Primitives and event budget | `/tmp/nightstream-nifs-primitives-build-2.log`, `/tmp/nightstream-nifs-error-budget-build-2.log`, `/tmp/nightstream-nifs-budget-primitives-build.log`, `/tmp/nightstream-nifs-budget-primitives-axioms-2.log`, `/tmp/nightstream-nifs-error-budget-static-1.log` |
| Final selected consumer and combined cut | `/tmp/nightstream-nifs-selected-fs-build-1.log`, `/tmp/nightstream-nifs-selected-fs-build.log`, `/tmp/nightstream-nifs-selected-fs-axioms-1.log`, `/tmp/nightstream-nifs-selected-fs-static-1.log` |

The final selected consumer build reports 1.8 s for the module and 3 s for
the wrapper; the subsequent complete build reports 1 s and the combined
axiom gate reports 4 s. These are retained measurements, not new limits or
evidence of cryptographic security. The final audit explicitly includes the
selected binding, checked-return, density, source-probability, primitive,
event-budget, generic FS and final selected consumer declarations.

For preserved execution evidence, the read logs include
`/tmp/nightstream-nifs-complete-driver-honest.log`,
`/tmp/nightstream-nifs-complete-artifact-check-2.log`,
`/tmp/nightstream-nifs-complete-evidence-check.log`, and
`/tmp/nightstream-nifs-public-verifier-regression-2.log`. They retain their
original input/source and command scope; this review did not rerun them.

**Observed SHA-256 identities.**

Code paths below are relative to `formal/nightstream-fprime/NightstreamFPrime/`.
These hashes identify reviewed bytes; they are not proof authority.

| Source | SHA-256 |
|---|---|
| `Export/Stage1/NifsBinding.lean` | `796339beef0f16d6e5c9e05099db612617b4c8737d6065a16ddbd03ca3cf15df` |
| `Export/Stage1/PiCCSStoredWitnessCheck.lean` | `d653a91d33ff599d61488f97908282a4a57a0b2ae4640b9e8744a047600fc18b` |
| `Export/Stage1/PiCCSStoredSourceProbability.lean` | `8536f8599cbb8bf05399ca2ce7e2ff2213d44b4a000d95e90731a961df1cba24` |
| `Export/Stage1/PiRLCExtractionPrimitives.lean` | `c4735ef74cf277cb5fa47efd24ab297694420072b2bd572f1299c3b4dfe25d25` |
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldDensityLaw.lean` | `0877dbc41fa094be84513e6c6b4c2da5e04a10a94fec4af4bb7068e78b3c9470` |
| `Lifecycle/PiRLC/v1_1/SamplerDensityLaw.lean` | `ff065c4c5f580b3bd787e8d39d9d08969de79d238193bb0b099e39d3ad179cc6` |
| `Lifecycle/Nifs/VerifierErrorBudget.lean` | `50913341ce0e32a7fb5613470b0212195524b8d54955103a56a6795e4c78119b` |
| `Lifecycle/Nifs/FiatShamirTransfer.lean` | `2ee1d59338a9d0deb08e1942c431a5cb4b9f97d3135cd0e72cfcb11e2aa0b509` |
| `Export/Stage1/NifsFiatShamir.lean` | `a2bdbdfcaed42ee160e8b6297631caac3f40fb48a9cea1e5aa71b096b77f48bd` |
| `Spec/Folding/PiRLC/PaperForkExtractionWork.lean` | `e524bf407342732ebe08ab210fc69c231e10397dbfbb6f374764cb59914391fa` |

The separately reviewed owner proposal at
`docs/reviews/nightstream-fprime-requirements/FIAT_SHAMIR_MODEL.md` has observed
SHA-256 `c55b30377de657bb233710b69a8116a142602e1b95f3cb251f9ca7818b5a71b6`.
This identifies the proposal read for this report; it does not assert that
the proposal was approved or committed in the source cut.
