"""Record this task's guarded commands without modifying retained evidence."""
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

store = Path(__file__).resolve().parent
source = Path('/Users/nijaar/starstream/Nightstream-fprime-conformance-fixes')
label, kind, *command = sys.argv[1:]
log = store / (label + '.log')
cwd = source / 'formal/nightstream-fprime' if kind == 'lean' else source
argv = ['python3', '-B', str(source / 'scripts/lean_graph/guard.py'),
        '--kind', kind, '--cwd', str(cwd), '--', *command]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('x') as output:
    result = subprocess.run(argv, stdout=output, stderr=subprocess.STDOUT,
                            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
record = {'label': label, 'started_at': started, 'command': argv,
          'exit': result.returncode, 'log': str(log)}
for line in reversed(log.read_text().splitlines()):
    try:
        detail = json.loads(line)
        if isinstance(detail, dict) and 'cap_seconds' in detail:
            record['execution'] = detail
            break
    except json.JSONDecodeError:
        continue
path = store / 'executions.json'
records = json.loads(path.read_text()) if path.exists() else []
records.append(record)
path.write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(record))
if result.returncode:
    print('\n'.join(log.read_text().splitlines()[-35:]))
raise SystemExit(result.returncode)
