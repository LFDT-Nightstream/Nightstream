# Pre-pin optimized-only nonzero parity

Pre-pin optimized-only nonzero phase parity. The fixtures are comparison data, not actual full native prover inputs/outputs. Production pins and main bootstrap source remain unchanged.

The two concrete fixes are the C/R driver package-identity field and an optimized-only entry into the existing complete D result checker. No arithmetic implementation is copied. The old dual-engine test remains available but is not selected.

Structural identity (CLI candidate selector): [12322613552781674794, 11618660216342328080, 8890015725622288919, 10115040070495147315].
Package identity (Lean R/D input metadata): [9705822157724451396, 520958727644325895, 9285622073986934000, 874020794279380938].

Run each phase only after the preceding phase passes. All commands are pending. Lean commands run from formal/nightstream-fprime; Cargo commands run from the isolated worktree root. Native commands use the project300s cap; Lean commands use1500s.

convert:
```sh
timeout --signal=KILL 300s python3 -B /tmp/nightstream-convert-nonzero-parity.py /tmp/nightstream-unused-allocation-evidence/fixtures /tmp/nightstream-unused-allocation-evidence/nonzero-converted
```

C Lean:
```sh
timeout --signal=KILL 1500s bash scripts/validate.sh pi-ccs-input-check /tmp/nightstream-unused-allocation-evidence/nonzero-converted/piccs-input.json /tmp/nightstream-unused-allocation-evidence/nonzero-converted/ccs-result.json
```

C optimized:
```sh
timeout --signal=KILL 300s cargo run --locked --release -p neo-fold-clean --bin check_pi_ccs_input -- /tmp/nightstream-unused-allocation-evidence/fixtures/candidate.json 12322613552781674794 11618660216342328080 8890015725622288919 10115040070495147315 /tmp/nightstream-unused-allocation-evidence/nonzero-converted/piccs-input.json /tmp/nightstream-unused-allocation-evidence/nonzero-converted/ccs-result.json optimized-accept
```

C/R Lean:
```sh
timeout --signal=KILL 1500s bash scripts/validate.sh pi-rlc-input-check 9705822157724451396 520958727644325895 9285622073986934000 874020794279380938 /tmp/nightstream-unused-allocation-evidence/nonzero-converted/piccs-input.json /tmp/nightstream-unused-allocation-evidence/nonzero-converted/rlc-result.json
```

C/R optimized:
```sh
timeout --signal=KILL 300s cargo run --locked --release -p neo-fold-clean --bin check_pi_ccs_input -- /tmp/nightstream-unused-allocation-evidence/fixtures/candidate.json 12322613552781674794 11618660216342328080 8890015725622288919 10115040070495147315 /tmp/nightstream-unused-allocation-evidence/nonzero-converted/piccs-input.json /tmp/nightstream-unused-allocation-evidence/nonzero-converted/rlc-result.json optimized-rlc
```

C/R/D Lean:
```sh
timeout --signal=KILL 1500s bash scripts/validate.sh pi-dec-input-check 9705822157724451396 520958727644325895 9285622073986934000 874020794279380938 /tmp/nightstream-unused-allocation-evidence/nonzero-converted/piccs-input.json /tmp/nightstream-unused-allocation-evidence/nonzero-converted/children.json /tmp/nightstream-unused-allocation-evidence/nonzero-converted/dec-result.json
```

D optimized complete:
```sh
timeout --signal=KILL 300s cargo test --locked --release -p neo-fold-clean --test nifs_pi_dec_lean_nonzero_parity lean_optimized_matches_complete_nonzero_pi_dec_result -- --exact --nocapture
```

After emission, require `ccs-result[5] == piccs-parity[2][:15]`; `rlc-result[6:] == pirlc-parity[1:]`; `dec-result[:8] == rlc-result`; and `dec-result[9][:16] == pidec-parity[2][:16]`. Also require `dec-result[9][16] == [1, children]`. These are comparisons against the existing separately emitted parity inputs/results; they do not generate expected arithmetic. D parity fields16–18 add the existing nonzero flags and state-preimage/hash checks, which the optimized-only test retains.

The conversion reads only existing schema8input fields: `[2, input[5], input[2], input[6], input[7], input[8], decodedRunning(input[0])]`. It decodes all framed preimage words in the existing statement_claims order, checks the complete public and semantic verifier blocks, and derives Dchildren as `[Dinput[0][2], Dinput[1], Dinput[4], Dinput[2], Dinput[3]]`. It checks complete source/result handoffs and canonical field/JSON encodings before writing into a fresh /tmpdirectory. No expected mathematical value, package pin, or new protocol parameter is invented.

Source hashes, exact claims and command arrays: `/tmp/nightstream-unused-optimized-parity-readiness.json`.
