import tests.EvidenceTargets

/-! Checker-owned invocations of the approved target and metadata checks.
Candidate declarations cannot omit these invocations from an acceptance run.
-/

#evidence_closed LeanGraph.Targets.PilotAssignment by LeanGraph.Targets.pilotAssignment
#evidence_closed LeanGraph.Targets.PiCCSAssignment by LeanGraph.Targets.piCCSAssignment

#evidence_closed LeanGraph.Targets.PiCCSPublicAssignment by LeanGraph.Targets.piCCSPublicAssignment
#evidence_closed LeanGraph.Targets.Stage1Assignment by LeanGraph.Targets.stage1Assignment
#evidence_closed LeanGraph.Targets.Stage1TerminalAssignment by LeanGraph.Targets.stage1TerminalAssignment
#evidence_closed LeanGraph.Targets.Stage1TerminalParent by LeanGraph.Targets.stage1TerminalParent
#evidence_closed LeanGraph.Targets.HyperNovaLinearSecurity by LeanGraph.Targets.hyperNovaLinearSecurity
