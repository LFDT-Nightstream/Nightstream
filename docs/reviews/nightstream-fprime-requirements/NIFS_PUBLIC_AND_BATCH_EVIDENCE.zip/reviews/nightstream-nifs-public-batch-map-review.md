# Independent milestone documentation and map review

Reviewer: Worker 3, `/root/conformance_review`.

Code cut: `692641958134b46d021639aed088d5574e1c68ce` in
`/home/nicoarq/develop/Nightstream-nifs-proof-links`.
This review covers the changed milestone text in the three reports below,
the three changed requirement nodes, and `nifs_public_batch_update`.
It compares the working documentation with `git show HEAD:<path>` at that
code cut. It does not extend the original immutable-cut conformance review
or repeat the source proofs and validation checks.

Result: **pass after one scope correction**. The original sentence that
the public checker "passes for every typed stored probe" could claim that
all malformed inputs are accepted. The coordinator changed it to say that
the checker's value and work theorems hold for every typed stored probe.
The corrected text at `NIFS_PROOF_LINKS.md:919` agrees with `check_value`
and `check_work_le`. No remaining false or stale claim was found in the
changed material. This reviewer made no active file edit and ran no build,
test, generator, backend, or PaperExact command.

## Claim and record checks

- The public check is installed in the selected witness checker. Its value
  theorem equals the existing predicate; it is not universal acceptance.
  The scope includes arbitrary typed probes and raw round lists. Pad stays
  separate from the 14 matrix families.
- The generic dense row has checked value and named-work proofs. The full
  selected commitment checker is explicitly unvalidated after three
  attempts, is retained outside active source, and has no adapter or audit
  registration. Commitment and matrix entry remain the selected checker's
  two contracts. No changed paragraph claims that the draft passed or was
  installed.
- Stored power has a unit-value theorem and a named-operation bound of
  579,844,861. The reports state that the existing inverse path is unchanged
  and selection and the outer representation/primitive link remain open.
  They do not claim a compiled-runtime, wall-time, gas, or full extraction
  theorem from that counter.
- The final timing record is the forced IO comparison. Its four power
  times range from 10.371750916s to 13.173788970s; extended GCD ranges from
  0.015131994s to 0.150011375s. Thus the reported 10.4--13.2 seconds and
  15--150 milliseconds are valid rounded values. All returned clocks are
  292,431,123. The test compares all 54 returned inverse coefficients with
  extended GCD and all 54 stored product coefficients with the identity.
  It does not separately execute an extended-GCD product. The earlier
  pure-let timing is explicitly excluded as timing evidence. These are
  four Lean execution observations, not a universal runtime bound.
- The independent batch output bound has the stated finite input and
  successful ordered target. Actual list/state equalities are deterministic
  Option results: successful output has the stated final state, and failure
  remains `none`. They do not identify internal failed traces. The new
  scalarwise totalizer proves finite output bounds and successful list
  agreement only. Acceptance inclusion, inverse fibers and work, the exact
  schedule, cache and query laws, state-restoration extraction, and transfer
  to fixed Poseidon2 remain open. No model, failed-trace equality, or complete
  Fiat--Shamir applicability is claimed. The inverse-codec plan is identified
  as an unproved next target.
- The native header entry rejects before its own builder/transcript
  mutation. Public types remain available, and the reports state the normal
  and restored-profile caller effects. They exclude an atomicity claim for
  caller prelude work and supply no replacement recursive API or broad
  Stage 1 conformance verdict.
- The initial 328-record / 26-addition gate and final 336-record /
  34-addition gate are distinct retained checks. The final 3,723-job,
  four-second result and permitted-axiom scope agree with the independently
  checked final audit. Static pass agrees with the retained result.
- The 20 paths in the code commit exactly equal the frozen source manifest.
  Every committed blob matches the manifest's SHA-256 and byte count. The
  selected commitment draft is absent from this set.
- The regression log reports 19.38s compilation and 0.00s test execution;
  the normal release check reports 8.27s. The new map build log reports 454
  nodes, and its test log reports seven passing tests. The 09:20 checkpoint
  log is byte-identical to the 08:20 log: three protected paths are absent,
  and the primary checkout's September 4 external review is retained with
  unchanged contents. The old review suite was not rerun here.

## Map preservation

Both maps contain 454 nodes in the same order. Exactly these nodes differ:

| Node | Connection before and after | Changed fields |
|---|---|---|
| `N.security.binding` | `partial` | `code`, `remaining` |
| `N.security.fiat_shamir` | `open` | `code`, `remaining` |
| `N.conformance.owners` | `partial` | `code`, `remaining` |

The other 451 node objects are exactly equal to their counterparts in
`HEAD`'s JSON. No node was inserted, deleted, or moved. All three nodes also
retain their proof and Rust statuses. Each added or relocated source link
points to the named declaration at the stated line in the code cut.

The only other changed root keys are `commit`, `source_note`, and the new
`nifs_public_batch_update`. Earlier update objects are unchanged. The new
object names the correct code cut and three changed nodes, records the
final audit, and keeps `model_approved`, `paper_exact_executed`, and
`website_published` false. Its remaining-work field preserves the selected
commitment, matrix, producer, representation/runtime, inverse-selection,
and Fiat--Shamir limits.

The previous bytes of `NIFS_CONFORMANCE_REVIEW_773f3d0f.md` remain an exact
prefix of its current bytes. Its new coordinator record does not rewrite
the original reviewed cut. Archive assembly and final archive identity are
the coordinator's separate packaging check; this review does not claim
that an archive was inspected or published.

## Reviewed document identities

Paths are relative to the worktree above. SHA-256 identifies bytes only.

| Path | Bytes | SHA-256 |
|---|---:|---|
| `docs/reviews/nightstream-fprime-requirements/NIFS_PROOF_LINKS.md` | 63,767 | `832ea192afeb3e7e7e56f917d7ec874d6a7943363c17d829e94fe486b5727483` |
| `docs/reviews/nightstream-fprime-requirements/NIFS_FIAT_SHAMIR_MODEL_DECISION.md` | 41,395 | `e821f9bd59c9e8a6a8a635e71118469df25bf95a01ef35c3c71998e0922bfc32` |
| `docs/reviews/nightstream-fprime-requirements/NIFS_CONFORMANCE_REVIEW_773f3d0f.md` | 74,285 | `8b16a0ef6853a6abbae737784e988c37c4c8bc73c3203e20a40776e8d1d15b42` |
| `docs/reviews/nightstream-fprime-requirements/site/requirements.json` | 460,298 | `693a4e1f37db41415238c481bff446ff7f04934806d91c111e71733680fc0c80` |

The final audit/static/source-manifest record remains in
`/tmp/nightstream-nifs-public-batch-milestone-review.md`. The exact source
and measurement limits remain in the separate public/normalization, batch,
power-inverse, selected-commitment and totalized-decoder review notes.
