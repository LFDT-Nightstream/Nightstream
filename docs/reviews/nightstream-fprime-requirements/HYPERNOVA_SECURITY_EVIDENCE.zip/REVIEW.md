Parent cut061c502c; listed source hashes define the checked proof cut. Ordered gates: static; full library3859jobs47s; full axioms3948jobs47s. Only propext, Classical.choice, Quot.sound are allowed.

Root reviewed: visited acceptance follows the actual mark; first failures cover base hash collisions and absent source results; initial support is needed only for symbolic depth. Base NIFS acceptance derives the public bound from actual sampled membership and claims no fresh or child opening. R construction reuses the existing sampler/append assembler and derives generated outputs from rows. No package data or pins changed.

Independent visited_acceptance review: NifsProviderLaw fixes raw calls, tapes and clocks before the context law and preserves the actual source PMF under supported extension. Total-family finite call moments remain explicit; averaged work and an FS model for another law are not supplied. Root source-call/control bound includes abort and false-mark paths, with no acceptance or source-success premise.

Whole-history probability uses one shared g/deltaFS across the exact guarded model family. The stated hash and selected MSIS reduction events remain explicit. Expected source work and selected full-package completeness remain open.
