# Independent selected commitment-check review

Reviewer: Worker 3 (`/root/conformance_review`), 2026-09-10.
The full frozen `Export/Stage1/PiCCSStoredCommitmentCheck.lean` was read.
No defect was found in the stated value or named-operation work claims.
This initial record has no terminal build result or passing adapter
integration result. No build, test or active source edit was performed by
this reviewer.

## Reviewed source

Paths are relative to
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/`.

| Source | SHA-256 |
|---|---|
| `Export/Stage1/PiCCSStoredCommitmentCheck.lean` — 273 lines | `4089ad6a02977033253203275054ae5a268c38772677f3e99cd9d53424a9feb3` |
| `Spec/Phi81Relation/PiRLCAlgebra/StoredCommitment.lean` — consumed row implementation, 228 lines | `f955c6708d95871688ffe8312869a4790b021c801634905fe1bdaf4378c26890` |

The root separately reviewed the generic row. This review checked its
implementation and exported value/work contracts as consumed by the
selected checker. Earlier Ajtai and stored-arithmetic review limits remain
in force. Hashes identify source; they do not establish authority.

## Same source, key and public commitment

The carrier alias uses the independent selected `PaperAlgebra.FullShape`
with `PiDECInputCheck.logicalWidth/publicFits`. The stored witness is a
vector of 17 complete-carrier coefficient vectors. The checker reads the
chosen source vector once before its row loop. It does not reconstruct an
arbitrary coefficient function or assign such a function a lookup cost.

`publicCommitment` at line 89 selects the fresh commitment at source zero.
Sources 1–16 select `input.running.commitments[source-1]`. The rebased index
is proved in range. `publicCommitment_value` matches the existing
`PiCCSInputCheck.outputCommitments` source order by `Fin.addCases`.
The selected 1188-field array is retained before the row loop.

`selectedRow` at line 165 invokes the concrete `StoredCommitment.row` with
`Poseidon2HashChainV1Setup.productionSetup`. `selectedRow_value` reaches
the same `productionAjtaiKey` used by `PaperAlgebra.openingMaps`. The helper
`rowOpening_value` is a generic use of the existing row theorem, not a new
primitive assumption supplied by the checker caller.

The row implementation computes every complete carrier block in increasing
index order. It expands each 54-lane key block with the actual counted
Ajtai coefficient generator, copies the matching 54 witness coefficients,
computes the stored ring product and updates the stored accumulator.
It has no sparse, zero-tail or honest-witness shortcut and materializes no
full key. Arbitrary completion-tail witness values remain included in the
commitment computation.

## Comparison, rejection and public theorem scope

`compareCoefficient` at line 131 reads one computed coefficient and the
claimed coordinate `row*54+lane`. All 22 rows and all 54 lanes must match
for acceptance. `check_value` at line 243 proves equality to the Boolean
test of the complete selected commitment equality for every stored witness
and source. It assumes neither a valid opening nor an accepted public
proof, and it exposes no primitive correctness premise.

`allFin` uses the direct `Fin.foldl` implementation. Once its accumulated
Boolean is false, it skips subsequent comparison or dense-row calls but
still visits the remaining indices and charges their control steps. Thus
the source claim that failed rows skip further row computations is exact;
it does not claim the whole finite loop exits early.

Each computed row is passed as a single `Result (Vector F 54)` into
`compareRow`. Its value and work come from that same call. The explicit
generic comparison bound is instantiated by the actual selected row bound.
No externally supplied row clock or free semantic commitment lookup reaches
the public checker theorem.

## Work and proof boundary

The scalar comparison costs 12 named operations. Its 54-lane comparison
loop is bounded by 868, and the row wrapper adds two operations. The outer
22-row loop adds four per row. Fresh/running commitment selection is bounded
by 10; the final source-read/closure/return envelope is four. These compose
to the declared bound
`22 * (StoredCommitment.rowWork carrier + 874) + 18`.

`selectedRow_work_le` discharges the actual row32 and block64 framing
premises: row indices are below 22, and the selected block count is
4,708,530. `check_work_le` at line 263 consequently has no remaining work
premise, including no opening-validity or sparsity premise. It covers
rejected as well as accepted candidates.

The local irreducibility attributes prevent proof elaboration from
normalizing millions of block iterations. They do not alter the child
implementation, replace a computation with an axiom, or omit work from
the executable call. These are named-operation bounds. This review does
not execute the full dense selected check or establish its wall time.

The selected checker is a concrete candidate for the existing
`commitmentCheck` slot. Until the adapter is passed and reviewed, this record
does not claim that the old selected witness-check commitment premises have
been removed. Matrix-entry work and the other extraction/FS limits remain
separate.

## Terminal status: not validated and not integrated

The final third full-module build was stopped. The retained
`/tmp/nightstream-nifs-selected-commitment-check-3.log` reports the target
as failed after 400s and `Lean exited with code 143`; the root reports the
build command's terminal code as 1. The root observed sustained CPU use and
about 7.6 GB memory without a source diagnostic before stopping it. No fourth
or narrower build was attempted under the three-round rule.

The complete reviewed draft is retained outside active Lean source at
`docs/reviews/nightstream-fprime-requirements/drafts/NIFS_STORED_COMMITMENT_CHECK.lean.txt`.
Its 273 lines and 14,057 bytes have the same SHA-256
`4089ad6a02977033253203275054ae5a268c38772677f3e99cd9d53424a9feb3`.
The active module is absent, and the audit registration file has no import
or theorem audit for this selected checker. Its adapter was not integrated.

The selected checker theorem claims are therefore **not Lean-validated**
for this milestone. The earlier source review describes the draft's intended
value/work proof and found no source defect; it does not certify either
exported theorem, approve the implementation, or remove the selected
commitment-check premises. No complete selected commitment execution is
claimed. The separate generic `StoredCommitment.row` result remains passed.

The existing selected witness checker remains the passing public/Pad/scalar
integration with explicit commitment and matrix-entry contracts. Final audit
and static records after removal are separate pending evidence at this point.
