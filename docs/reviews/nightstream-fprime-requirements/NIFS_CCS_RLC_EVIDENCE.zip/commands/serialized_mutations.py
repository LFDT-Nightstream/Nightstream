import json,pathlib,subprocess,time
work=pathlib.Path('/home/nicoarq/develop/Nightstream-nifs-proof-links')
data=pathlib.Path('/tmp/nightstream-nifs-conformance-z5w8wiof')
base=['timeout','--signal=KILL','300s','/home/nicoarq/develop/Nightstream/target/release/check_pi_ccs_input',str(work/'formal/nightstream-fprime/artifacts/nightstream-fprime-stage1-poseidon2-hash-chain-v1-candidate.json'),'12850397830186002711','3288783999059851307','4378874948253040911','12528041036879069119',str(data/'recursive_phase_input.json')]
records=[]
for name,path in json.loads((data/'rlc_serialized_mutations.json').read_text()):
 command=base+[str(data/f'rlc_mutation_{name}.json'),'optimized-rlc']
 log=data/f'rlc_mutation_{name}.log'
 start=time.monotonic()
 with log.open('w') as output: result=subprocess.run(command,cwd=work,stdout=output,stderr=subprocess.STDOUT)
 expected='exact PiCCS-to-PiRLC input handoff' if name=='handoff_state' else f'complete Lean/optimized PiRLC result field {path[1]}'
 record=dict(name=name,path=path,command=command,exit=result.returncode,elapsed_seconds=time.monotonic()-start,expected_failure=expected,passed=result.returncode in [-6,134] and expected in log.read_text())
 records.append(record)
 (data/'rlc_serialized_mutation_results.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 assert record['passed']
