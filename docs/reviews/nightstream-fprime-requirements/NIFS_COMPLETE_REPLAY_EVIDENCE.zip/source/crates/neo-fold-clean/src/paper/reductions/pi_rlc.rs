//! Native Pi_RLC reduction from CE inputs to one combined CE parent.
//!
//! Owns: input/combined validation, rho transcript scheduling, projection
//! binding data, and prover/verifier orchestration.
//!
//! Does not own: the RLC norm-bound theorem, engine ring mixing, Pi_DEC, or
//! in-circuit verification.
//!
//! Emits constraints: no.
//!
//! Authority boundary: the prover-supplied combined claim is checked against
//! verifier-derived rho values and the authenticated inputs before Pi_DEC uses
//! it; projection digests are compression, not authority.
//!
//! | Obligation | Local owner | Emits constraints? | Authority source |
//! |---|---|---|---|
//! | Rho schedule | [`begin_rho_sampling`], [`derive_rhos_for_inputs`] | no | Transcript-bound Pi_CCS outputs |
//! | Combined claim | [`validate_combined`] | no | Verifier recomputation from authenticated inputs |
//! | Prove/verify | [`prove`], [`verify`] | no | Engine Pi_RLC relation and checked transcript |

use neo_ajtai::Commitment;
use neo_ccs::{LaneCommitments, Mat};
use neo_math::field::KExtensions;
use neo_math::{D, F, K};
use thiserror::Error;

use crate::engine::optimized as engine;
use crate::engine::paper_exact as reference_engine;
use crate::engine::r1cs_circuit::ring_action::{projection_quotient, PROJECTION_QUOTIENT_LEN};
use crate::engine::transcript::{Poseidon2TranscriptSnapshot, Transcript};
use crate::paper::digest;
use crate::paper::params::Params;
use crate::paper::reductions::accumulator_sis_circuit::{
    accumulator_digest as sis_accumulator_digest, SisAccumulatorError, PI_RLC_PROJECTION_SIS_CONFIG,
};
use crate::paper::reductions::paper_exact_protocol;
use crate::paper::reductions::pi_rlc_circuit::rlc_projection_quotients;
use crate::paper::relations::{superneo_has_canonical_x_shape, validate_adv_shape, CeClaim, RlcMixer};
use crate::paper::sampling::check_rlc_bound;
use p3_field::{PrimeCharacteristicRing, PrimeField64};

pub(crate) const PI_RLC_PROJECTION_COMBINED_C_LABEL: &[u8] = b"pi_rlc/projection_combined_c";
pub(crate) const PI_RLC_PROJECTION_QUOTIENTS_LABEL: &[u8] = b"pi_rlc/projection_quotients";
pub(crate) const PI_RLC_PROJECTION_COMBINED_ADV_LABEL: &[u8] = b"pi_rlc/projection_combined_adv";
pub(crate) const PI_RLC_PROJECTION_ADV_QUOTIENTS_LABEL: &[u8] = b"pi_rlc/projection_adv_quotients";
pub(crate) const PI_RLC_PROJECTION_COMBINED_X_LABEL: &[u8] = b"pi_rlc/projection_combined_x";
pub(crate) const PI_RLC_PROJECTION_X_QUOTIENTS_LABEL: &[u8] = b"pi_rlc/projection_x_quotients";
pub(crate) const PI_RLC_PROJECTION_COMBINED_EVALUATION_LABEL: &[u8] = b"pi_rlc/projection_combined_evaluation";
pub(crate) const PI_RLC_PROJECTION_EVALUATION_QUOTIENTS_LABEL: &[u8] = b"pi_rlc/projection_evaluation_quotients";
pub(crate) const PI_RLC_PROJECTION_BINDING_DOMAIN: &[u8] = b"neo.fold.clean/pi_rlc/projection_binding/v1";
pub(crate) const PI_RLC_PROJECTION_BINDING_DIGEST_LABEL: &[u8] = b"pi_rlc/projection_binding_digest";
pub(crate) const PI_RLC_PROJECTION_BETA_LABEL: &[u8] = b"pi_rlc/projection_beta";

#[derive(Debug, Error)]
pub enum Error {
    #[error("\u{03A0}_RLC: input claims must be \u{2265} 1 (got 0)")]
    Shape,
    #[error("\u{03A0}_RLC: |claims| ({claims}) \u{2260} |witnesses| ({witnesses})")]
    WitnessMismatch { claims: usize, witnesses: usize },
    #[error("\u{03A0}_RLC: verifier rejected the prover's combined CE claim")]
    VerifyRejected,
    #[error("\u{03A0}_RLC: combined fold_digest must match every input fold_digest")]
    FoldDigest,
    #[error("\u{03A0}_RLC: noncanonical fold_digest byte limb in {owner} at lane {lane}")]
    FoldDigestCanonicality { owner: &'static str, lane: usize },
    #[error("\u{03A0}_RLC: X must use the canonical whole-ring coefficient embedding in {0}")]
    NoncanonicalXShape(&'static str),
    #[error("\u{03A0}_RLC: r length must match the padded joint row point in {0}")]
    RShape(&'static str),
    #[error("\u{03A0}_RLC: combined r must match every input r")]
    RConsistency,
    #[error("\u{03A0}_RLC: adv presence must be all-or-nothing across inputs ({present}/{total} present)")]
    AdvPresence { present: usize, total: usize },
    #[error("\u{03A0}_RLC: combined adv must equal the component-wise RLC of input adv tuples")]
    AdvConsistency,
    #[error("\u{03A0}_RLC: invalid product-commitment shape: {0}")]
    AdvShape(String),
    #[error("\u{03A0}_RLC: Eval_K or Eval_A has an invalid v1_1 shape in {0}")]
    EvaluationShape(&'static str),
    #[error("\u{03A0}_RLC: evaluation padding lanes must be zero in {0}")]
    EvaluationPadding(&'static str),
    #[error(
        "\u{03A0}_RLC: projection schedule — combined commitment lane {lane} is not the ring-action mix of the inputs"
    )]
    ProjectionMixDrift { lane: usize },
    #[error("Pi_RLC: projection schedule - combined adv.{coordinate} lane {lane} is not the ring-action mix")]
    AdvProjectionMixDrift {
        coordinate: &'static str,
        lane: usize,
    },
    #[error("Pi_RLC: projection schedule - combined {client} identity {identity} is not the ring-action mix")]
    AuxiliaryProjectionMixDrift {
        client: &'static str,
        identity: usize,
    },
    #[error("Pi_RLC: accelerator failed to compute the canonical projection SIS digest")]
    BackendProjectionDigest,
    #[error(transparent)]
    Projection(#[from] crate::paper::reductions::pi_rlc_circuit::Error),
    #[error(transparent)]
    SisAccumulator(#[from] SisAccumulatorError),
    #[error(transparent)]
    Sampling(#[from] crate::paper::sampling::SamplingError),
    #[error(transparent)]
    Engine(#[from] engine::Error),
    #[error(transparent)]
    PaperExactEngine(#[from] reference_engine::Error),
}

/// Output of one Π_RLC step — a single CE claim of norm B plus its
/// combined witness `Z_mix = Σρ_i Z_i`. Witness is prover-only; the
/// verifier reconstructs only the claim.
#[derive(Clone, Debug)]
pub struct Output {
    pub claim: CeClaim,
    pub witness: Mat<F>,
    /// The Lemma 5 β schedule this fold ran —
    /// prover-side plumbing for the F' image's projection regions.
    pub projection: ProjectionSchedule,
}

/// Π_RLC output whose prover witness remains owned by an accelerator.
#[derive(Clone, Debug)]
pub struct ResidentOutput<Resident> {
    pub claim: CeClaim,
    pub witness: Resident,
    pub projection: ProjectionSchedule,
}

/// Post-mix β schedule for the projection-checked commitment combination.
/// Nothing here rides the wire: the verifier recomputes every field
/// from ρ and the input commitments, so a carried value can never
/// out-vote the transcript.
#[derive(Clone, Debug)]
pub struct ProjectionSchedule {
    /// ρ_i ring elements (rotation-matrix first columns), fold order.
    pub rhos: Vec<[F; D]>,
    /// Per-κ-lane division quotients `q_lane` with
    /// `Σ_i ρ_i(X)·c_{i,lane}(X) = q_lane(X)·Φ(X) + combined_lane(X)`.
    pub q_lanes: Vec<[F; PROJECTION_QUOTIENT_LEN]>,
    /// Projection quotients for the `(ops, is, fs)` coordinates of `L+`.
    pub adv_q_lanes: Option<LaneCommitments<Vec<[F; PROJECTION_QUOTIENT_LEN]>>>,
    /// One quotient per active X ring column.
    pub x_q_lanes: Vec<[F; PROJECTION_QUOTIENT_LEN]>,
    /// Two quotients (c0, c1) per v1_1 evaluation family.
    pub evaluation_q_lanes: Vec<[[F; PROJECTION_QUOTIENT_LEN]; 2]>,
    /// The evaluation challenge, squeezed after c* and every `q_lane`
    /// are on the transcript — the order is the soundness (Lemma 5).
    pub beta: K,
}

/// Wire-format proof: the prover's combined CE claim of norm B.
///
/// The ρ-rotation challenges are not serialized here; prover and verifier
/// both resample them from the Fiat-Shamir transcript at this phase.
#[derive(Clone, Debug, PartialEq)]
pub struct Proof {
    pub combined: CeClaim,
}

// ──────────────────────────────────────────────────────────────────────────
// Prover  (§7.4 step order)
// ──────────────────────────────────────────────────────────────────────────

pub fn prove(
    tr: &mut Transcript,
    pp: &Params,
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    claims: &[CeClaim],
    witnesses: &[Mat<F>],
) -> Result<(Output, Proof), Error> {
    let witness_refs: Vec<&Mat<F>> = witnesses.iter().collect();
    prove_refs(tr, pp, s, mix, claims, &witness_refs)
}

pub(crate) fn prove_refs(
    tr: &mut Transcript,
    pp: &Params,
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    claims: &[CeClaim],
    witnesses: &[&Mat<F>],
) -> Result<(Output, Proof), Error> {
    #[cfg(feature = "perf-timers")]
    let total_started = std::time::Instant::now();
    #[cfg(feature = "perf-timers")]
    let prepare_started = std::time::Instant::now();
    validate_input_shape(claims, witnesses)?;
    validate_inputs_before_rho(s, claims)?;
    let rhos = derive_rhos_for_inputs(tr, pp, claims)?;
    #[cfg(feature = "perf-timers")]
    let prepare_elapsed = prepare_started.elapsed();
    #[cfg(feature = "perf-timers")]
    let mix_started = std::time::Instant::now();
    let (mut combined, z_mix) = engine::prove_pi_rlc_refs(pp, s, &rhos, claims, witnesses, |zs, cs| mix(zs, cs))?;
    #[cfg(feature = "perf-timers")]
    let mix_elapsed = mix_started.elapsed();
    #[cfg(feature = "perf-timers")]
    let public_checks_started = std::time::Instant::now();
    combined.adv = mixed_adv(mix, &rhos, claims)?;
    validate_combined_claim(s, mix, &rhos, claims, &combined)?;
    #[cfg(feature = "perf-timers")]
    let public_checks_elapsed = public_checks_started.elapsed();
    #[cfg(feature = "perf-timers")]
    let projection_started = std::time::Instant::now();
    let projection = projection_schedule(tr, &rhos, claims, &combined)?;
    #[cfg(feature = "perf-timers")]
    eprintln!(
        "[pi-rlc/prove] prepare={:.3}s mix={:.3}s checks={:.3}s projection={:.3}s total={:.3}s inputs={} c_lanes={} adv={} X={} y={}",
        prepare_elapsed.as_secs_f64(),
        mix_elapsed.as_secs_f64(),
        public_checks_elapsed.as_secs_f64(),
        projection_started.elapsed().as_secs_f64(),
        total_started.elapsed().as_secs_f64(),
        claims.len(),
        combined.c.kappa,
        combined.adv.is_some(),
        combined.X.cols(),
        combined.eval_a.len() + 1,
    );
    Ok((
        Output {
            claim: combined.clone(),
            witness: z_mix,
            projection,
        },
        Proof { combined },
    ))
}

/// PaperExact PiRLC prover used by the end-to-end NIFS reference.
pub(crate) fn prove_refs_paper_exact(
    tr: &mut Transcript,
    pp: &Params,
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    claims: &[CeClaim],
    witnesses: &[&Mat<F>],
) -> Result<(Output, Proof), Error> {
    validate_input_shape(claims, witnesses)?;
    validate_inputs_before_rho(s, claims)?;
    let rhos = derive_rhos_for_inputs_paper_exact(tr, pp, claims)?;
    let (mut combined, witness) =
        reference_engine::prove_pi_rlc_refs(pp, s, &rhos, claims, witnesses, |rho_matrices, commitments| {
            mix(rho_matrices, commitments)
        })?;
    combined.adv = paper_exact_protocol::mixed_adv(mix, &rhos, claims)?;
    validate_combined_claim(s, mix, &rhos, claims, &combined)?;
    let projection = paper_exact_protocol::projection_schedule(tr, &rhos, claims, &combined)?;
    Ok((
        Output {
            claim: combined.clone(),
            witness,
            projection,
        },
        Proof { combined },
    ))
}

/// Π_RLC prover with an accelerator-owned witness random-linear-combination.
///
/// The canonical paper layer still validates inputs, samples rho, builds and
/// validates the public parent, and executes the projection transcript. The
/// callback owns only `Z_mix = sum_i rho_i * Z_i`.
pub fn prove_refs_with_witness_mixer<MW>(
    tr: &mut Transcript,
    pp: &Params,
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    claims: &[CeClaim],
    witnesses: &[&Mat<F>],
    mix_witnesses: MW,
) -> Result<(Output, Proof), Error>
where
    MW: Fn(&[Mat<F>], &[&Mat<F>]) -> Mat<F>,
{
    validate_input_shape(claims, witnesses)?;
    validate_inputs_before_rho(s, claims)?;
    let rhos = derive_rhos_for_inputs(tr, pp, claims)?;
    let (mut combined, z_mix) = engine::prove_pi_rlc_refs_with_witness_mixer(
        pp,
        s,
        &rhos,
        claims,
        witnesses,
        |zs, cs| mix(zs, cs),
        mix_witnesses,
    )?;
    combined.adv = mixed_adv(mix, &rhos, claims)?;
    validate_combined_claim(s, mix, &rhos, claims, &combined)?;
    let projection = projection_schedule(tr, &rhos, claims, &combined)?;
    Ok((
        Output {
            claim: combined.clone(),
            witness: z_mix,
            projection,
        },
        Proof { combined },
    ))
}

/// Π_RLC prover with a backend-owned resident witness.
///
/// The canonical layer validates all inputs, samples ρ, constructs the public
/// parent, and runs the projection transcript. Only `Z_mix` storage and
/// computation cross into the callback.
pub fn prove_refs_with_resident_witness<MW, Resident>(
    tr: &mut Transcript,
    pp: &Params,
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    claims: &[CeClaim],
    witnesses: &[&Mat<F>],
    mix_witnesses: MW,
) -> Result<(ResidentOutput<Resident>, Proof), Error>
where
    MW: Fn(&[Mat<F>], &[&Mat<F>]) -> Resident,
{
    prove_refs_with_resident_witness_and_projection_digest(
        tr,
        pp,
        s,
        mix,
        claims,
        witnesses,
        mix_witnesses,
        |preimage| Ok(sis_accumulator_digest(PI_RLC_PROJECTION_SIS_CONFIG, preimage)?),
    )
}

/// Resident-witness prover path with accelerator-owned canonical digests.
///
/// The protocol layer constructs and validates the projection preimage. The
/// verifier recomputes its digest independently.
#[doc(hidden)]
pub fn prove_refs_with_resident_witness_and_projection_digest<MW, PD, Resident>(
    tr: &mut Transcript,
    pp: &Params,
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    claims: &[CeClaim],
    witnesses: &[&Mat<F>],
    mix_witnesses: MW,
    compute_projection_digest: PD,
) -> Result<(ResidentOutput<Resident>, Proof), Error>
where
    MW: Fn(&[Mat<F>], &[&Mat<F>]) -> Resident,
    PD: FnOnce(&[F]) -> Result<[F; 4], Error>,
{
    validate_input_shape(claims, witnesses)?;
    validate_inputs_before_rho(s, claims)?;
    begin_rho_sampling(tr, pp, claims)?;
    let rhos = engine::sample_rho_n(tr.inner_mut(), pp, claims.len())?;
    let (mut combined, resident) = engine::prove_pi_rlc_refs_with_resident_witness(
        pp,
        s,
        &rhos,
        claims,
        witnesses,
        |zs, cs| mix(zs, cs),
        mix_witnesses,
    )?;
    combined.adv = mixed_adv(mix, &rhos, claims)?;
    validate_combined_claim(s, mix, &rhos, claims, &combined)?;
    let projection = projection_schedule_with_digest(tr, &rhos, claims, &combined, compute_projection_digest)?;
    Ok((
        ResidentOutput {
            claim: combined.clone(),
            witness: resident,
            projection,
        },
        Proof { combined },
    ))
}

/// The prover's pre-ρ input validations (`prove_refs` line one), exposed for
/// NIFS backends that run Π_RLC's claim algebra outside `prove`. Call before
/// deriving ρ so a malformed input fails with the CPU error surface and an
/// untouched transcript.
pub fn validate_inputs(s: &crate::paper::relations::Structure, claims: &[CeClaim]) -> Result<(), Error> {
    validate_inputs_before_rho(s, claims)
}

/// The prover's post-combine claim validations, for the same backends.
/// Transcript-neutral; touches only claims, never witnesses.
pub fn validate_combined(
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    rhos: &[neo_reductions::common::RotRho],
    claims: &[CeClaim],
    combined: &CeClaim,
) -> Result<(), Error> {
    validate_combined_claim(s, mix, rhos, claims, combined)
}

// ──────────────────────────────────────────────────────────────────────────
// Verifier (§7.4)
// ──────────────────────────────────────────────────────────────────────────

/// Verify the prover's combined CE claim against `Σρ_i · u_i` recomputed
/// from `(transcript, claims)`. Returns the verified parent for Π_DEC.
pub fn verify(
    tr: &mut Transcript,
    pp: &Params,
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    claims: &[CeClaim],
    proof: &Proof,
) -> Result<CeClaim, Error> {
    validate_inputs_before_rho(s, claims)?;
    let rhos = derive_rhos_for_inputs(tr, pp, claims)?;
    validate_combined_claim(s, mix, &rhos, claims, &proof.combined)?;
    let ok = engine::verify_pi_rlc(pp, s, &rhos, claims, &proof.combined, |zs, cs| mix(zs, cs))?;
    if !ok {
        return Err(Error::VerifyRejected);
    }
    projection_schedule(tr, &rhos, claims, &proof.combined)?;
    Ok(proof.combined.clone())
}

/// Verify PiRLC with the direct PaperExact public-claim computation.
pub(crate) fn verify_paper_exact(
    tr: &mut Transcript,
    pp: &Params,
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    claims: &[CeClaim],
    proof: &Proof,
) -> Result<CeClaim, Error> {
    validate_inputs_before_rho(s, claims)?;
    let rhos = derive_rhos_for_inputs_paper_exact(tr, pp, claims)?;
    if proof.combined.adv != paper_exact_protocol::mixed_adv(mix, &rhos, claims)? {
        return Err(Error::AdvConsistency);
    }
    validate_combined_claim(s, mix, &rhos, claims, &proof.combined)?;
    if !reference_engine::verify_pi_rlc(pp, s, &rhos, claims, &proof.combined, |matrices, commitments| {
        mix(matrices, commitments)
    }) {
        return Err(Error::VerifyRejected);
    }
    paper_exact_protocol::projection_schedule(tr, &rhos, claims, &proof.combined)?;
    Ok(proof.combined.clone())
}

/// Bind the Π_CCS output claims and derive Π_RLC rotation challenges.
///
/// The caller must pass a transcript that is already at the Π_RLC phase, i.e.
/// after Π_CCS has produced and bound its output claims.
pub fn derive_rhos_for_inputs(
    tr: &mut Transcript,
    pp: &Params,
    claims: &[CeClaim],
) -> Result<Vec<neo_reductions::common::RotRho>, Error> {
    let (rhos, _) = derive_rhos_for_inputs_with_sampling_start(tr, pp, claims)?;
    Ok(rhos)
}

fn derive_rhos_for_inputs_paper_exact(
    tr: &mut Transcript,
    pp: &Params,
    claims: &[CeClaim],
) -> Result<Vec<neo_reductions::common::RotRho>, Error> {
    begin_rho_sampling(tr, pp, claims)?;
    reference_engine::sample_rho_n(tr.inner_mut(), pp, claims.len()).map_err(Into::into)
}

/// Bind Π_CCS output claims, capture the exact rho-sampling transcript start,
/// then derive Π_RLC rotation challenges.
///
/// CUDA backends use the returned snapshot to reproduce the same rho matrices
/// on device without treating copied rho buffers as protocol authority.
pub fn derive_rhos_for_inputs_with_sampling_start(
    tr: &mut Transcript,
    pp: &Params,
    claims: &[CeClaim],
) -> Result<(Vec<neo_reductions::common::RotRho>, Poseidon2TranscriptSnapshot), Error> {
    let sampling_start = begin_rho_sampling(tr, pp, claims)?;
    let rhos = engine::sample_rho_n(tr.inner_mut(), pp, claims.len())?;
    Ok((rhos, sampling_start))
}

/// Bind the Π_CCS output claims and return the transcript snapshot from
/// which Π_RLC rho sampling starts.
///
/// CUDA backends use this to let the device transcript own the rho sampling
/// loop while the host transcript remains authoritative for the public claim
/// digest bind.
pub fn begin_rho_sampling(
    tr: &mut Transcript,
    pp: &Params,
    claims: &[CeClaim],
) -> Result<Poseidon2TranscriptSnapshot, Error> {
    if claims.is_empty() {
        return Err(Error::Shape);
    }
    validate_rho_sampling_count(pp, claims.len())?;
    Ok(tr.snapshot())
}

/// Validate the public Π_RLC sampling shape without mutating a transcript.
/// Device-owned fold transcripts call this before binding a resident Π_CCS
/// output digest with the same canonical label and field count.
pub fn validate_rho_sampling_count(pp: &Params, claim_count: usize) -> Result<(), Error> {
    if claim_count == 0 {
        return Err(Error::Shape);
    }
    enforce_rlc_bound(pp, claim_count)
}

/// Projection metadata, shared by `prove` and `verify`: with ρ sampled and
/// the mix fixed, recompute the per-lane quotients and derive β on a copy
/// of the sampler transcript. The caller remains at the Lean PiRLC endpoint.
/// The combined commitment and every quotient precede β. Also discharges the
/// wire-identity obligation (Lemma 5 audit item 1): the mix the
/// quotients divide against must BE the combined commitment, lane for
/// lane — so the projection algebra can never drift from the mixer the
/// fold actually used.
fn projection_schedule(
    tr: &Transcript,
    rhos: &[neo_reductions::common::RotRho],
    inputs: &[CeClaim],
    combined: &CeClaim,
) -> Result<ProjectionSchedule, Error> {
    projection_schedule_with_digest(tr, rhos, inputs, combined, |preimage| {
        Ok(sis_accumulator_digest(PI_RLC_PROJECTION_SIS_CONFIG, preimage)?)
    })
}

fn projection_schedule_with_digest(
    tr: &Transcript,
    rhos: &[neo_reductions::common::RotRho],
    inputs: &[CeClaim],
    combined: &CeClaim,
    compute_digest: impl FnOnce(&[F]) -> Result<[F; 4], Error>,
) -> Result<ProjectionSchedule, Error> {
    #[cfg(feature = "perf-timers")]
    let total_started = std::time::Instant::now();
    let mut binding_preimage = digest::pack_bytes_as_fields(PI_RLC_PROJECTION_BINDING_DOMAIN);
    let rho_coeffs: Vec<[F; D]> = rhos
        .iter()
        .map(|rho| {
            let mat = rho.as_mat();
            core::array::from_fn(|row| mat[(row, 0)])
        })
        .collect();
    let input_cs: Vec<Commitment> = inputs.iter().map(|claim| claim.c.clone()).collect();
    #[cfg(feature = "perf-timers")]
    let commitment_started = std::time::Instant::now();
    let lanes = checked_projection_lanes(&rho_coeffs, &input_cs, &combined.c, None)?;
    append_projection_binding(
        &mut binding_preimage,
        PI_RLC_PROJECTION_COMBINED_C_LABEL,
        &combined.c.data,
    );
    for lane in &lanes {
        append_projection_binding(&mut binding_preimage, PI_RLC_PROJECTION_QUOTIENTS_LABEL, &lane.q);
    }
    #[cfg(feature = "perf-timers")]
    let commitment_elapsed = commitment_started.elapsed();

    #[cfg(feature = "perf-timers")]
    let adv_started = std::time::Instant::now();
    let present = inputs.iter().filter(|claim| claim.adv.is_some()).count();
    let adv_lanes = match (&combined.adv, present) {
        (None, 0) => None,
        (Some(_), 0) | (None, _) => return Err(Error::AdvConsistency),
        (Some(combined_adv), count) if count == inputs.len() => {
            let input_advs: Vec<&LaneCommitments<Commitment>> = inputs
                .iter()
                .map(|claim| claim.adv.as_ref().unwrap())
                .collect();
            let coordinate =
                |select: fn(&LaneCommitments<Commitment>) -> &Commitment,
                 combined_coordinate: &Commitment,
                 name: &'static str|
                 -> Result<Vec<crate::paper::reductions::pi_rlc_circuit::RlcLaneProjection>, Error> {
                    let commitments: Vec<Commitment> = input_advs.iter().map(|adv| select(adv).clone()).collect();
                    checked_projection_lanes(&rho_coeffs, &commitments, combined_coordinate, Some(name))
                };
            let ops = coordinate(|adv| &adv.ops, &combined_adv.ops, "ops")?;
            let is = coordinate(|adv| &adv.is, &combined_adv.is, "is")?;
            let fs = coordinate(|adv| &adv.fs, &combined_adv.fs, "fs")?;

            for leaf in digest::nebula_lane_leaf_digests(combined_adv) {
                append_projection_binding(&mut binding_preimage, PI_RLC_PROJECTION_COMBINED_ADV_LABEL, &leaf);
            }
            for lane in ops.iter().chain(is.iter()).chain(fs.iter()) {
                append_projection_binding(&mut binding_preimage, PI_RLC_PROJECTION_ADV_QUOTIENTS_LABEL, &lane.q);
            }
            Some(LaneCommitments { ops, is, fs })
        }
        (Some(_), count) => {
            return Err(Error::AdvPresence {
                present: count,
                total: inputs.len(),
            })
        }
    };
    #[cfg(feature = "perf-timers")]
    let adv_elapsed = adv_started.elapsed();

    #[cfg(feature = "perf-timers")]
    let x_started = std::time::Instant::now();
    let active_x_cols = crate::paper::relations::superneo_public_x_cols(combined.m_in);
    let mut x_lanes = Vec::with_capacity(active_x_cols);
    for col in 0..active_x_cols {
        let input_coeffs: Vec<[F; D]> = inputs
            .iter()
            .map(|claim| core::array::from_fn(|row| claim.X[(row, col)]))
            .collect();
        let output = core::array::from_fn(|row| combined.X[(row, col)]);
        let lane = checked_auxiliary_projection(&rho_coeffs, &input_coeffs, output, "X", col)?;
        append_projection_binding(&mut binding_preimage, PI_RLC_PROJECTION_COMBINED_X_LABEL, &output);
        append_projection_binding(&mut binding_preimage, PI_RLC_PROJECTION_X_QUOTIENTS_LABEL, &lane.q);
        x_lanes.push(lane);
    }
    #[cfg(feature = "perf-timers")]
    let x_elapsed = x_started.elapsed();

    #[cfg(feature = "perf-timers")]
    let evaluations_started = std::time::Instant::now();
    let mut evaluation_lanes = Vec::with_capacity(combined.eval_a.len() + 1);
    let input_eval_k: Vec<&[K]> = inputs.iter().map(|claim| claim.eval_k.as_slice()).collect();
    let eval_k_lanes = checked_k_vector_projection(&rho_coeffs, &input_eval_k, &combined.eval_k, "Eval_K", 0)?;
    for lane in &eval_k_lanes {
        append_projection_binding(
            &mut binding_preimage,
            PI_RLC_PROJECTION_COMBINED_EVALUATION_LABEL,
            &lane.out,
        );
        append_projection_binding(
            &mut binding_preimage,
            PI_RLC_PROJECTION_EVALUATION_QUOTIENTS_LABEL,
            &lane.q,
        );
    }
    evaluation_lanes.push(eval_k_lanes);
    for matrix in 0..combined.eval_a.len() {
        let input_rows: Vec<&[K]> = inputs
            .iter()
            .map(|claim| claim.eval_a[matrix].as_slice())
            .collect();
        let lanes = checked_k_vector_projection(
            &rho_coeffs,
            &input_rows,
            &combined.eval_a[matrix],
            "Eval_A",
            2 * (matrix + 1),
        )?;
        for lane in &lanes {
            append_projection_binding(
                &mut binding_preimage,
                PI_RLC_PROJECTION_COMBINED_EVALUATION_LABEL,
                &lane.out,
            );
            append_projection_binding(
                &mut binding_preimage,
                PI_RLC_PROJECTION_EVALUATION_QUOTIENTS_LABEL,
                &lane.q,
            );
        }
        evaluation_lanes.push(lanes);
    }
    #[cfg(feature = "perf-timers")]
    let evaluations_elapsed = evaluations_started.elapsed();

    #[cfg(feature = "perf-timers")]
    let binding_started = std::time::Instant::now();
    let binding_digest = compute_digest(&binding_preimage)?;
    let mut projection_transcript = tr.clone();
    projection_transcript.append_fields(PI_RLC_PROJECTION_BINDING_DIGEST_LABEL, &binding_digest);
    let beta = projection_transcript.challenge_fields(PI_RLC_PROJECTION_BETA_LABEL, 2);
    #[cfg(feature = "perf-timers")]
    eprintln!(
        "[pi-rlc/projection] c={:.3}s adv={:.3}s X={:.3}s y={:.3}s sis+beta={:.3}s total={:.3}s identities=c:{} adv:{} X:{} y:{} preimage_fields={}",
        commitment_elapsed.as_secs_f64(),
        adv_elapsed.as_secs_f64(),
        x_elapsed.as_secs_f64(),
        evaluations_elapsed.as_secs_f64(),
        binding_started.elapsed().as_secs_f64(),
        total_started.elapsed().as_secs_f64(),
        lanes.len(),
        adv_lanes.as_ref().map_or(0, |adv| adv.ops.len() + adv.is.len() + adv.fs.len()),
        x_lanes.len(),
        evaluation_lanes.len() * 2,
        binding_preimage.len(),
    );
    Ok(ProjectionSchedule {
        rhos: rho_coeffs,
        q_lanes: lanes.into_iter().map(|lane| lane.q).collect(),
        adv_q_lanes: adv_lanes.map(|lanes| LaneCommitments {
            ops: lanes.ops.into_iter().map(|lane| lane.q).collect(),
            is: lanes.is.into_iter().map(|lane| lane.q).collect(),
            fs: lanes.fs.into_iter().map(|lane| lane.q).collect(),
        }),
        x_q_lanes: x_lanes.into_iter().map(|lane| lane.q).collect(),
        evaluation_q_lanes: evaluation_lanes
            .into_iter()
            .map(|lanes| lanes.map(|lane| lane.q))
            .collect(),
        beta: K::from_coeffs([beta[0], beta[1]]),
    })
}

/// Derive projection metadata for a backend-produced combined claim from
/// the post-rho transcript. This leaves the caller at the Lean phase endpoint;
/// verifiers independently recompute the metadata from the same public inputs.
pub fn bind_backend_projection_schedule(
    tr: &Transcript,
    rhos: &[neo_reductions::common::RotRho],
    inputs: &[CeClaim],
    combined: &CeClaim,
) -> Result<ProjectionSchedule, Error> {
    projection_schedule(tr, rhos, inputs, combined)
}

/// Derive projection metadata without advancing the caller, delegating the final
/// fixed-seed SIS compression to an accelerator. The callback sees the exact
/// preimage used by the native prover; the verifier independently rebuilds
/// and compresses it before accepting the proof.
#[doc(hidden)]
pub fn bind_backend_projection_schedule_with_digest(
    tr: &Transcript,
    rhos: &[neo_reductions::common::RotRho],
    inputs: &[CeClaim],
    combined: &CeClaim,
    compute_digest: impl FnOnce(&[F]) -> Result<[F; 4], Error>,
) -> Result<ProjectionSchedule, Error> {
    projection_schedule_with_digest(tr, rhos, inputs, combined, compute_digest)
}

fn append_projection_binding(preimage: &mut Vec<F>, label: &[u8], fields: &[F]) {
    preimage.extend(digest::pack_bytes_as_fields(label));
    preimage.push(F::from_u64(fields.len() as u64));
    preimage.extend_from_slice(fields);
}

fn checked_auxiliary_projection(
    rho_coeffs: &[[F; D]],
    inputs: &[[F; D]],
    combined: [F; D],
    client: &'static str,
    identity: usize,
) -> Result<crate::paper::reductions::pi_rlc_circuit::RlcLaneProjection, Error> {
    if rho_coeffs.len() != inputs.len() {
        return Err(Error::Shape);
    }
    let pairs: Vec<([F; D], [F; D])> = rho_coeffs
        .iter()
        .copied()
        .zip(inputs.iter().copied())
        .collect();
    let (out, q) = projection_quotient(&pairs);
    if out != combined {
        return Err(Error::AuxiliaryProjectionMixDrift { client, identity });
    }
    Ok(crate::paper::reductions::pi_rlc_circuit::RlcLaneProjection { out, q })
}

fn checked_k_vector_projection(
    rho_coeffs: &[[F; D]],
    inputs: &[&[K]],
    combined: &[K],
    client: &'static str,
    identity_start: usize,
) -> Result<[crate::paper::reductions::pi_rlc_circuit::RlcLaneProjection; 2], Error> {
    if combined.len() < D || inputs.iter().any(|input| input.len() < D) {
        return Err(Error::Shape);
    }
    let input_c0: Vec<[F; D]> = inputs
        .iter()
        .map(|input| core::array::from_fn(|i| input[i].as_coeffs()[0]))
        .collect();
    let input_c1: Vec<[F; D]> = inputs
        .iter()
        .map(|input| core::array::from_fn(|i| input[i].as_coeffs()[1]))
        .collect();
    let combined_c0 = core::array::from_fn(|i| combined[i].as_coeffs()[0]);
    let combined_c1 = core::array::from_fn(|i| combined[i].as_coeffs()[1]);
    Ok([
        checked_auxiliary_projection(rho_coeffs, &input_c0, combined_c0, client, identity_start)?,
        checked_auxiliary_projection(rho_coeffs, &input_c1, combined_c1, client, identity_start + 1)?,
    ])
}

fn checked_projection_lanes(
    rho_coeffs: &[[F; D]],
    inputs: &[Commitment],
    combined: &Commitment,
    coordinate: Option<&'static str>,
) -> Result<Vec<crate::paper::reductions::pi_rlc_circuit::RlcLaneProjection>, Error> {
    let lanes = rlc_projection_quotients(rho_coeffs, inputs)?;
    for (lane_idx, lane) in lanes.iter().enumerate() {
        if combined.data.get(lane_idx * D..(lane_idx + 1) * D) != Some(&lane.out[..]) {
            return match coordinate {
                None => Err(Error::ProjectionMixDrift { lane: lane_idx }),
                Some(coordinate) => Err(Error::AdvProjectionMixDrift {
                    coordinate,
                    lane: lane_idx,
                }),
            };
        }
    }
    Ok(lanes)
}

// ──────────────────────────────────────────────────────────────────────────
// Step bodies
// ──────────────────────────────────────────────────────────────────────────

fn validate_inputs_before_rho(s: &crate::paper::relations::Structure, inputs: &[CeClaim]) -> Result<(), Error> {
    for input in inputs {
        validate_adv_shape(input.adv.as_ref(), input.c.d, input.c.kappa, "input").map_err(Error::AdvShape)?;
        validate_fold_digest_canonical("input", input)?;
        validate_canonical_x_shape_one("input", input)?;
        validate_r_shape_one("input", s, input)?;
        validate_evaluation_shape_one("input", s, input)?;
        validate_evaluation_padding_zero_one("input", input)?;
    }
    Ok(())
}

fn validate_input_shape(claims: &[CeClaim], witnesses: &[&Mat<F>]) -> Result<(), Error> {
    if claims.is_empty() {
        return Err(Error::Shape);
    }
    if claims.len() != witnesses.len() {
        return Err(Error::WitnessMismatch {
            claims: claims.len(),
            witnesses: witnesses.len(),
        });
    }
    Ok(())
}

/// Definition 14 norm bound: `count · T · (b−1) < B`. Fails loudly here
/// so the caller cannot reach the engine with a count that violates it.
fn enforce_rlc_bound(pp: &Params, count: usize) -> Result<(), Error> {
    check_rlc_bound(pp, count, pp.T() as u128).map_err(Into::into)
}

fn validate_combined_claim(
    s: &crate::paper::relations::Structure,
    mix: RlcMixer,
    rhos: &[neo_reductions::common::RotRho],
    inputs: &[CeClaim],
    combined: &CeClaim,
) -> Result<(), Error> {
    validate_adv_shape(combined.adv.as_ref(), combined.c.d, combined.c.kappa, "combined").map_err(Error::AdvShape)?;
    validate_fold_digest_canonical("combined", combined)?;
    validate_canonical_x_shape(inputs, combined)?;
    validate_r_shape(s, inputs, combined)?;
    validate_r_consistency(inputs, combined)?;
    validate_evaluation_shape(s, inputs, combined)?;
    validate_evaluation_padding_zero(inputs, combined)?;
    validate_adv_combination(mix, rhos, inputs, combined)?;
    validate_fold_digest_consistency(inputs, combined)?;
    Ok(())
}

/// the auxiliary-commitment flow (Π_RLC side): the combined claim's `adv` must equal the
/// component-wise ρ-mix of the input tuples — the same public arithmetic
/// that combines `c`, recomputed here on both prove and verify paths.
fn validate_adv_combination(
    mix: RlcMixer,
    rhos: &[neo_reductions::common::RotRho],
    inputs: &[CeClaim],
    combined: &CeClaim,
) -> Result<(), Error> {
    let expected = mixed_adv(mix, rhos, inputs)?;
    if combined.adv != expected {
        return Err(Error::AdvConsistency);
    }
    Ok(())
}

/// Component-wise ρ-mix of the inputs' `adv` tuples (`None` for a plain
/// fold; all-or-nothing presence enforced).
fn mixed_adv(
    mix: RlcMixer,
    rhos: &[neo_reductions::common::RotRho],
    inputs: &[CeClaim],
) -> Result<Option<neo_ccs::LaneCommitments<neo_ajtai::Commitment>>, Error> {
    let rho_mats: Vec<Mat<F>> = rhos.iter().map(|rho| rho.as_mat().clone()).collect();
    let advs: Vec<_> = inputs.iter().map(|claim| claim.adv.clone()).collect();
    crate::paper::relations::mix_adv(mix, &rho_mats, &advs).map_err(|e| Error::AdvPresence {
        present: e.present,
        total: e.total,
    })
}

fn validate_canonical_x_shape(inputs: &[CeClaim], combined: &CeClaim) -> Result<(), Error> {
    for input in inputs {
        validate_canonical_x_shape_one("input", input)?;
    }
    validate_canonical_x_shape_one("combined", combined)?;
    Ok(())
}

fn validate_canonical_x_shape_one(owner: &'static str, claim: &CeClaim) -> Result<(), Error> {
    if !superneo_has_canonical_x_shape(&claim.X, claim.m_in) {
        return Err(Error::NoncanonicalXShape(owner));
    }
    Ok(())
}

fn validate_r_shape(
    s: &crate::paper::relations::Structure,
    inputs: &[CeClaim],
    combined: &CeClaim,
) -> Result<(), Error> {
    for input in inputs {
        validate_r_shape_one("input", s, input)?;
    }
    validate_r_shape_one("combined", s, combined)?;
    Ok(())
}

fn validate_r_shape_one(
    owner: &'static str,
    s: &crate::paper::relations::Structure,
    claim: &CeClaim,
) -> Result<(), Error> {
    let assignment_width = neo_reductions::common::superneo_carrier_width(s.m);
    let expected =
        s.n.max(assignment_width)
            .next_power_of_two()
            .max(2)
            .trailing_zeros() as usize;
    if claim.r.len() != expected {
        return Err(Error::RShape(owner));
    }
    Ok(())
}

fn validate_r_consistency(inputs: &[CeClaim], combined: &CeClaim) -> Result<(), Error> {
    for input in inputs {
        if input.r != combined.r {
            return Err(Error::RConsistency);
        }
    }
    Ok(())
}

fn validate_evaluation_shape(
    s: &crate::paper::relations::Structure,
    inputs: &[CeClaim],
    combined: &CeClaim,
) -> Result<(), Error> {
    for input in inputs {
        validate_evaluation_shape_one("input", s, input)?;
    }
    validate_evaluation_shape_one("combined", s, combined)?;
    Ok(())
}

fn validate_evaluation_shape_one(
    owner: &'static str,
    s: &crate::paper::relations::Structure,
    claim: &CeClaim,
) -> Result<(), Error> {
    let expected_lanes = D.next_power_of_two();
    if claim.eval_k.len() != expected_lanes
        || claim.eval_a.len() != s.t()
        || claim.eval_a.iter().any(|row| row.len() != expected_lanes)
    {
        return Err(Error::EvaluationShape(owner));
    }
    Ok(())
}

fn validate_evaluation_padding_zero(inputs: &[CeClaim], combined: &CeClaim) -> Result<(), Error> {
    for input in inputs {
        validate_evaluation_padding_zero_one("input", input)?;
    }
    validate_evaluation_padding_zero_one("combined", combined)?;
    Ok(())
}

fn validate_evaluation_padding_zero_one(owner: &'static str, claim: &CeClaim) -> Result<(), Error> {
    if claim
        .eval_k
        .iter()
        .skip(D)
        .any(|&lane| lane != K::default())
    {
        return Err(Error::EvaluationPadding(owner));
    }
    for row in &claim.eval_a {
        if row.iter().skip(D).any(|&lane| lane != K::default()) {
            return Err(Error::EvaluationPadding(owner));
        }
    }
    Ok(())
}

fn validate_fold_digest_consistency(inputs: &[CeClaim], combined: &CeClaim) -> Result<(), Error> {
    for input in inputs {
        if input.fold_digest != combined.fold_digest {
            return Err(Error::FoldDigest);
        }
    }
    Ok(())
}

fn validate_fold_digest_canonical(owner: &'static str, claim: &CeClaim) -> Result<(), Error> {
    for (lane, chunk) in claim.fold_digest.chunks_exact(8).enumerate() {
        let value = u64::from_le_bytes(chunk.try_into().expect("fold_digest lanes are 8 bytes"));
        if value >= F::ORDER_U64 {
            return Err(Error::FoldDigestCanonicality { owner, lane });
        }
    }
    Ok(())
}
