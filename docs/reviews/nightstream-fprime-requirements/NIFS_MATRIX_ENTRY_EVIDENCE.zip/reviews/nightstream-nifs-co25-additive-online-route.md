# Additive transcript: online CO25 proof route

Independent analysis by Worker 3 (`/root/conformance_review`), 2026-09-10.
Continuation started at `225b271f`. This note completes the bounded analysis
retained in `nightstream-nifs-co25-additive-online-route-partial.md`.
No protocol, code, dependency, assumption, or model was changed. No build,
test, permutation execution, or security experiment was run.

Primary source: [Chiesa–Orrù, revision 2026-03-27](/tmp/nightstream-chiesa-orru-2025-536.txt),
SHA-256 `66d1cdd23bf6f18f5f93b08aabe6d0339ef79c0f3b58cfddc980966bd57903e7`.
The local full text supplies the source facts below; no web source was needed.
The current `NIFS_FIAT_SHAMIR_MODEL_DECISION.md` and the earlier independent
additive review were also read. Existing source claims in those records are
not extended to a new model here.

## Result and exact obstruction

The printed codec cannot take the proposed encoder. Definition 4.1 fixes
`phi_i : M_P,i -> Sigma^(ell_P(i))`; it has no transcript, state, or permutation
argument. Construction 4.3 uses that fixed function. The proposed
`E_S(b)=S_R+b` depends on previous permutation answers. Thus direct use of the
printed theorem remains unavailable. This is a type and oracle-interface
mismatch, not a proof that additive absorption is insecure. See
[codec](/tmp/nightstream-chiesa-orru-2025-536.txt:1561) and
[construction](/tmp/nightstream-chiesa-orru-2025-536.txt:1578).

A concrete alternative is to prove an additive version of the simulator and
trace conversion. Its new part is small in meaning: replace extraction of
overwrite words with subtraction from the preceding rate state, then prove
an online, cached relabeling law. The capacity graph and several deterministic
CO25 lemmas can support this route. The exact source instantiation, cache
consistency proof, probability bound, and work refinement remain open.

## Deterministic state and schedule equations

Let `S=(S_R,S_C)` have four rate and four capacity lanes. For one padded
four-lane source block `b`, write

```
U = (S_R+b,S_C)
E_S(b) = S_R+b
D_S(e) = e-S_R
p(overwrite(S,E_S(b))) = p(U).
```

For a fixed permutation and initial state, sequential application gives a
triangular inverse on the image of fixed-length block sequences. For typed
messages, inversion must also check the fixed labels, field order, lengths,
and zero padding of each *source call*. Concatenation without those call
boundaries is not the current source program.

The checked current source hashes remain:

- [Spec/Poseidon2.lean](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Poseidon2.lean:106):
  `552706034df8a5f6b59ac6740426a5905b254e195f1205c6762cef1b73a1bbbc`.
- [Lifecycle/Transcript.lean](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/Transcript.lean:26):
  `c202204c451ca96c03e6c27e0320970a6fe4d867e99d486284dcd887f99c6d32`.

The source flushes each absorb chunk with `p`, including a partial chunk.
It outputs the current lane and then calls `p` for each `squeezeF`.
`squeezeK` uses two such calls. Each R digest step outputs four rate lanes
and then calls `p`; each scalar has eight digest steps.

For an absorb run of `a >= 1` padded blocks, let `A` be its actual final
state. A paper execution starting at `(S,0,4)` and absorbing the translated
`4*a` words leaves the final permutation pending. Its squeeze of
`4*(h+1)` words returns

```
A_R || p(A)_R || ... || p^h(A)_R
```

and finishes at `(p^h(A),0,4)`. For C use `h=2`, retain positions 0 and 4
of 12 fields. For R use `h=8`, retain the first 32 of 36 fields. These are
comparison lengths derived from the source's eager final permutation. They
are not changes to the production transcript. Absorb-only, empty, initial,
and terminal boundaries still require their exact event map.

There is a further literal schedule issue in the retained paper revision.
Construction 3.3 performs zero permutation calls when it absorbs exactly
`r` words into a state with `i_A=0`: the last recursive call returns on the
empty word list. A subsequent squeeze of `r` words makes one call. Section 5
instead describes this as `L_P=1` absorbing call and `L_V=1` squeezing call,
and states that their sum is the exact number. For the complete-block
comparison above, direct evaluation of the *printed control flow* gives
`a-1` calls in Absorb and `h+1` in Squeeze, hence `a+h` total. The displayed
`L_P+L_V` gives `a+h+1`. The first squeeze call also completes the last
absorb block. See [cursor code](/tmp/nightstream-chiesa-orru-2025-536.txt:1063)
and [block-count claim](/tmp/nightstream-chiesa-orru-2025-536.txt:1718).

The larger number can bound this trace, but this does not fix BackTrack's
exact offsets. A new schedule proof must derive its edge positions from
the code: the challenge starts at the last absorb input (offset `a-1`), and
the next run starts after `a+h` edges. Do not copy the printed pointer
formula or its security constants as an established source match. This
observation does not, by itself, refute the security theorem.

## What the capacity lemmas supply

Use the same capacity-linked path of full permutation inputs and outputs as
Definitions 5.3 and 5.4. At an absorb position with prior full state `S` and
current permutation input `U`, decode `U_R-S_R`. At a squeeze position check
`U=S`. The capacity equality is already supplied by the path; typed parsing
checks the remaining rate conditions. This decoder makes no oracle calls.

CO25's bad predicate `E` is defined on the trace after removal of redundant
queries. Its capacity-collision and function-consistency tests do not depend
on whether an edge used addition or overwriting. In particular, the printed
deterministic statements say that before `E`:

- Lemma 5.12 excludes a rooted path whose edge was first created by an
  inverse query. A later inverse lookup of an existing edge is redundant.
- Lemma 5.14 gives at most one capacity path to the current input.
- Lemma 5.16 makes the first-occurrence indices along that path increase.

See [bad predicate](/tmp/nightstream-chiesa-orru-2025-536.txt:2258) and
[path lemmas](/tmp/nightstream-chiesa-orru-2025-536.txt:2604).
These are usable deterministic facts about the same graph. The additive
decoder reads only the already-created path and the current query input.
It does not read the current answer. Thus, once the schedule parser is
proved correct, its valid prefix is fixed before the current fresh answer.

This also identifies what happens to a forward edge queried before its
parent path exists. If it later becomes a rooted path, first-occurrence
order fails, which the cited implication places in `E`. An inverse-created
edge that later becomes such a path is covered by the inverse-path result.
They must not be treated as fresh independent challenge queries on replay.

This deterministic transfer does *not* transfer the probability of `E` in a
modified simulator. In particular, the simulator's future squeeze edges in
`Cache_p` are not all present in the visible trace. Their law and later
revelation still need the invariant below.

## An elementary online relabeling lemma

Let two lazy random-oracle tables have physical labels `v` and semantic
labels `u`, respectively, with the same output set for each round. Maintain
a finite partial bijection `T : u <-> v`. At a step that asks for an answer,
require all of the following:

1. The choice of labels and round is determined by the current history,
   before the answer at this new table entry is drawn. It may use previous
   answers and independent private randomness.
2. If either label is already registered, both are registered as the same
   pair. Otherwise neither table has an answer at either label, and adding
   the pair extends `T` injectively.
3. Registered pairs and their cached answers never change. Each retry uses
   that entry. All other visible operations use the same coupled history.

Then the two oracle executions have the same law after relabeling. Proof:
induct on requests. For an old pair, both sides return the same stored value.
For a new pair, both unqueried cells have a fresh uniform law independent of
the history. Draw one value, store it under both labels, and extend `T`.
The other operations preserve equality by the last condition. This proves
the claim for each finite prefix and for a stopping rule read from that
prefix. This is an elementary mathematical proof, not a checked Lean theorem.

The necessary Nightstream specialization is to prove those three conditions
for the trace decoder and the scalar-preimage cache. A semantic label must
contain the round, instance, salt if one is selected, and full prover-message
prefix used by the basic FS oracle. Its physical label is the corresponding
translated prefix. Uniqueness follows by induction only when every earlier
challenge has one fixed cached raw output and successor state. Decoded coins
alone do not determine the rate/capacity state.

Two counterexamples show why weaker statements do not suffice:

- A bijection for every permutation can still inspect a future answer.
  On `{0,1}`, take uniform permutation `p` and `E_p=p^{-1}`. Each `E_p` is
  bijective, but `p(E_p(0))=0` always. The actual causal translation does not
  have this form; the example disproves the pointwise-bijection argument.
- Let a balanced decoder keep the first of two random bits. If a retry keeps
  that decoded bit but resamples the second bit, and the next translated
  label uses the second bit, one semantic retry obtains two physical labels
  with probability one half. Even a zero-bias decoder needs a raw-state cache.

## Required cache and joint sample invariant

For each fresh prefix, cache the semantic/physical labels, decoded challenge,
one raw conditional preimage, and the complete programmed state chain. Keep
the same entries on repeats and rewinds. The permutation table must be a
partial bijection with both input and output lookup. The proof trace must
retain whether a new edge was first learned by a forward or inverse query,
even if the lookup table stores both as the same normalized input/output
pair; Lemma 5.12 uses that first-query direction. Every pending cache
edge must either agree with an existing edge or cause the named bad event;
it must never silently replace an earlier answer. Revelation of a pending
edge must be stable whether the next query is forward or inverse.

For proof bookkeeping, pending edges may be recorded in a generation-ordered
latent trace, separate from the visible query trace. The required lemma is
that projection to the visible trace preserves the additive decoder and
its stable labels until the first collision/inconsistency. A probability
proof must charge all generated states as well as their visible queries.
Adding this bookkeeping to a proof does not permit assuming the cached
states are independent after conditioning on a future no-collision event.
Use a coupling stopped at the first bad event instead. The printed
[cache branches](/tmp/nightstream-chiesa-orru-2025-536.txt:1979) and
[cache-conflict analysis](/tmp/nightstream-chiesa-orru-2025-536.txt:2453)
are the exact owners that require this refinement.

The decoder/preimage law has a direct joint proof. For a surjection
`psi : B -> A`, put `n=|B|`, `m=|A|`, and `f_a=|psi^{-1}(a)|`. Compare

```
P(b,a) = [psi(b)=a]/n
Q(b,a) = [psi(b)=a]/(m*f_a).
TV(P,Q) = (1/2)*sum_a |f_a/n - 1/m|
        = TV(psi(U(B)), U(A)).
```

The equality follows by summing over each fiber. Thus one joint coupling
of the decoded challenge and its raw preimage costs the decoder bias once.
Cache that pair once per fresh prefix; retries incur no new sample or error.
The zero-distance inverse calculation printed in Claim 5.22 is not valid
for unbalanced fibers. This joint calculation gives the needed replacement
without adding two separate bias losses. See
[Claim 5.22](/tmp/nightstream-chiesa-orru-2025-536.txt:2994).

For the C projection of 12 independent fields to positions 0 and 4, every
fiber has size `q^10`. For the R comparison, the four discarded final fields
multiply each 32-field totalized-decoder fiber by `q^4`. They preserve the
existing scalar bias bound `32*delta+u`; the independent 17-scalar comparison
has bound `544*delta+17*u`. These are raw-independent comparison laws, not
claims that actual Poseidon2 outputs are independent. Existing exact fiber
counts and DP tables provide local deterministic counts. A uniform global
inverse and its cache-compatible random law and work remain separate work.

## Remaining source and security obligations

The smallest concrete proof route is:

1. Prove the block parser, pending-permutation relation, and exact event and
   edge schedule for the current C/R/D source. Keep every framed message,
   separate Pad and matrix output fields, all 17 R coordinates in source
   order, and the terminal verifier behavior.
2. Replace BackTrack's rate decoder and the fixed `phi_i^{-1}` calls in
   D2SQuery/D2SAlgo/D2STrace by that parser. Prove the online bijection and
   the visible/latent cache invariant, then apply the elementary lemma.
3. Give a stopped permutation/random-function coupling and derive the bad
   event bound for this exact simulator and its exact query counts. Apply
   the joint decoder law only at fresh cache entries.
4. Refine trace conversion and work to the actual verifier and extraction
   interface. Existing accepted-actual-to-totalized comparison gives the
   same Running output and successful sampler `Batch.finalState`. It does
   not identify failed actual traces with an eager comparison trace.

All needed work is explicit: capacity/input/output lookups; path traversal;
four additions/subtractions per translated/decoded block; fixed-frame and
padding checks; copying all full states and raw preimages; cache lookup and
insertion; exact conditional sampling; and rewinds. A direct trace parser
need not re-query the permutation. An encoder that computes states first
and then replays paper absorption must account for those repeated calls.
For the complete-block comparison, a fresh challenge programs its first
output plus `h` future edges; those allocations and lookups must be charged.
No numerical adversary-query budget or runtime limit is selected here.

Actual initialization remains separate: the source starts at zero and
absorbs its fixed domain and bound statement prefix using the same Poseidon2
as other protocol hashes. CO25 Definition 4.2 uses an independent random
instance hash `h`; Remark 2.1 discusses hashing an instance with the sponge
but does not prove this exact source coupling. Digest self-consistency does
not discharge this obligation.

Finally, ideal-permutation applicability, the state-restoration knowledge
game with the same witness-bearing NIFS output, and concrete Poseidon2
transfer are distinct obligations. The successful-acceptance comparison and
finite sampler laws do not supply them. The paper's scope is classical; its
[Section 1.3](/tmp/nightstream-chiesa-orru-2025-536.txt:303) leaves quantum
superposition-query security open. This note selects no model and grants no
FS or full NIFS conformance approval.
