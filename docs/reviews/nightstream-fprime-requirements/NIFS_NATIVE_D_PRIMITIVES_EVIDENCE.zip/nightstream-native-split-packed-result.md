The base-two splitter now writes directly to the existing column masks. Its signed digit arithmetic and range checks are unchanged. Masks apply within their existing 64-row representation limit; taller matrices and other radices use the prior storage path.

The first focused invocation passed all ten tests in 10.08 seconds, with peak RSS 426,712 KiB. Tests check exact signed integer digits/recomposition, signed k16 endpoints, late-coordinate rejection, the full D×2 carrier tail, wide arithmetic, zero planes, the 64-row mask boundary and taller fallback, and existing other-radix arithmetic. Every test used the required 300-second outer timeout. No full-profile run was made.

Code is frozen and committed at 3f1ea473. Exact hashes and logs are in /tmp/nightstream-native-split-packed-result.json. Constructor copying adds at most one mask pair during final materialization; the selected path never allocates dense F digit planes. The queue was released to root after the pass.
