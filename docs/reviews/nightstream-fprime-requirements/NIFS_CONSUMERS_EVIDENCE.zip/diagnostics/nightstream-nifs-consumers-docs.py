import copy
import json
import re
import subprocess
from pathlib import Path

repo = Path('/home/nicoarq/develop/Nightstream-nifs-proof-links')
docs = repo / 'docs/reviews/nightstream-fprime-requirements'
code = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert code != 'c7c8f1d8' and (repo / 'formal/nightstream-fprime/NightstreamFPrime/Lifecycle/PiRLC/v1_1/StoredSamplerFiberTables.lean').exists()
short = code[:8]
evidence = 'NIFS_CONSUMERS_EVIDENCE.zip'

def insert_before(name, marker, section):
    path = docs / name
    text = path.read_text()
    assert marker in text and section.splitlines()[0] not in text
    path.write_text(text.replace(marker, section + '\n' + marker, 1))

insert_before('NIFS_PROOF_LINKS.md', '## Active criteria', f'''## Complete comparison and stored consumers — `{short}`

The checked source is `{code}`. The full verifier comparison,
its application consumer, one selected PiDEC matrix block, and the stored
scalar-fiber tables add 24 exports. The combined audit contains 402 complete
records with only permitted axioms. Full module builds and static checks pass.
Scoped source reviews, failed checks and the stopped commitment draft are in
[{evidence}]({evidence}).

`TotalizedComparison.accepted_actual_implies_comparison` now proves actual
acceptance implies comparison acceptance with the identical complete running
output. It preserves all 17 ordered ring challenges and the sampler's `Batch.finalState` on
success. Actual sampler shortfall cannot reach acceptance. The comparison
changes only the PiRLC response; all C/D checks remain in the same verifier.
`PerApplicationSamplerComparison.verifierBoundRowsZero_implies_base_or_comparison`
consumes the existing soundness result for arbitrary verifier-bound raw
assignments. It gives either the base case or this exact recursive comparison
at the actual C outgoing state. No cryptographic premise is added.

`PiDECCommitmentMatrixWork.commitmentForms_value` connects the counted source
row to the exact selected retained forms for every one of 1,188 rows. The
selector/A/B/C entry lengths are 1/657/1/42. It constructs the requested row
and two retained blocks and preserves duplicate columns, zero constants and
order. The complete bound is 254,729 named operations per requested row.
`PiDECOrdinarySourceWork.commitmentRow_data` supplies the exact ordered source
terms without changing the source generator. Other row families and the
complete selected matrix dispatcher remain open.

`StoredFiberTables` builds all 33 by 55 paired success/abort cells from stored
target digits. Every entry equals the exact decoder count at that lane and
suffix index. The initial successful count is positive for every 54-symbol
target; each stored sum is below `2^2048`. The construction bound is 425,407
named operations, including actual reads, literals and possible prefix copies;
a stored cell read costs seven. `StoredSamplerFiberTables` connects the initial
counts to the exact complete scalar comparison fiber and proves its positive
size and integer bound. These are finite arithmetic and named-work results,
not a random inverse, bit-time bound or actual Poseidon2 distribution law.

The selected commitment criterion stopped after three further complete
attempts. Diagnostic barriers checked the program and, in the last attempt,
the raw Result equality, but not the row-predicate transport. The complete
clean repair is inactive at
`drafts/NIFS_STORED_COMMITMENT_CHECK_RESULT_TRANSPORT.lean.txt`; no fourth or
narrower check was used. The exact kernel cause is not established. Commitment
and full matrix entry remain selected-checker contracts. The 17:20 protected
review read found unchanged contents in both checkouts. No Rust behavior,
profile, assumption, PaperExact/backend execution or publication changed.
''')

p = docs / 'NIFS_PROOF_LINKS.md'
t = p.read_text().replace(
    'its selected retained-form consumer and other source families remain open.',
    'its selected retained-form consumer is checked; full dispatch and other source families remain open.')
t = t.replace('An efficient inverse sampler, the actual-state joint law,',
    'Stored tables, positivity and full verifier comparison are checked. An efficient inverse sampler, the actual-state joint law,')
p.write_text(t)

insert_before('NIFS_FIAT_SHAMIR_MODEL_DECISION.md', '## Primary proof references and their limits', f'''## Complete verifier comparison and stored fibers — `{short}`

`TotalizedComparison` now connects the actual accepted NIFS verifier to the
comparison verifier, preserving the full output, all 17 ordered challenges
and the sampler's `Batch.finalState`. `PerApplicationSamplerComparison` consumes
the actual fixed-transition relation and arbitrary verifier-bound rows. It
retains the base/recursive distinction and uses the actual C outgoing state.
It adds no security premise. The former inactive comparison draft is now
superseded by this checked complete adapter.

The complete 33 by 55 stored table has exact success/abort values, positive
initial success, and count sums below `2^2048`. The exact totalized scalar
fiber is its success count plus the abort count only for the fallback. The
stored implementation has a 425,407 named-operation construction bound and a
seven-operation cell read. Review corrected omitted literal and wrapper costs
before the successful check. Arithmetic counts do not establish bit-time,
uniform rank generation or random sampling time.

The next obligations are weighted global rank/unrank, an exact uniform-rank
sampler and expected work, joint resampling/cache laws, the 17-scalar product
transport, the additive schedule and initialization, state restoration, and
the fixed-Poseidon2 security transfer. No approved model or numerical security
level follows from the new deterministic link. Checked source is `{code}`;
scoped reviews and complete checks are retained in `{evidence}`.
''')

p = docs / 'NIFS_FIAT_SHAMIR_MODEL_DECISION.md'
t = p.read_text()
start = t.index('The current finite-law source is\n')
end = t.index('\n\nThe contract is', start)
t = t[:start] + f'The current comparison and stored-fiber source is `{code}`.\nIts source, scoped reviews and checks are in [{evidence}]({evidence}).\nEarlier evidence archives remain unchanged.' + t[end:]
p.write_text(t)

p = docs / 'NIFS_CONFORMANCE_REVIEW_773f3d0f.md'
with p.open('a') as f:
    f.write(f'''\n## Scoped consumer review at `{short}`

The coordinator reviewed the complete comparison/application consumer and the
PiDEC retained-form implementation. Worker 1 independently reviewed the
comparison code written by Worker 3; Worker 3 independently reviewed the
stored-fiber implementation written by Worker 2. Their exact source reviews
are in `{evidence}`. These scoped reviews do not replace the historical
full conformance verdict above.

The full comparison preserves C/D checks, exact running output, all 17 ordered
challenges and the sampler's `Batch.finalState`. The application theorem starts with arbitrary
verifier-bound rows and consumes the existing fixed-transition soundness link.
The PiDEC consumer proves the exact 1,188-row block with selector/A/B/C lengths
1/657/1/42 and a 254,729-operation bound. The complete stored decoder tables
prove exact counts, positive scalar fibers and a 425,407-operation bound after
review corrected omitted literal and wrapper charges.

The final audit has 402 complete records, 24 additions, and only permitted
axioms. Static checks pass. The complete selected commitment repair stopped
after its third attempt and remains inactive and unvalidated. No new Rust,
complete NIFS/Stage 1, backend or Fiat–Shamir verdict follows. The 17:20
protected reviews were unchanged. No PaperExact or backend execution ran.
''')

p = docs / 'site/requirements.json'
before = json.loads(p.read_text())
Path('/tmp/nightstream-nifs-consumers-map-before.json').write_text(json.dumps(before, indent=2)+'\n')
x = copy.deepcopy(before)
changed = ['N.security.binding', 'N.security.fiat_shamir', 'N.conformance.owners']
base = 'formal/nightstream-fprime/NightstreamFPrime/'
matrix = [('Export/Stage1/PiDECOrdinarySourceWork.lean', 'commitmentRow_data'),
          *[('Export/Stage1/PiDECCommitmentMatrixWork.lean', s) for s in ['commitmentForms_value', 'commitmentForms_lengths', 'commitmentForms_work_le']]]
comparison = [('Lifecycle/Nifs/TotalizedComparison.lean', 'accepted_actual_implies_comparison'),
              ('Export/Stage1/PerApplicationSamplerComparison.lean', 'verifierBoundRowsZero_implies_base_or_comparison')]
tables = [('Spec/Folding/Nifs/NonInteractive/PiRlcSampler/StoredFiberTables.lean', s) for s in ['build_value', 'build_work_le', 'read_build_value', 'initial_success_pos']]
tables += [('Lifecycle/PiRLC/v1_1/StoredSamplerFiberTables.lean', s) for s in ['fiber_card', 'fiber_positive', 'fiber_lt_twoPow2048']]
remaining = {
 'N.security.binding': 'The selected public and Pad checks, dense row, and key generator are checked. The PiDEC commitment block now has exact counted source and retained-form generation for all 1,188 rows, with full per-row bound 254,729. Full matrix dispatch and other row families remain open. The complete selected commitment checker remains inactive after three further attempts; commitment and matrix-entry contracts are not discharged. Actual producer/checker, inverse choice/conversion, full representation and compiled runtime remain open. The approved same-key MSIS premise is unchanged and has no numerical hardness bound.',
 'N.security.fiat_shamir': 'Scalar and independent-batch comparisons and failure bounds are checked under their stated laws. The full actual verifier and arbitrary verifier-bound assignment now connect to the comparison, preserving the full Running output and all 17 challenges with the sampler Batch.finalState. Complete single-scalar fibers and stored 33×55 table values, positivity and a construction bound of 425,407 named operations are checked. Weighted global rank/unrank, exact uniform-rank sampling and expected work, 17-scalar product and joint cache/query laws remain open. Actual additive Poseidon2 schedule, initialization, state-restoration extraction and concrete-permutation transfer are not established. No model is approved.',
 'N.conformance.owners': 'Scoped independent reviews cover the complete comparison/application consumer and stored decoder tables; coordinator review covers the exact counted PiDEC retained forms. These consume existing semantic owners but do not close full matrix dispatch, selected commitment, actual producer or representation/runtime contracts. The prior native compressed-entry guard and Lean/optimized evidence retain their exact reviewed scope. No new complete Stage1 or Fiat-Shamir verdict follows; PaperExact execution remains pending approval.'
}

def line(path, symbol):
    matches = [i for i,s in enumerate((repo/path).read_text().splitlines(), 1) if re.match(r'(?:theorem|def) '+re.escape(symbol)+r'\b', s)]
    assert len(matches) == 1, (path, symbol, matches)
    return matches[0]

for n in x['nodes']:
    if n['id'] not in changed:
        continue
    additions = matrix if n['id']=='N.security.binding' else comparison+tables if n['id']=='N.security.fiat_shamir' else matrix+comparison+tables
    for path, symbol in additions:
        path = base+path
        assert not any(c.get('path')==path and c.get('symbol')==symbol for c in n['code'])
        n['code'].append({'path':path,'line':line(path,symbol),'symbol':symbol})
    for c in n['code']:
        if c['path'] == base+'Export/Stage1/PiDECOrdinarySourceWork.lean':
            c['line'] = line(c['path'],c['symbol'])
    n['remaining'] = remaining[n['id']]
x['nifs_consumers_update'] = {
 'code_commit':code,'evidence':str((docs/evidence).relative_to(repo)),
 'changed_nodes':changed,
 'scope':'Full verifier/application comparison, one selected counted PiDEC retained block, and complete stored scalar-fiber tables.',
 'validation':'Full targets passed; combined NIFS audit402 records,24 new exports, permitted axioms only; static passed. Scoped source reviews retained.',
 'remaining':'Selected commitment and full matrix dispatch; actual producer/runtime; global random inverse/product/cache and additive Poseidon2 state-restoration/security transfer.',
 'model_approved':False,'paper_exact_executed':False,'website_published':False}
actual = [a['id'] for a,b in zip(x['nodes'],before['nodes']) if a!=b]
assert actual == changed, actual
assert all(tuple(a.get(k) for k in ['proof','connection','rust'])==tuple(b.get(k) for k in ['proof','connection','rust']) for a,b in zip(x['nodes'],before['nodes']))
p.write_text(json.dumps(x,separators=(',',':'),ensure_ascii=False)+'\n')
print(json.dumps({'code':code,'changed_nodes':actual,'unchanged_nodes':len(x['nodes'])-len(actual)}))
