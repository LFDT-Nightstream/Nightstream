# Independent stored fiber-table review

Reviewer: Worker 3, `/root/conformance_review`.
Scope: the complete stored success/abort table and its scalar-fiber consumer.
No source edit, build, test, or sampler execution was run for this review.

The original 410741 clock is not a complete count under the operation
convention already used by SparseWork, RetainedWork, and PiDEC row generation.
It omits scalar literal/constant construction. I reported this necessary
defect to the coordinator and author before the second full check.
The corrected derivation below gives 425407. This review does not report a
passing build or audit for either new module.

## Exact input snapshots

Initial frozen Spec source: `/tmp/nightstream-nifs-stored-fiber-tables.lean`,
529 lines, 27706 bytes, SHA-256
`5623d084e39d6e93b127816d25699d359f051a51ac4e14e0a0198f4af8adc6c8`.
Initial frozen consumer: `/tmp/nightstream-nifs-stored-sampler-fiber-tables.lean`,
55 lines, 2724 bytes, SHA-256
`a96bb90fa216c727cb4a732e76448734dfb3b64e43b31ba10d0a48aeb6fd8ee3`.
All source line references below refer to those snapshots. The author is
repairing the first full check in the active files; those changing bytes are
not covered by an identity claim here.

Semantic sources checked under
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime`:

| Owner | SHA-256 |
| --- | --- |
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldDecoderFiberCount.lean` | `460f2fb881f174eccbf24a904535fc442675a71f68777fda9f94eddfcf8a87d5` |
| `Lifecycle/PiRLC/v1_1/SamplerFiberCount.lean` | `16d07b7a165590720b130e63d430cdb887ab76b3c6d4aa17d04b4cbd501c80cf` |
| `Lifecycle/PiRLC/v1_1/SamplerTotalizedOutputLaw.lean` | `34bc2b7861aa8a09867185d3a08aefcc03f2927d06c01c6a9351caee797dfdc9` |

## Value and event scope

The runtime input is a stored Vector of all 54 raw five-symbol indices.
The output is 33 stored rows of 55 cells, with both success and abort counts
in each cell. The row at level n represents n remaining field lanes. The cell
at position j counts success for the suffix beginning at j and abort for
54-j missing accepts. It includes the zero-lane row and the saturated j=54
column. This is a complete table, with no target-symbol or honest-trace premise.

The recurrence agrees with FieldDecoderFiberCount. The zero-lane base is
(success, abort)=(1,0) for an empty suffix and (0,1) otherwise. A saturated
success count is multiplied by q, leaving every later field unrestricted.
With one symbol left, a low candidate that completes the output leaves the
high candidate unrestricted. With at least two symbols left, the four ordered
pair classes reduce to the three stored terms, since the two one-accept
weights agree. Abort terms permit all accepted values and depend only on
the number still needed. At need one, only the reject/reject branch can abort.

The success bonuses test raw alphabet index zero, which denotes centered -2.
They do not test centered zero. The abort two-accept weight includes the extra
Goldilocks preimage of raw pair (0,0). Both low/high order and the complete
unused suffix are preserved. No new profile, sampling distribution, or
cryptographic premise appears in the declarations.

The positivity arguments at Spec lines 68-112 are valid mathematical routes:
a target of length at most 2*n can use positive two-accept rectangles, and
the all-reject rectangle gives positive abort count when at least one accept
is needed. Thus the selected 54-symbol target fits in 32 fields. The sum of
matching-success and abort counts is bounded by q^n through disjoint events.
The selected count is below 2^2048 because q<2^64 and n<=32. These statements
still require the full checked implementation; no new proof check was run here.

The consumer at lines 18-53 targets the existing complete scalar decoder.
Its exact formula is storedSuccess + [target.get=fallback]*storedAbort.
All aborting windows go to the fallback, independently of accepted prefix
digits. The function-valued equality is in a theorem statement, not in a
claimed counted program. Positivity and the size bound concern that exact
cardinality. No executable fallback comparison is hidden in the build clock.

## Necessary clock corrections

The established convention counts dispatch, predecessor extraction, calls,
value/index projections, scalar literals, arithmetic, and data constructors.
Passing an existing local value is part of the call. Proof terms, clock-field
reads, and clock arithmetic are excluded. Arithmetic is one named operation
on a Nat value, not one machine instruction or a constant-time bit operation.

| Source owner | Old count | Required count for the unchanged value body |
| --- | ---: | ---: |
| makeWeights, lines 138-143 | 13 | 25 |
| baseCell, lines 155-156 | 5 | 8 |
| stepCell saturated, lines 162-166 | 9 | 12 |
| stepCell final-one, lines 162-177 | 26 | 31 |
| stepCell live-two, lines 162-188 | 45 | 53 |
| rowPrefix empty, line 304 | capacity+4 | capacity+5 |
| rowPrefix step, lines 305-310 | capacity+2*prefix+13 | unchanged |
| baseRow wrapper, lines 345-347 | 3 | 4 |
| nextRow wrapper, lines 349-351 | 4 | 5 |
| tablePrefix empty, line 384 | capacity+4 | capacity+5 |
| tablePrefix successor, lines 385-393 | capacity+2*prefix+18 | capacity+2*prefix+20 |
| build wrapper, lines 450-453 | 6 | 7 |
| stored read, lines 506-510 | 7 | unchanged |

makeWeights has eleven arithmetic operations, two result/data constructors,
and twelve literal/constant occurrences. The latter are five occurrences in
the reject/success/abort temporary values, three in the finishOne/successOne
expressions, and four in the remaining weight expressions. baseCell needs the
coefficientCount constant and both returned Nat literals in addition to its
five other operations. The three stepCell corrections add respectively
three, five, and eight literal occurrences. The live-two branch adds two
coefficientCount constants, the j+1 and j+2 constants, and two literals for
each zero flag (comparison zero and the selected result).

rowPrefix's thirteen fixed step operations already cover dispatch/descent,
the two calls, Fin construction, three value/array projections, Vector/Result
construction, and the fixed part of its push allowance. baseRow additionally
needs its rowWidth argument literal. nextRow needs that literal plus the
captured closure, call, value read, and Result. tablePrefix's recursive branch
additionally needs the count=0 and count-1 literals; its exact first-branch
fixed cost is 16, covered by the same derived maximum 20. build additionally
needs its levelCount argument literal. Its complete seven operations are
Unit construction, makeWeights call, weights.value, levelCount, tablePrefix
call, result.value, and Result construction.

The coordinator fixed the allocation convention explicitly: count
Array.emptyWithCapacity once as the named allocation primitive, with a
reserved-slot allowance. Its base cost is dispatch, capacity literal,
allocation primitive, Vector, and Result, plus capacity. Do not add a second
allocator operation. The push bound retains its stated capacity+2*prefix+3
allowance for the primitive, possible allocation, copied-entry reads/writes,
and appended write. This is not a claim about compiler or allocator instructions.

With width=55, levels=33, and the maximum cell cost 53, the formulas give:

- rowPrefixBound(55) = 55+5 + 55*(53+3*55+13) = 12765;
- rowWork = 12765+5 = 12770;
- tablePrefixBound(33) = 33+5 + 33*(12770+3*33+20) = 425375;
- buildWork = 25+425375+7 = 425407.

The final read costs seven separately. Calling build/read and converting an
external function-valued scalar into the stored input remain caller work.
The corrected counters and these exact formulas must appear in frozen source
before the old count defect can be marked resolved.

## Storage and remaining limits

Each cell reads existing arrays directly; the semantic List.ofFn/drop views
occur only in proofs. The row and table builders advance explicit Nat indices.
They do not form a chain of reindexed closures. The private row callback is
instantiated only with baseCell or the concrete stepCell closure, whose bound
is discharged locally; there is no public unit-cost callback premise.

Every push may copy the whole existing prefix under the stated allowance.
Table copies move stored row references; they do not traverse every Nat in
those rows. Row copies move cell references. No uniqueness, compiler hoisting,
or in-place mutation assumption is needed for this named allowance. Both
the target and all previous rows remain stored. Weights are computed once
in the explicit build let before table construction.

The proved count/weight bounds are the correct basis for a later bit-cost
link. The table entries can require up to 2048 bits, so treating Nat arithmetic
as one named operation does not prove constant machine time. Intermediate
products and sums also need their explicit implementation-cost refinement
before a bit-time or gas claim. No random rank generator, global weighted
rank/unrank, uniform random inverse, joint cache/resampling law, actual
Poseidon2 law, or Fiat–Shamir applicability follows from these table results.

The recorded full first check failed in the Spec owner at
`/tmp/nightstream-nifs-stored-fiber-tables-1.log`; it has no passing full
consumer result. Proof elaboration failures and the identified count error
must remain recorded. This source review is not a replacement for the
coordinator's full check and axiom audit.

## Frozen round-2 source delta

I compared the full active Spec file with the original frozen snapshot and
checked the exact consumer bytes. The active paths are under the worktree's
`formal/nightstream-fprime/NightstreamFPrime` directory:

- `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/StoredFiberTables.lean`:
  548 lines, 29118 bytes, SHA-256
  `6f483f570668325ce67fd41adeebc252eab73e5cb0b7e35b0bd4b049d5d452f8`;
- `Lifecycle/PiRLC/v1_1/StoredSamplerFiberTables.lean`:
  55 lines, 2724 bytes, SHA-256
  `a96bb90fa216c727cb4a732e76448734dfb3b64e43b31ba10d0a48aeb6fd8ee3`.

The identified count defect is corrected in these source bytes. makeWeights
uses 25, baseCell 8, and stepCell 12/31/53. rowPrefix uses capacity+5 at zero
and the unchanged capacity+2*prefix+13 step. baseRow/nextRow add 4/5.
tablePrefix uses capacity+5 at zero and capacity+2*prefix+20 at each step.
build adds seven; read remains seven. The bound definitions at lines 344,
388, 436, and 474 give exactly 12765, 12770, 425375, and 425407 as derived
above. The empty-array primitive and reserved-slot convention is now explicit
at lines 308-316. All count corrections also propagate into their work proofs.

No value/control-flow change was introduced by the delta. New rowSize and
digitsSize facts and explicit array index proofs are erased proof terms.
They do not add a scan, runtime bounds check, changed index, or new branch.
The other changes repair proof elaboration and move rowPrefix opacity before
its parent proofs. The same direct indexed reads, row/table construction,
recurrence weights, zero flags, and ordered data are retained.

All fifteen public claims keep their original scope: twelve Spec theorems
(count_sum_le, successCount_pos, abortCount_pos,
field_window_count_lt_twoPow2048, build_value, build_work_le, build_sum_le,
build_sum_lt_twoPow2048, recurrence_weights_le_modulus, read_work,
read_build_value, initial_success_pos) and the three unchanged consumer
theorems (fiber_card, fiber_positive, fiber_lt_twoPow2048). No new callback,
sampling, invertibility, or model premise was added.

Result for this frozen delta: no further value or named-count defect found.
The second full build was still running when this addendum was written.
Its terminal result and the axiom audit remain separate evidence. The
original failed-check record, original undercount finding, and all runtime
and security limits above remain in force.

The subsequent round-2 terminal record is a failure, not a pass. I read
`/tmp/nightstream-nifs-stored-fiber-tables-2.log`: the only errors are the
stepCell_work tactic failures at lines 304/305 (an unreduced record projection
containing free variables before decide, and a strict dsimp with no progress).
The earlier value/prefix proof errors do not recur. The coordinator reports
terminal exit 1. A final proof repair remains pending; this result does not
change the reviewed runtime/count delta or validate the complete criterion.

## Frozen round-3 proof repair

The final Spec source has 552 lines, 29211 bytes, SHA-256
`12a3abb502c9d4f0a4e0aabab8cc20de3b3ae55082eb7c82cdf9c37b4c31322d`.
I compared it with the retained round-2 copy, whose hash matches the reviewed
`6f483f57…` bytes. The sole delta is inside private stepCell_work: each branch
changes the goal to the explicit Nat inequality 12<=53, 31<=53, or 53<=53
before decide. The unnecessary strict dsimp is removed. No function body,
clock, theorem statement, parameter, or import changes. The consumer remains
byte-identical at `a96bb90f…`. The 425407/read-seven count review therefore
applies to these final bytes. The full third build is pending at this point.

## Final checked status

I read the terminal third-check record in
`/tmp/nightstream-nifs-stored-fiber-tables-3.log`. The complete target
`NightstreamFPrime.Lifecycle.PiRLC.v1_1.StoredSamplerFiberTables` passed:
2434 dependency jobs, consumer module 1.4 seconds, wrapper 35 seconds,
terminal exit 0. The log SHA-256 is
`32ee51470ff0bfe29d5a985577f6eddbc3fe8861b76548cf1dae65bdbd0263b4`.
The Spec and consumer hashes remain exactly those in the round-3 addendum.

The subsequent combined audit has 402 complete records, including all fifteen
exports of these two modules, in exact registration order and with only
propext, Classical.choice, and Quot.sound. I parsed that full record
independently. The source cut is `286dc71a543d28d52e430e9466ab5cecea01de7d`;
its committed bytes match the reviewed final Spec/consumer. The complete
milestone record is `/tmp/nightstream-nifs-consumers-milestone-review.md`.
This closes the local value/named-count validation for the tables. It does
not expand the machine-runtime, random-inverse, or Fiat–Shamir scope above.
