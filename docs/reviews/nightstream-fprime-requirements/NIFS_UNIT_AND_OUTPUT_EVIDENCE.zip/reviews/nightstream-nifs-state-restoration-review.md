# State-restoration interface check

Coordinator source review, 2026-09-10. This is an interface analysis, not a
new Lean premise or an approved security model.

The target is the classical rewinding game in Chiesa–Orrù Definition 3.16.
Its prover can select a statement and a complete prover-message prefix on
each query, revisit old queries, and return a final statement after seeing
other replies. A repeated prefix query uses its cached reply. The extractor
receives the final transcript, query trace and black-box prover, and must
bound both witness failure on accepting runs and expected extraction work.
The full source is ePrint 2025/536, revision 2026-03-27, Definitions 3.12–3.16.

The current selected extraction owners require different interfaces:

| Existing owner | Checked input/law | Missing state-restoration construction |
|---|---|---|
| `CausalExecution.Prover` and `run` | One fixed causal C strategy. A round message uses alpha, gamma and earlier round challenges; final output can use the complete C challenge stream. | Convert an adaptive prefix-query prover into these causal calls while preserving the selected statement and all prior replies. The selected statement cannot be moved into an independent initial context merely because its value has a type. |
| `StrongExtraction.probability_and_expected_work` | The stated context/tape PMFs, uniform C verifier mean, actual one-call refinement, actual witness checker and proved work bounds. | Prove the law of each simulated call, its relation to the selected accepting transcript, and total query/rewind work. A distribution-only coupling table is not an executable prover simulation. |
| `PaperWeakOracle.run` and `law` | A captured post-C suffix called at an explicit complete R vector, with the stated private-tape PMF. Its joint output/work law retains aborts. | Supply this call interface from the same cached prefix oracle. One-coordinate changes must preserve all other R coordinates even though the actual sponge state is chained. Fresh oracle replies and repeated replies must follow their separate laws. |
| `PaperWeakExtraction.FinalOutputSuccess` and `run_return_iff` | Accepted D messages and valid witnesses for this invocation's exact 16 computed children. | Define a witness-bearing reduction game, then prove that its final-output event is this event. Public NIFS acceptance alone does not supply child witnesses. |
| `PaperCompositionProbability.source_success_ge_from_weak` | A pointwise weak-success inequality under the existing sequential mean. It combines the weak loss with the C disagreement/test loss. | Obtain that pointwise law from the state-restoration extractor; retain the same commitment tuple and the same output witnesses. An adaptive search success probability is not the sequential mean by definition. |

Source paths are under
`formal/nightstream-fprime/NightstreamFPrime/Spec/Folding/`, except the
selected `Lifecycle/Nifs/StrongExtraction.lean` entry. The corrected local
SuperNeo paper, Appendix B.3, defines the fixed post-C context, the actual
suffix call, and the one-coordinate forks. It does not supply the adaptive
prefix-query construction above.

One possible relation-level route is to include the final child witnesses
in the analysis game's final prover output and check the exact child
relation there. This is already the event used by `PaperWeakSuffix.Correct`.
It would require an explicit terminal-message map to the paper's IP and its
noninteractive construction. It must preserve every earlier query and the
actual public output. This review does not add those witnesses to the
published NIFS proof, assert they are publicly available, or declare that
terminal map proved.

The needed theorem must quantify over every classical adversary and its
symbolic query/work bounds. Its conclusion must use the actual selected
source witness relation, with the existing named binding alternative. The
interactive inequalities become inputs to that theorem only after the
above program and law refinements are proved. The interactive expected-call
bound 18 is not a per-run bound on prefix, permutation or rewind queries.
No new numerical query budget, retry limit or cryptographic premise was
selected in this analysis.
