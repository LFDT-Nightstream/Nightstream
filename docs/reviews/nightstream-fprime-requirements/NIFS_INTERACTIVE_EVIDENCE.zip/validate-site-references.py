from pathlib import Path
import json, subprocess
site=Path.cwd()
data=json.loads((site/"requirements.json").read_text())
root=site.parents[3]
p="docs/reviews/nightstream-fprime-requirements/site/requirements.json"
before=json.loads(subprocess.check_output(["git","show","861a5b8c272e6edb204623524219caf49027b303:"+p],cwd=root))
old={n["id"]:n for n in before["nodes"]}
changed=set(data["nifs_top_three_update"]["requested_records"])
assert data["commit"] == "77713c1e711c7b1bca0a1b0e5941c2ac94f0656e"
for n in data["nodes"]:
 if n["id"] not in changed:
  assert n == old[n["id"]], n["id"]
 else:
  for ref in n["code"]:
   source=subprocess.check_output(["git","show",data["commit"]+":"+ref["path"]],cwd=root,text=True).splitlines()
   assert 0 < ref["line"] <= len(source), ref
   if ref["path"].endswith(".lean") and ref["symbol"].replace("_", "").replace(".", "").isalnum():
    assert ref["symbol"].split(".")[-1] in source[ref["line"]-1], ref
for key in before:
 if key not in ("nodes","commit","source_note"):
  assert data[key] == before[key], key
print("All earlier nodes and update records preserved; eight NIFS references match the reviewed code commit.")
