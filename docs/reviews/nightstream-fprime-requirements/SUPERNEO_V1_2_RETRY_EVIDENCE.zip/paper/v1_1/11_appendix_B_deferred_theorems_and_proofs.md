# B Deferred theorems and proofs

## B.1 Proof of Composition Theorem (Theorem 12)

*Proof.* Consider an arbitrary expected polynomial-time adversary  $(\mathcal{A}, \mathcal{P}^*)$  for the composition  $\Pi := \Pi_2 \circ \Pi_1$  with success probability  $\epsilon(\mathcal{A}, \mathcal{P}^*) \geq 1/\text{poly}(\lambda)$ . Without loss of generality, the adversary  $\mathcal{P}^*$  can be split into two adversaries  $(\mathcal{P}_1^*, \mathcal{P}_2^*)$  such that given  $\text{pp} \leftarrow \mathcal{G}(1^\lambda, \text{sz})$ ,  $(\mathbf{s}, u_1, \text{st}_1) \leftarrow \mathcal{A}(\text{pp})$ , and  $(\text{pk}, \text{vk}) \leftarrow \mathcal{K}(\text{pp}, \mathbf{s})$ ,

- $\langle \mathcal{P}_1^*, \mathcal{V}_1 \rangle((\text{pk}, \text{vk}), u_1, \text{st}_1) \rightarrow (u_2, \text{st}_2)$
- $\langle \mathcal{P}_2^*, \mathcal{V}_2 \rangle((\text{pk}, \text{vk}), u_2, \text{st}_2) \rightarrow (u_3, w_3)$

Furthermore, we assume that  $\mathcal{A}$  outputs  $\text{st}_1$  which contains  $(\mathbf{s}, \text{pp}, u_1)$ ; otherwise, we could trivially construct an adversary  $\mathcal{A}'$  with an identical distribution of prior outputs that does so. First, we construct an adversary  $\mathcal{A}_2 := (\mathcal{B}_2, \mathcal{B}'_2)$  for  $\Pi_2$ :

```

 $\mathcal{B}_2(\text{pp}) \rightarrow (\mathbf{s}, \text{st}_1)$  :
  1.  $(\mathbf{s}, u_1, \text{st}_1) \leftarrow \mathcal{A}(\text{pp})$ .
  2. Output  $(\mathbf{s}, \text{st}_1)$ .

 $\mathcal{B}'_2(\text{st}_1) \rightarrow (u_2, \text{st}_2)$  :
  1. Parse  $\text{st}_1$  to obtain  $(\mathbf{s}, \text{pp}, u_1)$ .
  2.  $(\text{pk}, \text{vk}) \leftarrow \mathcal{K}(\text{pp}, \mathbf{s})$ .
  3. Simulate  $(u_2, \text{st}_2) \leftarrow \langle \mathcal{P}_1^*, \mathcal{V}_1 \rangle((\text{pk}, \text{vk}), u_1, \text{st}_1)$ .
  4. Output  $(u_2, \text{st}_2)$ .

 $\mathcal{A}_2(\text{pp}) \rightarrow (\mathbf{s}, u_2, \text{st}_2)$  :
  1.  $(\mathbf{s}, \text{st}_1) \leftarrow \mathcal{B}_2(\text{pp})$ .
  2.  $(u_2, \text{st}_2) \leftarrow \mathcal{B}'_2(\text{st}_1)$ .
  3. Output  $(\mathbf{s}, u_2, \text{st}_2)$ .
  
```

The adversary  $\mathcal{A}_2$  runs in expected polynomial time since  $\mathcal{A}$  and  $\mathcal{P}_1^*$  do, and all remaining computations run in polynomial time. Observe that, by construction, the success probability  $\epsilon(\mathcal{A}_2, \mathcal{P}_2^*)$  of adversary  $(\mathcal{A}_2, \mathcal{P}_2^*)$  for  $\Pi_2$  is equal to the success probability  $\epsilon(\mathcal{A}, \mathcal{P}^*)$  of adversary  $(\mathcal{A}, \mathcal{P}^*)$  for  $\Pi$ . By construction,  $\mathcal{B}_2$  samples the input and state according to  $\mathcal{A}$ , while each invocation of  $\mathcal{B}'_2$  simulates one execution of  $\langle \mathcal{P}_1^*, \mathcal{V}_1 \rangle$  on that input and state. Thus, the distribution of  $(u_2, u'_2)$  in the following experiment is identical to that in condition (i) for  $\Pi_1$  with respect to adversary  $(\mathcal{A}, \mathcal{P}_1^*)$ . By assumption,  $\Pi_1$  is a strong interactive reduction (Definition 17). As such, it satisfies condition (i); thus, we must have

$$\Pr \left[ \begin{array}{c} u_2, u'_2 \neq \perp \\ \Downarrow \\ \phi(u_2) = \phi(u'_2) \end{array} \middle| \begin{array}{l} \text{pp} \leftarrow \mathcal{G}(1^\lambda, \text{sz}) \\ (\mathbf{s}, \text{st}_1) \leftarrow \mathcal{B}_2(\text{pp}) \\ (u_2, \text{st}_2) \leftarrow \mathcal{B}'_2(\text{st}_1) \\ (u'_2, \text{st}'_2) \leftarrow \mathcal{B}'_2(\text{st}_1) \end{array} \right] = 1, \quad (1)$$

By assumption,  $\Pi_2$  is a weak interactive reduction (Definition 16). Thus, with respect to adversary  $(\mathcal{A}_2, \mathcal{P}_2^*)$ , there exists an expected polynomial-time extractor  $\mathcal{E}_2$  such that, since  $\epsilon(\mathcal{A}_2, \mathcal{P}_2^*) = \epsilon(\mathcal{A}, \mathcal{P}^*) \geq 1/\text{poly}(\lambda)$ ,

$$\Pr \left[ (\text{pp}, \mathbf{s}, u_2, w_2) \in \mathcal{R}'_2 \middle| \begin{array}{l} \text{pp} \leftarrow \mathcal{G}(1^\lambda, \text{sz}) \\ (\mathbf{s}, u_2, \text{st}_2) \leftarrow \mathcal{A}_2(\text{pp}) \\ (\text{pk}, \text{vk}) \leftarrow \mathcal{K}(\text{pp}, \mathbf{s}) \\ w_2 \leftarrow \mathcal{E}_2(\text{pp}, \mathbf{s}, u_2, \text{st}_2) \end{array} \right] \geq \epsilon(\mathcal{A}, \mathcal{P}^*) - \text{negl}(\lambda) \quad (2)$$

Moreover, since  $\mathcal{A}_2 = (\mathcal{B}_2, \mathcal{B}'_2)$  satisfies (1), the same extractor satisfies

$$\Pr \left[ \begin{array}{c} w_2, w'_2 \neq \perp \\ \wedge w_2 \neq w'_2 \end{array} \middle| \begin{array}{l} \mathbf{pp} \leftarrow \mathcal{G}(1^\lambda, \mathbf{sz}) \\ (\mathbf{s}, \mathbf{st}_1) \leftarrow \mathcal{B}_2(\mathbf{pp}) \\ (u_2, \mathbf{st}_2) \leftarrow \mathcal{B}'_2(\mathbf{st}_1) \\ w_2 \leftarrow \mathcal{E}_2(\mathbf{pp}, \mathbf{s}, u_2, \mathbf{st}_2) \\ (u'_2, \mathbf{st}'_2) \leftarrow \mathcal{B}'_2(\mathbf{st}_1) \\ w'_2 \leftarrow \mathcal{E}_2(\mathbf{pp}, \mathbf{s}, u'_2, \mathbf{st}'_2) \end{array} \right] \leq \text{negl}(\lambda) \quad (3)$$

Next, we will construct an adversary  $\mathcal{P}_1^{**}$  for  $\Pi_1$ . Recall that  $\mathcal{V}_1$  is the verifier of  $\Pi_1$ . During the interaction  $\langle \mathcal{P}_1^{**}, \mathcal{V}_1 \rangle$ ,  $\mathcal{P}_1^{**}$  internally runs  $\mathcal{P}_1^*$  and relays messages between  $\mathcal{P}_1^*$  and  $\mathcal{V}_1$ :

$\mathcal{P}_1^{**}(\mathbf{pk}, u_1, \mathbf{st}_1) \rightarrow w_2$  :

1. Parse  $\mathbf{st}_1$  to obtain  $(\mathbf{s}, \mathbf{pp})$ .
2.  $(\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s})$ .
3. Run  $\mathcal{P}_1^*(\mathbf{pk}, u_1, \mathbf{st}_1)$ , relaying each message from  $\mathcal{V}_1$  to  $\mathcal{P}_1^*$  and each response from  $\mathcal{P}_1^*$  back to  $\mathcal{V}_1$ . Let  $\mathbf{tr}$  be the resulting transcript and  $\mathbf{st}_2$  the final state of  $\mathcal{P}_1^*$ .
4. Since  $\Pi_1$  is public coin, compute the verifier's output  $u_2$  by emulating  $\mathcal{V}_1(\mathbf{vk}, u_1)$  on  $\mathbf{tr}$ .
5.  $w_2 \leftarrow \mathcal{E}_2(\mathbf{pp}, \mathbf{s}, u_2, \mathbf{st}_2)$ .
6. Output  $w_2$ .

The adversary  $\mathcal{P}_1^{**}$  runs in expected polynomial time since  $\mathcal{P}_1^*$  and  $\mathcal{E}_2$  do, and all remaining computations run in polynomial time. Conditioned on  $(\mathbf{pp}, \mathbf{s}, u_1, \mathbf{st}_1)$ ,  $\mathcal{B}'_2(\mathbf{st}_1)$  and the interaction  $\langle \mathcal{P}_1^{**}, \mathcal{V}_1 \rangle$  generate  $(u_2, \mathbf{st}_2)$  according to the same distribution: both run  $\mathcal{P}_1^*$  against  $\mathcal{V}_1$  using the same keys produced by the deterministic encoder. Moreover, since  $\Pi_1$  is public coin,  $\mathcal{P}_1^{**}$  can reconstruct from  $\mathbf{tr}$  the output  $u_2$  produced by  $\mathcal{V}_1$ . Hence, the event in (2) is exactly the event defining  $\epsilon'(\mathcal{A}, \mathcal{P}_1^{**})$ , and therefore  $\epsilon'(\mathcal{A}, \mathcal{P}_1^{**}) \geq \epsilon(\mathcal{A}, \mathcal{P}^*) - \text{negl}(\lambda) \geq 1/\text{poly}(\lambda)$ . Furthermore, two independent executions of  $\langle \mathcal{P}_1^{**}, \mathcal{V}_1 \rangle$  correspond to two independent invocations of  $\mathcal{B}'_2$  followed by  $\mathcal{E}_2$ . Thus, the following experiment has the same distribution as the experiment in (3); by (3), we must have

$$\Pr \left[ \begin{array}{c} w_2, w'_2 \neq \perp \\ \wedge \\ w_2 \neq w'_2 \end{array} \middle| \begin{array}{l} \mathbf{pp} \leftarrow \mathcal{G}(1^\lambda, \mathbf{sz}) \\ (\mathbf{s}, u_1, \mathbf{st}_1) \leftarrow \mathcal{A}(\mathbf{pp}) \\ (\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s}) \\ (u_2, w_2) \leftarrow \langle \mathcal{P}_1^{**}, \mathcal{V}_1 \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st}_1) \\ (u'_2, w'_2) \leftarrow \langle \mathcal{P}_1^{**}, \mathcal{V}_1 \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st}_1) \end{array} \right] \leq \text{negl}(\lambda) \quad (4)$$

Thus, we have by (4), the bound  $\epsilon'(\mathcal{A}, \mathcal{P}_1^{**}) \geq 1/\text{poly}(\lambda)$  established above, and condition (ii) of Definition 17 for  $\Pi_1$  that there exists an expected polynomial-time extractor  $\mathcal{E}_1$  such that

$$\Pr \left[ (\mathbf{pp}, \mathbf{s}, u_1, w_1) \in \mathcal{R}_1 \middle| \begin{array}{l} \mathbf{pp} \leftarrow \mathcal{G}(1^\lambda, \mathbf{sz}) \\ (\mathbf{s}, u_1, \mathbf{st}_1) \leftarrow \mathcal{A}(\mathbf{pp}) \\ (\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s}) \\ w_1 \leftarrow \mathcal{E}_1(\mathbf{pp}, \mathbf{s}, u_1, \mathbf{st}_1) \end{array} \right] \geq \epsilon'(\mathcal{A}, \mathcal{P}_1^{**}) - \text{negl}(\lambda) \quad (5)$$

By (2) and the preceding argument,

$$\epsilon'(\mathcal{A}, \mathcal{P}_1^{**}) \geq \epsilon(\mathcal{A}, \mathcal{P}^*) - \text{negl}(\lambda).$$

Therefore, combining these inequalities and absorbing the sum of the two negligible functions into  $\text{negl}(\lambda)$ , we have

$$\Pr \left[ (\mathbf{pp}, \mathbf{s}, u_1, w_1) \in \mathcal{R}_1 \middle| \begin{array}{l} \mathbf{pp} \leftarrow \mathcal{G}(1^\lambda, \mathbf{sz}) \\ (\mathbf{s}, u_1, \mathbf{st}_1) \leftarrow \mathcal{A}(\mathbf{pp}) \\ (\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s}) \\ w_1 \leftarrow \mathcal{E}_1(\mathbf{pp}, \mathbf{s}, u_1, \mathbf{st}_1) \end{array} \right] \geq \epsilon(\mathcal{A}, \mathcal{P}^*) - \text{negl}(\lambda).$$

In conclusion, for the arbitrary adversary  $(\mathcal{A}, \mathcal{P}^*)$  fixed above, set  $\mathcal{E} := \mathcal{E}_1$ . The preceding inequality shows that  $\mathcal{E}$  extracts a valid witness for  $\mathcal{R}_1$  with probability at least  $\epsilon(\mathcal{A}, \mathcal{P}^*) - \text{negl}(\lambda)$ . Thus,  $\Pi := \Pi_2 \circ \Pi_1$  is knowledge sound. Since  $\Pi_1$  and  $\Pi_2$  are complete and public coin, their sequential composition  $\Pi$  is also complete and public coin. Therefore,  $\Pi$  is a reduction of knowledge (Definition 9).  $\square$

## B.2 Proofs for $\Pi_{\text{CCS}}$

We first provide a lemma that will be helpful for both the security and completeness of the interactive reduction.

**Lemma 9.** *Consider the following arbitrary items:*

$$\begin{aligned} &\text{structure } \mathbf{s}, \quad \text{vectors } z_1, \dots, z_{K+k} \in \mathbb{L}^{n_L}, \\ &\text{point } r \in \mathbb{K}^{\log m}, \quad \text{evaluations } (y_i \in \mathbb{R}_{\mathbb{K}}, \{y_{i,j} \in \mathbb{R}_{\mathbb{A}}\}_{j \in [t]})_{i=K+1}^{K+k} \end{aligned}$$

Recall from Definition 20 the matrix  $\text{Pad} \in \mathbb{F}^{m \times n_{\mathbb{F}}}$ . For every  $i \in [K+k]$ , define

$$\begin{aligned} z_i^b &:= \text{Flat}_{\mathbb{L}}(z_i) \in \mathbb{F}^{n_{\mathbb{F}}} \\ z_i^{b, \text{pad}} &:= \text{Pad } z_i^b \in \mathbb{F}^m \\ \mathbf{z}_i &:= \text{Pack}_{\mathbb{L}}(z_i) = \text{Pack}_{\mathbb{F}}(z_i^b) \in \mathbb{R}_{\mathbb{F}}^{n_{\mathbb{R}}} \\ h_i &:= \text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad})) \cdot \mathbf{z}_i \in \mathbb{R}_{\mathbb{F}}^m \end{aligned}$$

For every  $i \in [K+k]$  and  $j \in [t]$ , define

$$h_{i,j} := \text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j)) \cdot \mathbf{z}_i \in \mathbb{R}_{\mathbb{L}}^m$$

Similarly to  $\Pi_{\text{CCS}}$  (Section 7.3), define

$$\begin{aligned} \mathbf{F}(\vec{X}, C) &:= \sum_{i=1}^K C^{i-1} \cdot f(\widetilde{M_1 z_i}, \dots, \widetilde{M_t z_i}) \\ \mathbf{NC}(\vec{X}, C) &:= \sum_{i=1}^{K+k} C^{i-1} \cdot \prod_{a=-b+1}^{b-1} \left( \widetilde{z_i^{b, \text{pad}}} - a \right) \\ \mathbf{Eval}_{\mathbb{K}}(\vec{X}, C) &:= \text{eq}(\vec{X}, r) \cdot \sum_{i=K+1}^{K+k} \sum_{\ell=1}^d C^{\mathbf{I}_{\mathbb{K}}(i, \ell)} \cdot \widetilde{\text{cf}(h_i)_{\ell}} \\ \mathbf{Eval}_{\mathbb{A}}(\vec{X}, C) &:= \text{eq}(\vec{X}, r) \cdot \sum_{i=K+1}^{K+k} \sum_{j=1}^t \sum_{\ell=1}^d C^{\mathbf{I}_{\mathbb{A}}(i, j, \ell)} \cdot \widetilde{\text{cf}(h_{i,j})_{\ell}} \\ Q(\vec{X}, \vec{A}, C) &:= \mathbf{Eval}_{\mathbb{K}}(\vec{X}, C) + C^{kd} \cdot \mathbf{Eval}_{\mathbb{A}}(\vec{X}, C) + C^{kd(t+1)} \cdot \text{eq}(\vec{X}, \vec{A}) \left( \mathbf{F}(\vec{X}, C) + C^K \cdot \mathbf{NC}(\vec{X}, C) \right) \\ \mathbf{T}(C) &:= \sum_{i=K+1}^{K+k} \sum_{\ell=1}^d C^{\mathbf{I}_{\mathbb{K}}(i, \ell)} \cdot \text{cf}(y_i)_{\ell} + C^{kd} \cdot \sum_{i=K+1}^{K+k} \sum_{j=1}^t \sum_{\ell=1}^d C^{\mathbf{I}_{\mathbb{A}}(i, j, \ell)} \cdot \text{cf}(y_{i,j})_{\ell} \end{aligned}$$

where  $\vec{X} := (X_1, \dots, X_{\log m})$ , and the challenges  $\alpha \in \mathbb{K}^{\log m}$  and  $\gamma \in \mathbb{K}$  are replaced by the indeterminates  $\vec{A} := (A_1, \dots, A_{\log m})$  and  $C$ , respectively.

We must have  $T(C) = \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x}, \vec{A}, C)$  if and only if

1.  $f(\widetilde{M_1 z_i}, \dots, \widetilde{M_t z_i}) \in \mathbf{ZS}_{\log m}(\mathbb{L})$  for all  $i \in [K]$ ,
2.  $\|z_i^b\|_{\infty} < b$  for all  $i \in [K+k]$ ,
3.  $y_i = \widetilde{h_i}(r)$  for all  $i \in [K+1, K+k]$ ,
4.  $y_{i,j} = \widetilde{h_{i,j}}(r)$  for all  $i \in [K+1, K+k]$  and  $j \in [t]$ .

*Proof.* By definition of  $T(C)$ ,

$$T(C) = \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x}, \vec{A}, C)$$

if and only if

$$\sum_{i=K+1}^{K+k} \sum_{\ell=1}^d C^{\mathbb{I}_K(i,\ell)} \cdot \text{cf}(y_i)_\ell + C^{kd} \cdot \sum_{i=K+1}^{K+k} \sum_{j=1}^t \sum_{\ell=1}^d C^{\mathbb{I}_A(i,j,\ell)} \cdot \text{cf}(y_{i,j})_\ell = \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x}, \vec{A}, C) \quad (6)$$

Since powers of  $C$  are linearly independent, Equation (6) occurs if and only if

$$\forall i \in [K], \quad 0 = \sum_{\vec{x} \in \{0,1\}^{\log m}} \text{eq}(\vec{x}, \vec{A}) \cdot f\left(\widetilde{M_1 z_i}(\vec{x}), \dots, \widetilde{M_t z_i}(\vec{x})\right), \quad (7)$$

$$\forall i \in [K+k], \quad 0 = \sum_{\vec{x} \in \{0,1\}^{\log m}} \text{eq}(\vec{x}, \vec{A}) \cdot \prod_{a=-b+1}^{b-1} \left(\widetilde{z_i^{b,\text{pad}}}(\vec{x}) - a\right), \quad (8)$$

$$\forall i \in [K+1, K+k], \quad \forall \ell \in [d], \quad \text{cf}(y_i)_\ell = \sum_{\vec{x} \in \{0,1\}^{\log m}} \text{eq}(\vec{x}, r) \cdot \widetilde{\text{cf}(h_i)}_\ell(\vec{x}) \quad (9)$$

$$\forall i \in [K+1, K+k], \quad \forall j \in [t], \quad \forall \ell \in [d], \quad \text{cf}(y_{i,j})_\ell = \sum_{\vec{x} \in \{0,1\}^{\log m}} \text{eq}(\vec{x}, r) \cdot \widetilde{\text{cf}(h_{i,j})}_\ell(\vec{x}) \quad (10)$$

By Lemma 3, Equation (7) and Equation (8) occur if and only if

1.  $f\left(\widetilde{M_1 z_i}, \dots, \widetilde{M_t z_i}\right) \in \text{ZS}_{\log m}(\mathbb{L})$  for all  $i \in [K]$  (Item 1),
2.  $\prod_{a=-b+1}^{b-1} \left(\widetilde{z_i^{b,\text{pad}}} - a\right) \in \text{ZS}_{\log m}(\mathbb{F})$  for all  $i \in [K+k]$ .

Since  $z_i^{b,\text{pad}} = \text{Pad } z_i^b$  only appends zero coordinates and  $0 \in \{-b+1, \dots, b-1\}$ , Item 2 holds if and only if  $\|z_i^b\|_\infty < b$  for all  $i \in [K+k]$  (Item 2). By definition of multilinear extension and bijectivity of the coefficient map, Equation (9) and Equation (10) hold if and only if

$$\begin{aligned} y_i &= \widetilde{h_i}(r) && \text{for all } i \in [K+1, K+k] && \text{(Item 3),} \\ y_{i,j} &= \widetilde{h_{i,j}}(r) && \text{for all } i \in [K+1, K+k], j \in [t] && \text{(Item 4).} \end{aligned}$$

In conclusion, we have shown

$$T(C) = \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x}, \vec{A}, C)$$

if and only if (Item 1), (Item 2), (Item 3), and (Item 4).  $\square$

**Lemma 10.** *The interactive reduction  $\Pi_{\text{CCS}} : \text{CCS}(b, \mathcal{L})^K \times \text{CE}(b, \mathcal{L})^k \rightarrow \text{CE}(b, \mathcal{L})^{K+k}$  is **complete** and **public coin**.*

*Proof. Completeness.* Assume the original input tuples belong to relations  $\text{CCS}(b, \mathcal{L})$  (Definition 19) and  $\text{CE}(b, \mathcal{L})$  (Definition 20). We will first argue that the sum-check verifier in step 2 passes. Then, we will argue that the evaluation claim check in step 4 passes. Finally, we will argue that output tuples belong to  $\text{CE}(b, \mathcal{L})^{K+k}$ .

By the definition of relations  $\text{CCS}(b, \mathcal{L})$  (Definition 19) and  $\text{CE}(b, \mathcal{L})$  (Definition 20), we must have that (Item 1), (Item 2), (Item 3), and (Item 4) from Lemma 9 hold. Therefore, we must have that

$$T(C) = \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x}, \vec{A}, C).$$

Thus, for any choice of challenges  $\alpha \in \mathbb{K}^{\log m}$  and  $\gamma \in \mathbb{K}$  chosen in step 1,

$$T(\gamma) = \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x}, \alpha, \gamma).$$

Thus, by the completeness of the sum-check protocol (Definition 11), we must have that the sum-check verifier (step 2) always passes.

By step 3 and Theorem 10, we must have that

$$\begin{aligned} \text{ct}(y'_i) &= \widetilde{z_i^{b, \text{pad}}}(r') && \text{for all } i \in [K+k], \\ \text{ct}(y'_{i,j}) &= \widetilde{M_j z_i}(r') && \text{for all } i \in [K+k], j \in [t]. \end{aligned}$$

Finally, by the same theorem, we must have that

$$\begin{aligned} \text{cf}(y'_i)_\ell &= \widetilde{\text{cf}(h_i)_\ell}(r') && \text{for all } i \in [K+1, K+k], \ell \in [d], \\ \text{cf}(y'_{i,j})_\ell &= \widetilde{\text{cf}(h_{i,j})_\ell}(r') && \text{for all } i \in [K+1, K+k], j \in [t], \ell \in [d]. \end{aligned}$$

By definition of  $Q(\vec{X})$  in step 2, we must have that

$$Q(r') = E_{\mathbb{K}} + \gamma^{kd} \cdot E_{\mathbb{A}} + \gamma^{kd(t+1)} \cdot \text{eq}(r', \alpha)(F + \gamma^K \cdot N)$$

for values  $F, N, E_{\mathbb{K}}$ , and  $E_{\mathbb{A}}$  derived in step 4. Since the honest sum-check execution yields  $v = Q(r')$ , the verifier check in step 4 passes.

Observe that  $\Pi_{\text{CCS}}$  outputs exactly the original structure  $s$ , commitments  $(c_i)_{i \in [K+k]}$ , vectors  $(z_i)_{i \in [K+k]}$ , and instances  $(x_i)_{i \in [K+k]}$ . Thus, by the definition of  $\text{CCS}(b, \mathcal{L})$ , we must have immediately that every condition in  $\text{CE}(b, \mathcal{L})$  is satisfied for all the  $K+k$  tuples, except that

$$\begin{aligned} y'_i &= \widetilde{h_i}(r') && \text{for all } i \in [K+k], \\ y'_{i,j} &= \widetilde{h_{i,j}}(r') && \text{for all } i \in [K+k], j \in [t]. \end{aligned}$$

However, these are exactly the evaluations computed by the honest prover in step 3. Therefore, the output tuples do belong to  $\text{CE}(b, \mathcal{L})^{K+k}$  as required.

**Public coin.** The sum-check protocol itself is a public-coin protocol. The remaining randomness from the verifier are the challenges  $\alpha \in \mathbb{K}^{\log m}$ ,  $\gamma \in \mathbb{K}$ , which are sampled uniformly at random and sent to the prover.  $\square$

We prove conditions (i) and (ii) of strong interactive reductions (Definition 17).

*Proof.*

**Proof of (i)** By construction, the verifier trivially sets the commitments in the output instance  $u_2$  to be the original commitments  $(c_i)_{i \in [K+k]}$  from the input instance  $u_1$ . Hence, for repeated executions with respect to the same input instance  $u_1$  with output instances  $u_2, u'_2$ , the commitments in these output instances must be the same.

**Proof of (ii)** Consider an arbitrary expected polynomial-time adversary  $(\mathcal{A}, \mathcal{P}^*)$ , such that the relaxed success probability of the adversary  $\epsilon'(\mathcal{A}, \mathcal{P}^*) \geq 1/\text{poly}(\lambda)$  and

$$\Pr \left[ \begin{array}{c} w_2, w'_2 \neq \perp \\ \wedge \\ w_2 \neq w'_2 \end{array} \middle| \begin{array}{l} \text{pp} \leftarrow \mathcal{G}(1^\lambda, \text{sz}) \\ (\text{s}, u_1, \text{st}) \leftarrow \mathcal{A}(\text{pp}) \\ (\text{pk}, \text{vk}) \leftarrow \mathcal{K}(\text{pp}, \text{s}) \\ (u_2, w_2) \leftarrow \langle \mathcal{P}^*, \mathcal{V} \rangle((\text{pk}, \text{vk}), u_1, \text{st}) \\ (u'_2, w'_2) \leftarrow \langle \mathcal{P}^*, \mathcal{V} \rangle((\text{pk}, \text{vk}), u_1, \text{st}) \end{array} \right] \leq \text{negl}(\lambda) \quad (11)$$

then we will show that there exists an expected polynomial-time extractor  $\mathcal{E}$  such that

$$\Pr \left[ (\mathbf{pp}, \mathbf{s}, u_1, w_1) \in \mathcal{R}_1 \left| \begin{array}{l} \mathbf{pp} \leftarrow \mathcal{G}(1^\lambda, \mathbf{sz}) \\ (\mathbf{s}, u_1, \mathbf{st}) \leftarrow \mathcal{A}(\mathbf{pp}) \\ (\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s}) \\ w_1 \leftarrow \mathcal{E}(\mathbf{pp}, \mathbf{s}, u_1, \mathbf{st}) \end{array} \right. \right] \geq \epsilon'(\mathcal{A}, \mathcal{P}^*) - \text{negl}(\lambda).$$

Namely, the following extractor  $\mathcal{E}$ ,

$\mathcal{E}(\mathbf{pp}, \mathbf{s}, u_1, \mathbf{st}) \rightarrow w_1 :$

1.  $(\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s})$ .
2. Simulate  $(u_2, w_2) \leftarrow \langle \mathcal{P}^*, \mathcal{V} \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st})$  with fresh randomness.
3. If  $(\mathbf{pp}, \mathbf{s}, u_2, w_2) \notin \mathcal{R}'_2$ , then output  $\perp$ .
4. Parse  $(z_1, \dots, z_K, z_{K+1}, \dots, z_{K+k}) \leftarrow w_2$ .
5. For all  $i \in [K]$ , assign  $w_i^{\text{CCS}} \leftarrow z_i[n_{L,\text{in}} : ]$ .
6. Output  $w_1 := (w_1^{\text{CCS}}, \dots, w_K^{\text{CCS}}, z_{K+1}, \dots, z_{K+k})$ .

**Extractor runtime.** The extractor makes one call to the expected polynomial-time prover  $\mathcal{P}^*$  and otherwise performs only polynomial-time computations. Hence, it runs in expected polynomial time.

**Extractor success probability.** Let  $\theta := (\mathbf{pp}, \mathbf{s}, u_1, \mathbf{st})$  denote everything fixed before the protocol execution, and compute  $(\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s})$ . Conditioned on  $\theta$ , consider two independent executions with fresh prover and verifier randomness:

$$\begin{aligned} (u_2, w_2) &\leftarrow \langle \mathcal{P}^*, \mathcal{V} \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st}), \\ (u'_2, w'_2) &\leftarrow \langle \mathcal{P}^*, \mathcal{V} \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st}). \end{aligned}$$

Let  $w_1$  denote the output of the extractor when its protocol call is the first execution. Define the relaxed success events for the first and second executions, the extraction error event for the first execution, and the witness agreement event as follows:

$$\begin{aligned} \text{Succ}_1 &:= \{(\mathbf{pp}, \mathbf{s}, u_2, w_2) \in \mathcal{R}'_2\}, \\ \text{Succ}_2 &:= \{(\mathbf{pp}, \mathbf{s}, u'_2, w'_2) \in \mathcal{R}'_2\}, \\ \text{Err}_1 &:= \text{Succ}_1 \cap \{(\mathbf{pp}, \mathbf{s}, u_1, w_1) \notin \mathcal{R}_1\}, \\ \text{Agree} &:= \{w'_2 = w_2\}. \end{aligned}$$

Thus, conditioned on  $\theta$ ,  $\text{Succ}_1$  and  $\text{Succ}_2$  each occur with probability

$$p_\theta := \Pr[\text{Succ}_1 \mid \theta] = \Pr[\text{Succ}_2 \mid \theta],$$

and  $\text{Err}_1$  occurs with probability

$$a_\theta := \Pr[\text{Err}_1 \mid \theta].$$

Since  $\text{Err}_1 \subseteq \text{Succ}_1$ , we have  $0 \leq a_\theta \leq p_\theta$ . By the law of total probability,

$$\epsilon'(\mathcal{A}, \mathcal{P}^*) = \mathbb{E}_\theta[\Pr[\text{Succ}_1 \mid \theta]] = \mathbb{E}_\theta[p_\theta]. \quad (12)$$

Conditioned on  $\theta$ ,  $\text{Err}_1$  depends only on the first execution and  $\text{Succ}_2$  only on the independent second execution. Therefore, by conditional independence and the law of total probability,

$$\Pr[\text{Err}_1 \cap \text{Succ}_2] = \mathbb{E}_\theta[a_\theta p_\theta]. \quad (13)$$

On  $\text{Agree}^c$ , the event  $\text{Err}_1 \cap \text{Succ}_2$  is contained in (11); membership in  $\mathcal{R}'_2$  ensures that  $w_2, w'_2 \neq \perp$ . Thus, letting  $\epsilon_{\text{coll}} \leq \text{negl}(\lambda)$  denote the probability bound in (11), we have

$$\Pr[\text{Err}_1 \cap \text{Succ}_2 \cap \text{Agree}^c] \leq \epsilon_{\text{coll}}. \quad (14)$$

It remains to bound  $\text{Err}_1 \cap \text{Succ}_2 \cap \text{Agree}$ . Fix  $\theta$  and a first execution in  $\text{Err}_1$ . By definition of  $\mathcal{R}'_2 = \text{CE}(q/2, \mathcal{L})^{K+k}$ , for all  $i \in [K+k]$ , define

$$\mathbf{x}_i := \text{Pack}_{\mathbb{L}}(x_i), \quad \mathbf{z}_i := \text{Pack}_{\mathbb{L}}(z_i).$$

We must have

$$\mathbf{x}_i = \mathcal{L}_{\text{in}}(\mathbf{z}_i) \quad \text{and} \quad c_i = \mathcal{L}(\mathbf{z}_i). \quad (15)$$

By the definitions of  $\text{Pack}_{\mathbb{L}}$  (Definition 14) and  $\mathcal{L}_{\text{in}}$  (Definition 21), together with  $n_{\mathbb{F}, \text{in}} = \tau n_{L, \text{in}} = dn_{R, \text{in}}$  (Definition 1), Equation (15) also implies that for all  $i \in [K+k]$ , the first  $n_{L, \text{in}}$  entries of  $z_i$  are equal to  $x_i$  (from input instance  $u_1$ ).

Since the fixed first execution lies in  $\text{Err}_1$ ,  $(\text{pp}, \mathbf{s}, u_1, w_1) \notin \mathcal{R}_1$ . Recall that  $\mathcal{R}_1 := \text{CCS}(b, \mathcal{L})^K \times \text{CE}(b, \mathcal{L})^k$ . By Equation (15), we know that all conditions in  $\text{CCS}(b, \mathcal{L})$  and  $\text{CE}(b, \mathcal{L})$ , except for the norm bound  $\|z_i^b\|_{\infty} < b$ , the evaluations  $y = \widetilde{h}(r)$  and  $y_j = \widetilde{h}_j(r)$  for  $j \in [t]$ , or the CCS requirements  $f(\widetilde{M}_1 z, \dots, \widetilde{M}_t z) \in \text{ZS}_{\log m}(\mathbb{L})$ , are satisfied. Thus, using notation from Lemma 9,  $(\text{pp}, \mathbf{s}, u_1, w_1) \notin \mathcal{R}_1$  implies that either:

1. there exists an  $i \in [K]$ ,  $f(\widetilde{M}_1 z_i, \dots, \widetilde{M}_t z_i) \notin \text{ZS}_{\log m}(\mathbb{L})$ ,
2. OR there exists an  $i \in [K+k]$ ,  $\|z_i^b\|_{\infty} \geq b$ ,
3. OR there exists an  $i \in [K+1, K+k]$ ,  $y_i \neq \widetilde{h}_i(r)$ ,
4. OR there exists an  $i \in [K+1, K+k]$  and  $j \in [t]$ ,  $y_{i,j} \neq \widetilde{h}_{i,j}(r)$ .

By Lemma 9, we must have

$$T(C) \neq \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x}, \vec{A}, C).$$

Now focus on the independent second execution, whose randomness is fresh and independent of the fixed first execution. Write  $\alpha', \gamma', r', v', y'_i$ , and  $y'_{i,j}$  for the challenges, sum-check point and value, and claimed evaluations of this execution.

On **Agree**, the witness from the first execution,  $w_2$ , agrees with the witness from the second execution,  $w'_2$ ; that is,  $w_2 = w'_2$ . Consequently, the second execution uses the same vectors  $z_i$ , and hence the same  $h_i$  and  $h_{i,j}$ , as the fixed first execution.

On **Succ**<sub>2</sub>, the second execution has relaxed success, so  $(\text{pp}, \mathbf{s}, u'_2, w'_2) \in \mathcal{R}'_2$ . Therefore, the verifier did not abort in protocol steps 2 and 4, and the prover's claimed evaluations in protocol step 3 are true. Namely,

$$\begin{aligned} y'_i &= \widetilde{h}_i(r') && \text{for all } i \in [K+k], \\ y'_{i,j} &= \widetilde{h}_{i,j}(r') && \text{for all } i \in [K+k], j \in [t]. \end{aligned}$$

Thus, by Theorem 10, the definition of  $Q$ , and the construction of the verifier's checks in protocol step 4, we must have that the second execution's sum-check evaluation claim  $v' = Q(r', \alpha', \gamma')$  is true.

Thus, in order for the sum-check verifier to have passed in the second execution, either the adversary  $\mathcal{P}^*$

- succeeded in the sum-check protocol, despite  $T(\gamma') \neq \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x}, \alpha', \gamma')$  (in other words, violated the soundness of the sum-check protocol)
- OR the non-zero polynomial

$$P(C, \vec{A}) := T(C) - \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x}, \vec{A}, C)$$

evaluated to zero on the random point  $(\gamma', \alpha') \in \mathbb{K}^{1+\log m}$  of the second execution.

By the soundness error of the sum-check protocol (Definition 11), the first event occurs with probability at most  $\epsilon_{\text{SC}} := \max(u, 2b, 2) \cdot \log m / |\mathbb{K}|$ , where  $u$  is the strict total-degree bound for  $f$ ,  $b$  is the norm bound, and 2 comes from  $\text{Eval}_{\mathbb{K}}(\vec{X})$  and  $\text{Eval}_{\mathbb{A}}(\vec{X})$ . By the Schwartz–Zippel lemma (Lemma 2), the second event occurs with probability at most  $\epsilon_{\text{SZ}} := (kd(t+1) + 2K + k - 1 + \log m) / |\mathbb{K}|$ . By Definition 1,  $1/|\mathbb{K}| = \text{negl}(\lambda)$ . Since

$u, b, t, k, K, d$ , and  $\log m$  are polynomially bounded in  $\lambda$ , both  $\epsilon_{\text{SC}}$  and  $\epsilon_{\text{SZ}}$  are negligible. For the fixed  $\theta$  and first execution in  $\text{Err}_1$ , the union bound over the fresh randomness of the second execution gives

$$\Pr[\text{Succ}_2 \cap \text{Agree}] \leq \epsilon_{\text{SC}} + \epsilon_{\text{SZ}}. \quad (16)$$

Let  $\epsilon_{\text{test}} := \epsilon_{\text{SC}} + \epsilon_{\text{SZ}}$ . We will now prove that, for every fixed  $\theta$ ,

$$\Pr[\text{Err}_1 \cap \text{Succ}_2 \cap \text{Agree} \mid \theta] \leq a_\theta \epsilon_{\text{test}}. \quad (17)$$

We split into two cases:

If  $a_\theta = 0$ , then

$$\begin{aligned} \Pr[\text{Err}_1 \cap \text{Succ}_2 \cap \text{Agree} \mid \theta] &\leq \Pr[\text{Err}_1 \mid \theta] \\ &= a_\theta = 0 = a_\theta \epsilon_{\text{test}}. \end{aligned}$$

Suppose instead that  $a_\theta > 0$ , so conditioning on  $\text{Err}_1$  is well defined. Since Equation (16) holds for every fixed first execution in  $\text{Err}_1$ , averaging over the first execution conditioned on  $\text{Err}_1$  gives

$$\Pr[\text{Succ}_2 \cap \text{Agree} \mid \text{Err}_1, \theta] \leq \epsilon_{\text{test}}.$$

Therefore, by the chain rule,

$$\begin{aligned} \Pr[\text{Err}_1 \cap \text{Succ}_2 \cap \text{Agree} \mid \theta] \\ &= \Pr[\text{Err}_1 \mid \theta] \Pr[\text{Succ}_2 \cap \text{Agree} \mid \text{Err}_1, \theta] \\ &\leq a_\theta \epsilon_{\text{test}}. \end{aligned}$$

Thus, Equation (17) holds for every fixed  $\theta$ . Averaging over  $\theta$  gives

$$\Pr[\text{Err}_1 \cap \text{Succ}_2 \cap \text{Agree}] \leq \mathbb{E}_\theta[a_\theta] \epsilon_{\text{test}}. \quad (18)$$

The events  $\text{Agree}$  and  $\text{Agree}^c$  partition the event in Equation (13). Therefore, by Equations (14) and (18),

$$\mathbb{E}_\theta[a_\theta p_\theta] \leq \epsilon_{\text{coll}} + \mathbb{E}_\theta[a_\theta] \epsilon_{\text{test}}. \quad (19)$$

Jensen's inequality gives the first inequality below, while  $a_\theta \leq p_\theta$  gives the second:

$$\mathbb{E}_\theta[a_\theta]^2 \leq \mathbb{E}_\theta[a_\theta^2] \leq \mathbb{E}_\theta[a_\theta p_\theta]. \quad (20)$$

Since  $a_\theta$  is a probability,  $0 \leq \mathbb{E}_\theta[a_\theta] \leq 1$ . Combining Equations (19) and (20) gives

$$\begin{aligned} \mathbb{E}_\theta[a_\theta]^2 &\leq \epsilon_{\text{coll}} + \mathbb{E}_\theta[a_\theta] \epsilon_{\text{test}} \\ &\leq \epsilon_{\text{coll}} + \epsilon_{\text{test}}. \end{aligned}$$

Therefore,  $\mathbb{E}_\theta[a_\theta] \leq \sqrt{\epsilon_{\text{coll}} + \epsilon_{\text{test}}} = \text{negl}(\lambda)$ . For every fixed  $\theta$ , relaxed success occurs with probability  $p_\theta$  and extraction error occurs with probability  $a_\theta$ . The extractor outputs a valid witness exactly when relaxed success occurs without an extraction error, namely on  $\text{Succ}_1 \setminus \text{Err}_1$ . Since  $\text{Err}_1 \subseteq \text{Succ}_1$ , this event has probability  $p_\theta - a_\theta$ . Consequently, by the law of total probability, linearity of expectation, and Equation (12),

$$\begin{aligned} \Pr[(\text{pp}, s, u_1, w_1) \in \mathcal{R}_1] &= \Pr[\text{Succ}_1 \setminus \text{Err}_1] \\ &= \mathbb{E}_\theta[p_\theta - a_\theta] \\ &= \mathbb{E}_\theta[p_\theta] - \mathbb{E}_\theta[a_\theta] \\ &= \epsilon'(\mathcal{A}, \mathcal{P}^*) - \mathbb{E}_\theta[a_\theta] \\ &\geq \epsilon'(\mathcal{A}, \mathcal{P}^*) - \text{negl}(\lambda). \end{aligned}$$

□

## B.3 Proofs for $\Pi_{\text{RLC}}$

Set  $\ell:=K+k$ . Throughout this subsection, unbold symbols  $z_i,z,z^{(i)}$  are native vectors in  $\mathbb{L}^{n_L}$ , while bold symbols  $\mathbf{z}_i,\mathbf{z},\mathbf{z}^{(i)}$  are their packed images in  $R_{\mathbb{F}}^{n_R}$ . This distinction is essential: the commitment, folding, and relaxed-binding equations are ring-module equations on packed vectors, whereas membership in  $\text{CE}$  is stated using native witnesses.

**Lemma 11.** *The interactive reduction  $\Pi_{\text{RLC}}:\text{CE}(b,\mathcal{L})^{\ell}\to\text{CE}(B,\mathcal{L})$  is complete and public coin.*

*Proof. Completeness.* For each input witness, define

$$z_i^b:=\text{Flat}_{\mathbb{L}}(z_i),\qquad
\mathbf{z}_i:=\text{Pack}_{\mathbb{L}}(z_i)=\text{Pack}_{\mathbb{F}}(z_i^b),\qquad
\mathbf{x}_i:=\text{Pack}_{\mathbb{L}}(x_i).$$

The protocol computes

$$\mathbf{z}:=\sum_{i=1}^{\ell}\rho_i\mathbf{z}_i,
\qquad z:=\text{Pack}_{\mathbb{L}}^{-1}(\mathbf{z}),
\qquad
\mathbf{x}:=\sum_{i=1}^{\ell}\rho_i\mathbf{x}_i,
\qquad x:=\text{Pack}_{\mathbb{L}}^{-1}(\mathbf{x}).$$

Because  $\text{Pack}_{\mathbb{L}}=\text{Pack}_{\mathbb{F}}\circ\text{Flat}_{\mathbb{L}}$ , the flattened output is

$$z^b:=\text{Flat}_{\mathbb{L}}(z)=\text{Pack}_{\mathbb{F}}^{-1}(\mathbf{z}).$$

Apply Theorem 11 first with  $(\mathbb{B},M)=(\mathbb{F},\text{Pad})$  and native vectors  $z_i^b$ , and then, for every  $j\in[t]$ , with  $(\mathbb{B},M)=(\mathbb{L},M_j)$  and native vectors  $z_i$ . Together with the module homomorphisms  $\mathcal{L}$  and  $\mathcal{L}_{\mathrm{in}}$ , this gives

$$\begin{aligned}
c&=\mathcal{L}(\mathbf{z}), &
\mathbf{x}&=\mathcal{L}_{\mathrm{in}}(\mathbf{z}),\\
y&=\widetilde{\text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad}))\mathbf{z}}(r), &
y_j&=\widetilde{\text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j))\mathbf{z}}(r)
\quad(j\in[t]).
\end{aligned}$$

It remains to prove the norm bound. Packing preserves coefficient norm, so

$$\begin{aligned}
\|z^b\|_{\infty}
&=\|\mathbf{z}\|_{\infty}
 =\left\|\sum_{i=1}^{\ell}\rho_i\mathbf{z}_i\right\|_{\infty}\\
&\leq\sum_{i=1}^{\ell}\|\rho_i\mathbf{z}_i\|_{\infty}
 \leq\sum_{i=1}^{\ell}T\|\mathbf{z}_i\|_{\infty}
 =\sum_{i=1}^{\ell}T\|z_i^b\|_{\infty}\\
&\leq \ell T(b-1)<B,
\end{aligned}$$

where the penultimate inequality uses that coefficient norms are integral and  $\|z_i^b\|_{\infty}<b$ . Hence the output belongs to  $\text{CE}(B,\mathcal{L})$ . The verifier samples each  $\rho_i$  uniformly from the explicit finite set  $\mathcal{C}$  and sends the complete challenge vector, so the protocol is public coin.  $\square$

**Proof of Lemma 8 (weak extraction).** Take

$$\mathcal{R}_1:=\text{CE}(b,\mathcal{L})^{\ell},
\qquad
\mathcal{R}'_1:=\text{CE}(q/2,\mathcal{L})^{\ell}.$$

Fix a tuple  $\theta=(\text{pp},\mathbf{s},u_1,\text{st})$ . For a challenge vector  $\boldsymbol\rho=(\rho_1,\dots,\rho_\ell)\in\mathcal{C}^{\ell}$ , let

$$\operatorname{Out}(u_1,\boldsymbol\rho)
 :=(c,x,r,y,\{y_j\}_{j\in[t]})$$

be the output *instance* computed deterministically from the input instance and the RLC verifier equations:

$$\begin{aligned}
c&:=\sum_{a=1}^{\ell}\rho_a c_a,
&\mathbf{x}&:=\sum_{a=1}^{\ell}\rho_a\text{Pack}_{\mathbb{L}}(x_a),
&x&:=\text{Pack}_{\mathbb{L}}^{-1}(\mathbf{x}),\\
y&:=\sum_{a=1}^{\ell}\rho_a y_a,
&y_j&:=\sum_{a=1}^{\ell}\rho_a y_{a,j}
&& (j\in[t]).
\end{aligned}$$

Define  $A_\theta(\boldsymbol\rho)$  to run  $\mathcal{P}^*$  once against the RLC verifier using challenge  $\boldsymbol\rho$  and to return the native output witness  $z$  (or  $\perp$ ). Define

$$V_\theta(\boldsymbol\rho,z)=1
\quad\Longleftrightarrow\quad
u_1\neq\perp\ \text{ and }\
(\text{pp},\mathbf{s},\operatorname{Out}(u_1,\boldsymbol\rho),z)
 \in\text{CE}(B,\mathcal{L}).$$

Here  $V_\theta$  does not rerun the prover: the RLC output instance is verifier-determined once  $u_1$  and  $\boldsymbol\rho$  are fixed. Thus the success probability of  $(A_\theta,V_\theta)$  is exactly the conditional success probability of the original adversary.

Apply Theorem 7 with one-coordinate set  $\mathcal{C}$  and vector length  $\ell$ . Except with loss  $\ell/|\mathcal{C}|$ , it returns an accepting base pair  $(\boldsymbol\rho,z)$  and, for every  $i\in[\ell]$ , an accepting fork  $(\boldsymbol\rho^{(i)},z^{(i)})$  such that the two challenge vectors differ only in coordinate  $i$ . Define

$$\begin{aligned}
\Delta_i&:=\rho_i-\rho_i^{(i)},\\
\mathbf{z}&:=\text{Pack}_{\mathbb{L}}(z),
&\mathbf{z}^{(i)}&:=\text{Pack}_{\mathbb{L}}(z^{(i)}),\\
\mathbf{z}_i&:=\Delta_i^{-1}(\mathbf{z}-\mathbf{z}^{(i)}),
&z_i&:=\text{Pack}_{\mathbb{L}}^{-1}(\mathbf{z}_i).
\end{aligned}$$

The special-set condition gives  $\Delta_i\neq0$ . Since  $\rho_i,\rho_i^{(i)}\in\mathcal{C}$  and  $\mathcal{C}$  is a strong sampling set, Theorem 4 makes  $\Delta_i$  invertible in  $R_{\mathbb{F}}$ . The extractor returns  $(z_1,\dots,z_\ell)$  only after directly checking that all reconstructed tuples belong to  $\mathcal{R}'_1$ .

We now show that this final check passes whenever coordinate extraction succeeds. Membership of the base and fork outputs in  $\text{CE}(B,\mathcal{L})$  gives

$$\begin{aligned}
\sum_a\rho_a c_a&=\mathcal{L}(\mathbf{z}),
&\sum_a\rho_a^{(i)}c_a&=\mathcal{L}(\mathbf{z}^{(i)}),\\
\sum_a\rho_a\text{Pack}_{\mathbb{L}}(x_a)&=\mathcal{L}_{\mathrm{in}}(\mathbf{z}),
&\sum_a\rho_a^{(i)}\text{Pack}_{\mathbb{L}}(x_a)&=\mathcal{L}_{\mathrm{in}}(\mathbf{z}^{(i)}),\\
\sum_a\rho_a y_a&=H_{\mathbb{F}}(\mathbf{z}),
&\sum_a\rho_a^{(i)}y_a&=H_{\mathbb{F}}(\mathbf{z}^{(i)}),\\
\sum_a\rho_a y_{a,j}&=H_{\mathbb{L},j}(\mathbf{z}),
&\sum_a\rho_a^{(i)}y_{a,j}&=H_{\mathbb{L},j}(\mathbf{z}^{(i)}),
\end{aligned}$$

where

$$\begin{aligned}
H_{\mathbb{F}}(\mathbf{v})
&:=\widetilde{\text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad}))\mathbf{v}}(r),\\
H_{\mathbb{L},j}(\mathbf{v})
&:=\widetilde{\text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j))\mathbf{v}}(r).
\end{aligned}$$

Subtracting each fork equation from its base equation, using equality of all challenge coordinates other than  $i$ , and cancelling the invertible  $\Delta_i$  yields

$$\begin{aligned}
c_i&=\mathcal{L}(\mathbf{z}_i),\\
\text{Pack}_{\mathbb{L}}(x_i)&=\mathcal{L}_{\mathrm{in}}(\mathbf{z}_i),\\
y_i&=H_{\mathbb{F}}(\mathbf{z}_i),\\
y_{i,j}&=H_{\mathbb{L},j}(\mathbf{z}_i)\qquad(j\in[t]).
\end{aligned}$$

Finally, every coefficient in  $\text{Flat}_{\mathbb{L}}(z_i)$  is a base-field element, so its norm is at most  $(q-1)/2<q/2$ . Thus every reconstructed tuple lies in  $\text{CE}(q/2,\mathcal{L})$ . Averaging the pointwise coordinate-extraction guarantee over  $\theta$  gives

$$\Pr[(\text{pp},\mathbf{s},u_1,(z_i)_{i\in[\ell]})\in\mathcal{R}'_1]
\geq \epsilon(\mathcal{A},\mathcal{P}^*)-\frac{\ell}{|\mathcal{C}|}.$$

By Definition 21,  $\ell$  is polynomially bounded and  $1/|\mathcal{C}|$  is negligible, so this is the extraction guarantee required by Definition 16.

**Weak consistency.** Let  $\phi$  project the input commitment tuple  $(c_i)_{i\in[\ell]}$ . Assume the premise of Definition 16 in its equivalent mismatch form:

$$\Pr[u_1,u'_1\neq\perp\ \wedge\ \phi(u_1)\neq\phi(u'_1)]=0.$$

Suppose two invocations of the extractor return non-abort witness tuples  $(z_i)_i$  and  $(z'_i)_i$  that differ. Choose an index  $i$  with  $z_i\neq z'_i$ . In the first extraction, let

$$\Delta_1:=\rho_i-\rho_i^{(i)},
\qquad v_1:=\mathbf{z}-\mathbf{z}^{(i)},$$

and in the second extraction let

$$\Delta_2:=\rho'_i-\rho_i^{(i)'},
\qquad v_2:=\mathbf{z}'-\mathbf{z}^{(i)'}.$$

All four packed output witnesses come from accepting  $\text{CE}(B,\mathcal{L})$  executions. Hence, by the triangle inequality,

$$\|v_1\|_{\infty}<2B,
\qquad
\|v_2\|_{\infty}<2B.$$

The two input instances have the same commitment  $c_i$  almost surely under the premise. Subtracting the corresponding base and fork commitment equations gives

$$\Delta_1 c_i=\mathcal{L}(v_1),
\qquad
\Delta_2 c_i=\mathcal{L}(v_2).$$

Moreover,  $z_i\neq z'_i$  and bijectivity of  $\text{Pack}_{\mathbb{L}}$  imply

$$\Delta_1^{-1}v_1\neq\Delta_2^{-1}v_2.$$

Both differences are invertible, so multiplying by  $\Delta_1\Delta_2$  gives

$$\Delta_1v_2\neq\Delta_2v_1.$$

Thus  $(c_i,\Delta_1,\Delta_2,v_1,v_2)$  is a  $(2B,\mathcal{C})$ -relaxed-binding collision as defined in Definition 7. The commitment assumption in Definition 21 makes the probability of this event negligible. Therefore two non-abort extractor outputs differ only with negligible probability, completing the proof that  $\Pi_{\text{RLC}}$  is weak.  $\square$

## B.4 $\Pi_{\text{DEC}}$ is a Reduction of Knowledge (Theorem 13)

*Proof. Completeness:* First, we show that the verifier's checks in step 2 pass. Then, we will show that the output tuples belong to  $\text{CE}(b, \mathcal{L})^k$ .

By the definition of  $\text{CE}(B, \mathcal{L})$ , let  $z^b := \text{Flat}_{\mathbb{L}}(z)$  and  $x^b := \text{Flat}_{\mathbb{L}}(x)$ . We must have  $\|z^b\|_{\infty} < B = b^k$  (Definition 21), so  $\text{split}_b(z^b)$  is defined and  $z^b = \sum_{i=1}^k b^{i-1} \cdot z_i^b$ . Moreover,  $\text{Pack}_{\mathbb{L}}(x) = \mathcal{L}_{\text{in}}(\text{Pack}_{\mathbb{L}}(z))$ . Since  $\mathcal{L}_{\text{in}}$  projects the first  $n_{\mathbb{R}, \text{in}}$  packed coordinates,  $x^b$  is the corresponding prefix of  $z^b$ . Therefore,  $\|x^b\|_{\infty} \leq \|z^b\|_{\infty} < B$ , so  $\text{split}_b(x^b)$  is also defined. Since  $\text{split}_b$  is coordinatewise, each  $x_i^b$  is the corresponding prefix of  $z_i^b$ . Hence,  $\text{Pack}_{\mathbb{L}}(x_i) = \mathcal{L}_{\text{in}}(\text{Pack}_{\mathbb{L}}(z_i))$  for every  $i \in [k]$ . By linearity,

$$\begin{aligned} z^b &= \sum_{i=1}^k b^{i-1} \cdot z_i^b \\ z &= \sum_{i=1}^k b^{i-1} \cdot z_i \\ \text{Pack}_{\mathbb{L}}(z) &= \sum_{i=1}^k b^{i-1} \cdot \text{Pack}_{\mathbb{L}}(z_i) \end{aligned} \quad (45)$$

$$\begin{aligned} \mathcal{L}(\text{Pack}_{\mathbb{L}}(z)) &= \mathcal{L}\left(\sum_{i=1}^k b^{i-1} \cdot \text{Pack}_{\mathbb{L}}(z_i)\right) \\ c &= \sum_{i=1}^k b^{i-1} \cdot \mathcal{L}(\text{Pack}_{\mathbb{L}}(z_i)), \end{aligned} \quad (46)$$

$$c = \sum_{i=1}^k b^{i-1} \cdot c_i, \quad (47)$$

Equation (46) follows directly from  $\mathcal{L}$  being a  $\mathbb{R}_F$ -module homomorphism. Equation (47) follows by construction of  $c_i \leftarrow \mathcal{L}(\text{Pack}_{\mathbb{L}}(z_i))$  in step 1. Therefore, the verifier's commitment check passes. Starting from equation (45), we must have

$$\begin{aligned} \text{Pack}_{\mathbb{L}}(z) &= \sum_{i=1}^k b^{i-1} \cdot \text{Pack}_{\mathbb{L}}(z_i) \\ \text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad})) \cdot \text{Pack}_{\mathbb{L}}(z) &= \sum_{i=1}^k b^{i-1} \cdot \text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad})) \cdot \text{Pack}_{\mathbb{L}}(z_i) \\ h &= \sum_{i=1}^k b^{i-1} \cdot h_i \\ \tilde{h}(r) &= \sum_{i=1}^k b^{i-1} \cdot \tilde{h}_i(r) \end{aligned} \quad (48)$$

$$y = \sum_{i=1}^k b^{i-1} \cdot y_i \quad (49)$$

Similarly, for every  $j \in [t]$ ,

$$\begin{aligned} \text{Pack}_{\mathbb{L}}(z) &= \sum_{i=1}^k b^{i-1} \cdot \text{Pack}_{\mathbb{L}}(z_i) \\ \text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j)) \cdot \text{Pack}_{\mathbb{L}}(z) &= \sum_{i=1}^k b^{i-1} \cdot \text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j)) \cdot \text{Pack}_{\mathbb{L}}(z_i) \\ h_j &= \sum_{i=1}^k b^{i-1} \cdot h_{i,j} \end{aligned}$$

$$\widetilde{h}_j(r) = \sum_{i=1}^k b^{i-1} \cdot \widetilde{h}_{i,j}(r) \quad (50)$$

$$y_j = \sum_{i=1}^k b^{i-1} \cdot y_{i,j} \quad (51)$$

Equation (48) and Equation (50) follow from the linearity of matrix multiplication and multilinear evaluation. Equation (49) and Equation (51) follow from the definition of  $\text{CE}(B, \mathcal{L})$  and the construction of  $y_i$  and  $y_{i,j}$  in step 1. Thus, by (47), (49), and (51), the verifier's checks pass.

Next, we show that the output tuple,  $(\mathbf{s}; \{c_i, x_i, r, y_i, \{y_{i,j}\}_{j \in [t]}\}_{i \in [k]}; \{z_i\}_{i \in [k]})$ , belongs to  $\text{CE}(b, \mathcal{L})^k$ . By the definition of  $\text{split}_b$ , we must have that  $\|z_i^b\|_\infty < b$  for all  $i \in [k]$ . Since  $\mathcal{L}_{\text{in}}$  is the trivial  $\mathbb{R}_{\text{in}}$ -module homomorphism which projects the first  $n_{\text{R}, \text{in}}$  coordinates, and  $\text{split}_b$  is coordinatewise, we must have that, by construction in step 2,  $\text{Pack}_{\mathbb{L}}(x_i) = \mathcal{L}_{\text{in}}(\text{Pack}_{\mathbb{L}}(z_i))$  for all  $i \in [k]$ . Thus, in total, we must have, along with the construction of  $(c_i, y_i, \{y_{i,j}\}_{j \in [t]})_{i \in [k]}$  in step 1, that the output tuples belong to  $\text{CE}(b, \mathcal{L})^k$ .

**Public coin:** The verifier uses no randomness in this protocol. Thus, the protocol is trivially public coin.

**Knowledge soundness:** Consider an arbitrary expected-polynomial time adversary  $(\mathcal{A}, \mathcal{P}^*)$  for  $\Pi_{\text{DEC}}$  with success probability,  $\epsilon(\mathcal{A}, \mathcal{P}^*) \geq 1/\text{poly}(\lambda)$ . We construct an extractor  $\mathcal{E}$  for  $\Pi_{\text{DEC}}$  as follows,

$\mathcal{E}(\text{pp}, \mathbf{s}, u_1 := (c, x, r, y, (y_j)_{j \in [t]}), \text{st}):$

1. Execute encoder  $(\text{pk}, \text{vk}) \leftarrow \mathcal{K}(\text{pp}, \mathbf{s})$ .
2. Simulate  $(u_2, w_2) \leftarrow \langle \mathcal{P}^*(\text{pk}, u_1, \text{st}), \mathcal{V}(\text{vk}, u_1) \rangle$ .
3. If  $u_2 = \perp$ , output  $\perp$ .
4. Parse  $(z_1, \dots, z_k) \leftarrow w_2$ .
5. Output  $w_1 := \sum_{i=1}^k b^{i-1} z_i$ .

**Extractor runtime:** The extractor runs in expected polynomial time, since it simulates only one execution between the adversary  $\mathcal{P}^*$  and verifier  $\mathcal{V}$ , which both run in expected polynomial time.

**Extractor success probability:** Assume that the simulated adversary  $(\mathcal{A}, \mathcal{P}^*)$  succeeds in convincing the verifier  $\mathcal{V}$  and the parties jointly output  $(\mathbf{s}, u_2, w_2) \in \text{CE}(b, \mathcal{L})^k$ ; note that this occurs with probability  $\epsilon(\mathcal{A}, \mathcal{P}^*)$ . Define

$$(c_i, x_i, r, y_i, (y_{i,j})_{j \in [t]})_{i \in [k]} := u_2 \text{ and } z_1, \dots, z_k := w_2.$$

By the definition of  $\text{CE}(b, \mathcal{L})$ , for every  $i \in [k]$ , define  $z_i^b := \text{Flat}_{\mathbb{L}}(z_i)$ ,  $h_i := \text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad})) \cdot \text{Pack}_{\mathbb{L}}(z_i)$ , and  $h_{i,j} := \text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j)) \cdot \text{Pack}_{\mathbb{L}}(z_i)$  for every  $j \in [t]$ . We must have

$$\begin{aligned} c_i &= \mathcal{L}(\text{Pack}_{\mathbb{L}}(z_i)), \\ \text{Pack}_{\mathbb{L}}(x_i) &= \mathcal{L}_{\text{in}}(\text{Pack}_{\mathbb{L}}(z_i)), \\ \|z_i^b\|_\infty &< b, \\ y_i &= \widetilde{h}_i(r), \\ \forall j \in [t], \quad y_{i,j} &= \widetilde{h}_{i,j}(r) \end{aligned} \quad (52)$$

Since the adversary convinces the verifier, we must have

$$\begin{aligned} c &= \sum_{i=1}^k b^{i-1} \cdot c_i, \\ y &= \sum_{i=1}^k b^{i-1} \cdot y_i, \\ \forall j \in [t], \quad y_j &= \sum_{i=1}^k b^{i-1} \cdot y_{i,j} \end{aligned} \quad (53)$$

By construction in step 2 (i.e. definition of  $\text{split}_b$ ), we also must have  $x = \sum_{i=1}^k b^{i-1} \cdot x_i$ . By defining  $z := \sum_{i=1}^k b^{i-1} z_i$ , observe that  $x = \sum_{i=1}^k b^{i-1} \cdot x_i$ , (52), and (53) satisfy the remaining conditions stated in

Theorem 11, applied first with  $\mathbb{B} = \mathbb{F}$ ,  $M = \text{Pad}$ , vectors  $(z_i^b)_{i \in [k]}$ , and evaluations  $(y_i)_{i \in [k]}$ , and then, for every  $j \in [t]$ , with  $\mathbb{B} = \mathbb{L}$ ,  $M = M_j$ , vectors  $(z_i)_{i \in [k]}$ , and evaluations  $(y_{i,j})_{i \in [k]}$ . In both applications, the scalars are  $(b^{i-1})_{i \in [k]}$ , where each  $b^{i-1}$  is treated as a constant element of  $R_{\mathbb{F}}$ . We must have  $c = \mathcal{L}(\text{Pack}_{\mathbb{L}}(z))$ ,  $\text{Pack}_{\mathbb{L}}(x) = \mathcal{L}_{\text{in}}(\text{Pack}_{\mathbb{L}}(z))$ ,  $y = \tilde{h}(r)$ , and, for all  $j \in [t]$ ,  $y_j = \tilde{h}_j(r)$ , where  $h := \text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad})) \cdot \text{Pack}_{\mathbb{L}}(z)$  and  $h_j := \text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j)) \cdot \text{Pack}_{\mathbb{L}}(z)$ . Since in (52), we have  $\|z_i^b\|_{\infty} < b$  for every  $i \in [k]$ , by the  $\mathbb{F}$ -linearity of  $\text{Flat}_{\mathbb{L}}$ , we must also have  $z^b = \sum_{i=1}^k b^{i-1} z_i^b$  and  $\|z^b\|_{\infty} \leq \sum_{i=1}^k b^{i-1}(b-1) = b^k - 1 < B$ . These are exactly the conditions for  $(s; u_1 := \{c, x, r, y, \{y_j\}_{j \in [t]}\}; w_1 := z)$  to belong to  $\text{CE}(B, \mathcal{L})$ . The simulated interaction in  $\mathcal{E}$  has the same distribution as the interaction defining  $\epsilon(\mathcal{A}, \mathcal{P}^*)$ . Whenever this interaction succeeds, the preceding argument shows that the extracted witness  $w_1$  satisfies the input relation. Therefore,  $\mathcal{E}$  outputs a satisfying witness with probability at least  $\epsilon(\mathcal{A}, \mathcal{P}^*)$ .  $\square$

## B.5 Hardness and Inversion Bound calculation scripts

We defer to the lattice estimator script for hardness. The inversion bounds are calculated with the following script.

```
# [LS18, eprint 2017-523] pg 6
# m is the cyclotomic polynomial index
def tau(m):
    return m if (m % 2) != 0 else m / 2

# [LS18, eprint 2017-523] Thm 1.1, pg 4
# m is the cyclotomic polynomial index
# p is the prime
# z is any divisor of m
# This tests for the condition for thm 1.1 to hold
def thm1_1_cond(m, p, z):
    cond1 = (p % z) == 1
    cond2 = Mod(p,m).multiplicative_order() == m/z
    return cond1 and cond2

# [LS18, eprint 2017-523] Thm 1.1, pg 4
# p is the prime
# z is any divisor of m
# lInf bound for elements to be invertible
# given that m,p,z satisfy thm 1.1 cond
def thm1_1_inv_bound(p, z):
    return (1/s1(z)*p^(1/euler_phi(z))).n()

def thm1_1_num_factors(z):
    return euler_phi(z)

# Output divisors of m
def divisors(m):
    zs = list()
    for i in range(1,m+1):
        if m % i == 0:
            zs.append(i)
    return zs

# [LS18, eprint 2017-523] pg 6, pg 9
# We only consider prime power cyclotomics
# m is the cyclotomic polynomial index
def s1(m):
    return sqrt(tau(m))
```

```

# checks if cyclotomic index m is power of two
def is_pow2(m):
    return sum(m.digits(2)) == 1

# [AL21] eprint Prop 2. 2021/202
# for all u,v in R, |u*v| / |v| <= gamma*|u|
# outputs T = gamma * |u|
# assumes we are only testing prime powers
def expansion_factor(m, norm):
    if is_pow2(m):
        return euler_phi(m) * norm
    else:
        return 2 * euler_phi(m) * norm

# p is prime
# max_idx is max cyclotomic index
# outputs list of (m, z)
def candidates(p, min_idx=10, max_idx=200):
    # prime powers
    possible_indices = [i for i in range(min_idx, max_idx) if len(factor(i)) == 1]
    c = list()
    for m in possible_indices:
        zs = divisors(m)
        for z in zs:
            if thm1_1_cond(m, p, z):
                c.append((Integer(m), Integer(z)))
    return c

def pre_filter(q, cyclotomic_index, z, chals):
    chals_max_diff = chals[-1] - chals[0]
    phi = cyclotomic_polynomial(cyclotomic_index) # index cyclotomic polynomial
    d = phi.degree() # degree of cyclotomic

    return chals_max_diff < thm1_1_inv_bound(q, z) and log(len(chals)^d,2).n() >= 120

def info(q, cyclotomic_index, z, chals):
    chals_norm = max({abs(c) for c in chals})
    chals_max_diff = chals[-1] - chals[0]
    phi = cyclotomic_polynomial(cyclotomic_index) # index cyclotomic polynomial
    d = phi.degree() # degree of cyclotomic
    T = expansion_factor(cyclotomic_index, chals_norm)

    print("####")
    print("Cyclotomic idx:", cyclotomic_index)
    print("Cyclotomic Poly:", phi)
    print("z:", z)
    print("Csmall norm is small enough?", chals_max_diff < thm1_1_inv_bound(q, z))
    print("Csmall large enough?", log(len(chals)^d,2).n() >= 120)
    print("Degree of Cyclotomic:", d)
    print("Expansion Factor T:", T)
    print("Invertible Norm bound:", thm1_1_inv_bound(q, z))
    print("log(|C_Small|):", log(len(chals)^d,2).n())
    print("Factors of Cyclotomic:", thm1_1_num_factors(z))
    print()

def possible_settings(q, chals):

```

```

for (cyclotomic_index, z) in candidates(q):
    if pre_filter(q, cyclotomic_index, z, chals):
        info(q, cyclotomic_index, z, chals)
    else:
        d = cyclotomic_polynomial(cyclotomic_index).degree()
        print(
            "[Does not satisfy challenge-set requirements] "
            "index: {}, degree: {}, z: {}, "
            "log(|C_Small|): {}, Invertible Norm bound: {}".format(
                cyclotomic_index,
                d,
                z,
                log(len(chals)^d,2).n(),
                thm1_1_inv_bound(q, z),
            )
        )

# Primes:
GL = 2^64 - 2^32 + 1
AGL = GL - 32
print("#####")
print("AGL #####")
print("#####")
# Small Challenge set
chals = [-1, 0, 1, 2]
possible_settings(AGL, chals)
print("#####")
print("M61 #####")
print("#####")
# Small Challenge set
chals = [-2, -1, 0, 1, 2]
possible_settings(2^61-1, chals)
print("#####")
print("GL #####")
print("#####")
# Small Challenge set
chals = [-2, -1, 0, 1, 2]
possible_settings(GL, chals)
print("#####")

```

## B.6 Lattice Estimator Script

```

from pathlib import Path
import sys

# Initialize this dependency with: git submodule update --init
sys.path.insert(0, str(Path(__file__).resolve().parent / "lattice-estimator"))

from estimator import *
Logging.set_level(Logging.LEVEL0)

M61 = 2^61 -1
GL = 2^64 - 2^32 +1
AGL = GL - 32
b = 2

kappa = 15

```

```

d = 64
k = 13
K = 50
B = b^k
n_R = 2^27
n_F = 2^33
assert n_F == n_R*d

T = 128
q = AGL

n_sis = kappa*d
m_sis = n_R*d
B_l2 = sqrt(n_R*d)*(8*T*B)

params = SIS.Parameters(n=n_sis, q=q, m=m_sis,length_bound=B_l2, norm=2)
_ = SIS.estimate(params)
print((K+k)*T*(b-1) < B)

kappa = 18
d = 54
k = 14
K = 61
B = b^k
n_R = 19884107
n_F = 2^30 - 46
assert n_F == n_R*d

T=216
q = GL

n_sis = kappa*d
m_sis = n_R*d
B_l2 = sqrt(n_R*d)*(8*T*B)

params = SIS.Parameters(n=n_sis, q=q, m=m_sis,length_bound=B_l2, norm=2)
_ = SIS.estimate(params)
print((K+k)*T*(b-1) < B)

kappa = 18
d = 54
k = 14
K = 61
B = b^k
n_R = 4971026
n_F = 2^28 - 52
assert n_F == n_R*d

T = 216
q = M61

n_sis = kappa*d
m_sis = n_R*d
B_l2 = sqrt(n_R*d)*(8*T*B)

params = SIS.Parameters(n=n_sis, q=q, m=m_sis,length_bound=B_l2, norm=2)

```

```
_ = SIS.estimate(params)
print((K+k)*T*(b-1) < B)
```
