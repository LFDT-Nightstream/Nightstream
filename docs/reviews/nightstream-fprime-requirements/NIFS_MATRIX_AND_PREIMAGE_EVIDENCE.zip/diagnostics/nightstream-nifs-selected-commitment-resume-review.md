# Independent selected commitment repair review

Reviewer: Worker 3, `/root/conformance_review`.
Baseline: `42aece71461d8997f62da5920b2874011c9e86c9` in
`/home/nicoarq/develop/Nightstream-nifs-proof-links`.

Result: **no defect found in the stated value and named-work claims**.
This is an independent source review of the frozen, uncommitted selected
checker and its actual row path. It is not a build result or an adapter
approval. The inspected `nightstream-nifs-selected-commitment-resume-3.log`
had no terminal target result. No build, test or active edit was made by
this reviewer. The review does not cover this worker's own totalized
comparison module.

## Exact repair and source authority

The current checker has 292 lines and 15,351 bytes. Compared with the old
273-line stopped draft, only the final value proof changes: `check_rows`,
`bool_value_of_rows`, and their use by `check_value`. The complete prefix
containing executable definitions is byte-identical. The `workBound` and
its proof are unchanged. The new helpers first prove a symbolic row/Boolean
equivalence, then substitute the selected commitment. Semantic commitment
functions and their `decide` terms occur in proofs, not as extra calls by
the executed checker.

The selected carrier at line 28 is the independent
`PaperAlgebra.FullShape PiDECInputCheck.logicalWidth PiDECInputCheck.publicFits`.
Its completed width is 254,260,620, or 4,708,530 complete 54-lane blocks.
`StoredWitness` contains 17 arrays at that width. `check` at line 236 reads
the chosen source array once. It requires no valid opening, accepted public
proof, sparsity, zero tail, or externally supplied primitive contract.

`publicCommitment` at line 89 reads the fresh 1,188-field commitment for
source zero, or running commitment `source-1` for sources 1 through 16.
`publicCommitment_value` proves equality to the same
`PiCCSInputCheck.outputCommitments` order. `claimView` and the existing input
decoder use the same `row*54+lane` packing. The checker compares against
this already stored array, with no semantic-function lookup charge.

`selectedRow` at line 165 calls the actual `StoredCommitment.row` with
`Poseidon2HashChainV1Setup.productionSetup`. That setup contains the existing
production seed; `productionAjtaiKey` is its existing indexed verifier-key
projection. `rowOpening_value` consumes the generic row theorem, and
`selectedRow_value` reaches the exact `PaperAlgebra.openingMaps` commitment.
No descriptor digest or separately supplied key is made authoritative.

## Actual dense row and comparison

The row at `StoredCommitment.lean:190` uses core `Fin.foldl` over every
complete carrier block. Its step expands 54 actual key coefficients through
`AjtaiSetupV1.Work.coefficient`, reads 54 corresponding stored witness
coordinates, multiplies the stored rings, and materializes the sum with the
stored accumulator. It retains the current blocks and accumulator, with no
full key table or growing accessor chain. Completion-tail coordinates are
included, regardless of their values.

The child value theorem reaches `Commitment.ajtaiRow`, whose definition at
`Commitment.lean:71` sums exactly those block products. The generator's
27,509-operation result, stored ring multiplication/addition, and array
builder have unchanged source identities from their prior scoped reviews.
Their relevant executed definitions and contracts were inspected again at
the selected call boundary. The coefficient generator still computes its
seed expansion and reduction; the child receives no cached coefficient
oracle. The selected work proof supplies row indices below `2^32` and a
block count at most `2^64` from the actual 22-row and 4,708,530-block profile.

`compareCoefficient` at line 131 reads both stored arrays and compares the
actual field values. `compareRow` uses all 54 coefficients from the one
computed row result. The outer check requires all 22 rows. These are Ajtai
commitment rows, not the separate 14 CCS matrix families.

Both comparison loops use direct `Fin.foldl`. Core Lean 4.30's
`Init/Data/Fin/Fold.lean:27` increments a direct natural index and constructs
the corresponding `Fin`. Reindexing through `index.succ` occurs only in the
proof. Once a comparison result is false, subsequent test calls are skipped,
but the remaining loop indices and control steps are still traversed and
charged. A successful check includes every dense block of every row.

## Work scope and remaining integration

The checked clock composition is:

- coefficient equality: 12 named operations;
- 54-lane comparison: at most 868;
- comparison of one computed row: its row work plus 870;
- outer row control: four per row;
- claimed-array selection: at most ten;
- source-array access and final envelope: four, in addition to the outer
  loop's initialization/return four.

Thus `check_work_le` bounds every typed input/source by
`22 * (StoredCommitment.rowWork carrier + 874) + 18`.
The child row bound is `223 + blockCount * 1,654,418`. If all 22 rows are
computed, the source has 103,587,660 ring products and 5,593,733,640 key
coefficient generations. These numbers follow from the selected dimensions;
they are not measured running times or imposed limits.

The imported `Vector.ofFnM` builder uses a preallocated array with direct
indices and pushes (`Init/Data/Vector/OfFn.lean:79`). Its existing grouped
loop clock remains the model. These results do not count compiled machine
instructions, all allocator activity, bit complexity, or gas. This review
did not execute the complete selected dense check. Producing the stored
input arrays and linking the full extraction representation remain separate.

The current `PiCCSStoredWitnessCheck` is unchanged and still has commitment
and matrix-entry contracts at lines 297 and 333. This source review does not
remove those contracts. A passing selected build, its audit, and the actual
adapter integration must be recorded separately. The old stopped draft's
failed status remains intact; it is not promoted by this new review.

## Source identities

Paths below are relative to `formal/nightstream-fprime/NightstreamFPrime/`.
SHA-256 records bytes only.

| Source | SHA-256 |
|---|---|
| `Export/Stage1/PiCCSStoredCommitmentCheck.lean` | `8e17f212c162c279941377e9772fe4e51441f0820d7c879abb475724997595a9` |
| `Export/Stage1/PiCCSStoredWitnessCheck.lean` | `7b1b92821e25fc76e7af47293860b39bc1941e22e4dbcbc2986a47ac26e3d9e9` |
| `Export/Stage1/PiCCSInputCheck.lean` | `cd46da12f09769fd36807dace85a2b046a33c0dcf60337fb9ac2d17695cf15a7` |
| `Export/Stage1/Poseidon2HashChainV1Setup.lean` | `b8fedbdd75c8730eb4f25bf39ee6e55b9b7e009a956078067aa9f324eda0d168` |
| `Spec/Phi81Relation/PiRLCAlgebra/StoredCommitment.lean` | `f955c6708d95871688ffe8312869a4790b021c801634905fe1bdaf4378c26890` |
| `Spec/Phi81Relation/PiRLCAlgebra/Commitment.lean` | `e33d7f2b0338dea84189a96d9fb09ce2640dd329204c55d256a2269bf6f121d7` |
| `Spec/Phi81Relation/EvaluationHomomorphism/StoredRingArithmetic.lean` | `b8adc58eb144b8896d007b33034d0ba52ca2194e5813f424fc6c424f61a91e90` |
| `Spec/AjtaiSetupV1/Work.lean` | `70fb5515ac20ca03dda5b260654b1ed6738f515d2009440c0a0007a0d4a8e561` |
| `Spec/Folding/Nifs/StoredAssignmentArithmetic.lean` | `5286553017b90af1c5f50ce2b85103da4c776e4103fd55dcc6f7591f71371362` |
| `Spec/Folding/PiCCS/PaperJoint/StoredWitnessCheckPrimitives.lean` | `d544ec7b6ce1ae398a527c7ba070138e9992fa21b528f330a73855d65cb11b0c` |
| `Lifecycle/PaperAlgebra.lean` | `1cf3c10fd22789f11006c63a0cb21792716e72edc0ad0e80e22d0df6ad4aa10e` |
