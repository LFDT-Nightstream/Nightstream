# Primary-source follow-up, 2026-09-10

Source: https://datatracker.ietf.org/doc/html/draft-irtf-cfrg-fiat-shamir-03 , published17August2026, accessed10September2026.

The updated draft describes XOF context copying and a separate output reader in3.2. Its8.4 still requires extraction-friendly indifferentiability and state-restoration knowledge soundness. These requirements do not discharge Nightstream's additive field schedule, initialization, shared-permutation query simulation, or classical extraction obligations. The general quantum-security prose does not supply a theorem for our exact protocol. No model or protocol change is selected. No newly closing theorem for the actual additive Poseidon2 schedule was found in this source.
