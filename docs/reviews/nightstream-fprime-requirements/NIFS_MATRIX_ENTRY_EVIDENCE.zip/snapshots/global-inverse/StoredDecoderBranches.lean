import NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredInverseInput
import NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredRectangleRank
import Mathlib.Data.Vector.Basic
import Mathlib.Tactic.FinCases

/-!
Stored success/abort transitions for the complete inverse. Each branch keeps
its exact rectangle, next stored suffix, and stored suffix count. Proof fields
bind every cached count to the checked table. Only the selected continuation
is executed by the parent inverse.
-/

namespace NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredDecoderBranches

open ProductionAlphabet FieldPairLaw FieldDecoderFiberCount FieldPreimageRectangle
open StoredInverseInput (Target Prepared)
open _root_.NightstreamFPrime.Spec.Folding.PiRLC.PaperForkExtractionWork (Result)

inductive Mode where
  | success
  | aborts

structure Cursor (prepared : Prepared target fallback) where
  position : Fin StoredFiberTables.rowWidth
  digits : List Coefficient
  digits_eq : digits = prepared.digits.drop position.val

def start (prepared : Prepared target fallback) : Result (Cursor prepared) :=
  ⟨⟨⟨0, by decide⟩, prepared.digits, by simp only [List.drop_zero]⟩, 5⟩

theorem cursor_length (cursor : Cursor prepared) :
    cursor.digits.length = coefficientCount - cursor.position.val := by
  rw [cursor.digits_eq, List.length_drop, StoredInverseInput.digits_length]

theorem cursor_empty_position (cursor : Cursor prepared) (empty : cursor.digits = []) :
    cursor.position.val = coefficientCount := by
  have length := cursor_length cursor
  rw [empty, List.length_nil] at length
  have inside := cursor.position.isLt
  unfold StoredFiberTables.rowWidth at inside
  omega

/-- Advance over one requested digit. At saturation retain the empty suffix. -/
def advance (cursor : Cursor prepared) : Result (Cursor prepared) :=
  match shape : cursor.digits with
  | [] => ⟨cursor, 3⟩
  | _ :: tail =>
      let j := cursor.position.val
      let next := j + 1
      have inside : next < StoredFiberTables.rowWidth := by
        have length := cursor_length cursor
        rw [shape, List.length_cons] at length
        have bound := cursor.position.isLt
        unfold StoredFiberTables.rowWidth at bound ⊢
        omega
      ⟨⟨⟨next, inside⟩, tail, by
        have same := congrArg List.tail cursor.digits_eq
        simpa only [shape, List.tail_cons, List.tail_drop] using same⟩, 10⟩

theorem advance_digits (cursor : Cursor prepared) :
    (advance cursor).value.digits = cursor.digits.tail := by
  cases shape : cursor.digits with
  | nil => simp only [advance, shape, List.tail_nil]
  | cons first tail => simp only [advance, shape, List.tail_cons]

theorem advance_work_le (cursor : Cursor prepared) : (advance cursor).work ≤ 10 := by
  unfold advance
  split
  · change (3 : Nat) ≤ 10; decide
  · change (10 : Nat) ≤ 10; decide

/-- Includes the complete seven-operation table read and its seven-operation wrapper. -/
def slot (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (cursor : Cursor prepared) : Result Nat :=
  let result := StoredFiberTables.read prepared.tables level cursor.position
  let cell := result.value
  match mode with
  | .success => ⟨cell.success, result.work + 7⟩
  | .aborts => ⟨cell.aborts, result.work + 7⟩

theorem slot_value (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (cursor : Cursor prepared) :
    (slot prepared mode level cursor).value =
      match mode with
      | .success => successCount level.val cursor.digits
      | .aborts => abortCount level.val cursor.digits.length := by
  have entry := StoredInverseInput.read_value prepared level cursor.position
  cases mode with
  | success => simpa only [slot, cursor.digits_eq] using entry.1
  | aborts => simpa only [slot, cursor_length] using entry.2

theorem slot_work (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (cursor : Cursor prepared) :
    (slot prepared mode level cursor).work = 14 := by
  cases mode <;> simp only [slot, StoredFiberTables.read_work]

structure Branch (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) where
  low : ChunkClass
  high : ChunkClass
  next : Cursor prepared
  weight : Nat
  suffix : Nat
  mass : Nat
  weight_eq : weight = FieldPreimageRectangle.size low high
  suffix_eq : suffix = (slot prepared mode level next).value
  mass_eq : mass = weight * suffix

private def makeBranch (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (next : Cursor prepared)
    (low high : ChunkClass) (weight : Nat)
    (correct : weight = FieldPreimageRectangle.size low high) :
    Result (Branch prepared mode level) :=
  let frequency := slot prepared mode level next
  let suffix := frequency.value
  let mass := weight * suffix
  ⟨⟨low, high, next, weight, suffix, mass, correct, rfl, rfl⟩, frequency.work + 5⟩

private theorem makeBranch_work (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (next : Cursor prepared)
    (low high : ChunkClass) (weight : Nat) (correct) :
    (makeBranch prepared mode level next low high weight correct).work = 19 := by
  simp only [makeBranch, slot_work]

private theorem rr_weight (prepared : Prepared target fallback) :
    prepared.weights.rr = FieldPreimageRectangle.size .reject .reject := by
  rw [prepared.weights_eq]
  rfl

private theorem rt_weight (prepared : Prepared target fallback) (digit : Coefficient) :
    prepared.weights.rt = FieldPreimageRectangle.size .reject (.residue digit) ∧
    prepared.weights.rt = FieldPreimageRectangle.size (.residue digit) .reject := by
  rw [prepared.weights_eq]
  simp [StoredInverseInput.expectedWeights, FieldPreimageRectangle.size, zeroBonus,
    ChunkClass.size, ChunkClass.HasZero]

private theorem rv_weight (prepared : Prepared target fallback) :
    prepared.weights.rv = FieldPreimageRectangle.size .reject .accepted ∧
    prepared.weights.rv = FieldPreimageRectangle.size .accepted .reject := by
  rw [prepared.weights_eq]
  simp [StoredInverseInput.expectedWeights, FieldPreimageRectangle.size, zeroBonus,
    ChunkClass.size, ChunkClass.HasZero]

private theorem th_weight (prepared : Prepared target fallback) (digit : Coefficient) :
    prepared.weights.th + (if digit.val = 0 then 1 else 0) =
      FieldPreimageRectangle.size (.residue digit) .all := by
  rw [prepared.weights_eq]
  simp only [StoredInverseInput.expectedWeights, FieldPreimageRectangle.size, zeroBonus,
    ChunkClass.size, ChunkClass.HasZero, and_true]
  ring

private theorem tt_weight (prepared : Prepared target fallback) (first second : Coefficient) :
    prepared.weights.tt + (if first.val = 0 then 1 else 0) * (if second.val = 0 then 1 else 0) =
      FieldPreimageRectangle.size (.residue first) (.residue second) := by
  rw [prepared.weights_eq]
  by_cases a : first.val = 0 <;> by_cases b : second.val = 0 <;>
    simp [StoredInverseInput.expectedWeights, FieldPreimageRectangle.size, zeroBonus,
      ChunkClass.size, ChunkClass.HasZero, a, b] <;> ring

private theorem vv_weight (prepared : Prepared target fallback) :
    prepared.weights.vv = FieldPreimageRectangle.size .accepted .accepted := by
  rw [prepared.weights_eq]
  simp only [StoredInverseInput.expectedWeights, FieldPreimageRectangle.size, zeroBonus,
    ChunkClass.size, ChunkClass.HasZero, true_and, if_true]
  ring

private theorem hh_weight : goldilocksModulus = FieldPreimageRectangle.size .all .all := by
  rw [goldilocks_decomposition]
  simp only [FieldPreimageRectangle.size, zeroBonus, ChunkClass.size, ChunkClass.HasZero,
    true_and, if_true, pairModulus]
  ring

/-- The only four acceptance patterns are RR, high only, low only, and both.
One remaining symbol instead uses RR, high only, or low followed by any high. -/
def branches (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (cursor : Cursor prepared) :
    Result (List (Branch prepared mode level)) :=
  let weights := prepared.weights
  match mode with
  | .success =>
      match cursor.digits with
      | [] =>
          let all := makeBranch prepared mode level cursor .all .all goldilocksModulus hh_weight
          ⟨[all.value], all.work + 12⟩
      | [digit] =>
          let advanced := advance cursor
          let next := advanced.value
          let extra := if digit.val = 0 then 1 else 0
          let finish := weights.th + extra
          let rr := makeBranch prepared mode level cursor .reject .reject weights.rr (rr_weight prepared)
          let rt := makeBranch prepared mode level next .reject (.residue digit) weights.rt (rt_weight prepared digit).1
          let th := makeBranch prepared mode level next (.residue digit) .all finish (th_weight prepared digit)
          ⟨[rr.value, rt.value, th.value], rr.work + rt.work + th.work + advanced.work + 35⟩
      | first :: second :: _ =>
          let advanced := advance cursor
          let next := advanced.value
          let advancedAgain := advance next
          let later := advancedAgain.value
          let firstZero := if first.val = 0 then 1 else 0
          let secondZero := if second.val = 0 then 1 else 0
          let both := weights.tt + firstZero * secondZero
          let rr := makeBranch prepared mode level cursor .reject .reject weights.rr (rr_weight prepared)
          let rt := makeBranch prepared mode level next .reject (.residue first) weights.rt (rt_weight prepared first).1
          let tr := makeBranch prepared mode level next (.residue first) .reject weights.rt (rt_weight prepared first).2
          let tt := makeBranch prepared mode level later (.residue first) (.residue second) both (tt_weight prepared first second)
          ⟨[rr.value, rt.value, tr.value, tt.value],
            rr.work + rt.work + tr.work + tt.work + advanced.work + advancedAgain.work + 51⟩
  | .aborts =>
      match cursor.digits with
      | [] => ⟨[], 6⟩
      | _ :: _ =>
          let advanced := advance cursor
          let next := advanced.value
          let advancedAgain := advance next
          let later := advancedAgain.value
          let rr := makeBranch prepared mode level cursor .reject .reject weights.rr (rr_weight prepared)
          let rv := makeBranch prepared mode level next .reject .accepted weights.rv (rv_weight prepared).1
          let vr := makeBranch prepared mode level next .accepted .reject weights.rv (rv_weight prepared).2
          let vv := makeBranch prepared mode level later .accepted .accepted weights.vv (vv_weight prepared)
          ⟨[rr.value, rv.value, vr.value, vv.value],
            rr.work + rv.work + vr.work + vv.work + advanced.work + advancedAgain.work + 34⟩

theorem branches_length (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (cursor : Cursor prepared) :
    (branches prepared mode level cursor).value.length ≤ 4 := by
  cases mode <;> cases shape : cursor.digits with
  | nil => simp only [branches, shape, List.length_nil, List.length_cons]; decide
  | cons first tail =>
      cases tail <;> simp only [branches, shape, List.length_nil, List.length_cons] <;> decide

theorem branches_work_le (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (cursor : Cursor prepared) :
    (branches prepared mode level cursor).work ≤ 147 := by
  have first := advance_work_le cursor
  have second := advance_work_le (advance cursor).value
  cases mode <;> cases shape : cursor.digits with
  | nil => simp only [branches, shape, makeBranch_work]; decide
  | cons firstDigit tail =>
      cases tail <;> simp only [branches, shape, makeBranch_work] <;> omega

def masses : List (Branch prepared mode level) → Result (List Nat)
  | [] => ⟨[], 3⟩
  | branch :: rest =>
      let mass := branch.mass
      let tail := masses rest
      ⟨mass :: tail.value, tail.work + 8⟩

theorem masses_value (entries : List (Branch prepared mode level)) :
    (masses entries).value = entries.map Branch.mass := by
  induction entries with
  | nil => rfl
  | cons first rest ih => simp only [masses, List.map_cons, ih]

theorem masses_work (entries : List (Branch prepared mode level)) :
    (masses entries).work = 8 * entries.length + 3 := by
  induction entries with
  | nil => rfl
  | cons first rest ih => simp only [masses, List.length_cons, ih]; omega

theorem branches_total (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (cursor : Cursor prepared) :
    (masses (branches prepared mode level cursor).value).value.sum =
      match mode with
      | .success => successCount (level.val + 1) cursor.digits
      | .aborts => abortCount (level.val + 1) cursor.digits.length := by
  rw [masses_value]
  cases mode with
  | success =>
      cases shape : cursor.digits with
      | nil =>
          simp only [branches, shape, List.map_cons, List.map_nil, List.sum_cons,
            List.sum_nil, Nat.add_zero, makeBranch, slot_value, shape, successCount]
      | cons first tail =>
          cases tail with
          | nil =>
              simp only [branches, shape, List.map_cons, List.map_nil, List.sum_cons,
                List.sum_nil, Nat.add_zero, makeBranch, slot_value, advance_digits,
                shape, List.tail_cons, List.tail_nil, successCount_one]
              rw [prepared.weights_eq]
              simp only [StoredInverseInput.expectedWeights]
              ring
          | cons second suffix =>
              simp only [branches, shape, List.map_cons, List.map_nil, List.sum_cons,
                List.sum_nil, Nat.add_zero, makeBranch, slot_value, advance_digits,
                shape, List.tail_cons, successCount_two]
              rw [prepared.weights_eq]
              by_cases a : first.val = 0 <;> by_cases b : second.val = 0 <;>
                simp [StoredInverseInput.expectedWeights, a, b] <;> ring
  | aborts =>
      cases shape : cursor.digits with
      | nil => simp only [branches, shape, List.map_nil, List.sum_nil, List.length_nil, abortCount_zero]
      | cons first tail =>
          simp only [branches, shape, List.map_cons, List.map_nil, List.sum_cons,
            List.sum_nil, Nat.add_zero, makeBranch, slot_value, advance_digits,
            shape, List.tail_cons, List.length_cons, List.length_tail, abortCount_step]
          rw [prepared.weights_eq]
          simp only [StoredInverseInput.expectedWeights]
          ring

abbrev Fields (lanes : Nat) := List.Vector F lanes

def Holds (mode : Mode) (cursor : Cursor prepared) (fields : Fields lanes) : Prop :=
  match mode with
  | .success => Sampling.FirstAccepted.boundedSample verifier cursor.digits.length
      (candidateList fields.get) = some cursor.digits
  | .aborts => Sampling.FirstAccepted.boundedSample verifier cursor.digits.length
      (candidateList fields.get) = none

abbrev Fiber (prepared : Prepared target fallback) (mode : Mode) (lanes : Nat)
    (cursor : Cursor prepared) := {fields : Fields lanes // Holds mode cursor fields}

def prepend (head : F) (tail : Fields lanes) : Result (Fields (lanes + 1)) :=
  let values := tail.val
  ⟨⟨head :: values, by simp only [List.length_cons, tail.property]⟩, 4⟩

def headTail (fields : Fields (lanes + 1)) : Result (F × Fields lanes) :=
  match shape : fields.val with
  | [] => False.elim (by have length := fields.property; rw [shape] at length; simp at length)
  | head :: tail =>
      ⟨(head, ⟨tail, by have length := fields.property; rw [shape, List.length_cons] at length; omega⟩), 7⟩

theorem prepend_get (head : F) (tail : Fields lanes) :
    (prepend head tail).value.get = Fin.cons head tail.get := by
  funext index
  refine Fin.cases ?_ (fun position => ?_) index
  · exact List.Vector.get_cons_zero head tail
  · exact List.Vector.get_cons_succ head tail position

theorem headTail_prepend (head : F) (tail : Fields lanes) :
    (headTail (prepend head tail).value).value = (head, tail) := rfl

theorem prepend_headTail (fields : Fields (lanes + 1)) :
    (prepend (headTail fields).value.1 (headTail fields).value.2).value = fields := by
  rcases fields with ⟨values, length⟩
  cases values with
  | nil => simp at length
  | cons head tail => rfl

theorem prepend_injective {left right : F} {first second : Fields lanes}
    (same : (prepend left first).value = (prepend right second).value) :
    left = right ∧ first = second := by
  have pairs := congrArg (fun fields => (headTail fields).value) same
  simpa only [headTail_prepend, Prod.mk.injEq] using pairs

theorem headTail_work (fields : Fields (lanes + 1)) : (headTail fields).work = 7 := by
  rcases fields with ⟨values, length⟩
  cases values with
  | nil => simp at length
  | cons head tail => rfl

def BranchMember (branch : Branch prepared mode level) (field : F) : Prop :=
  FieldPreimageRectangle.Member branch.low branch.high field

theorem branches_cover (prepared : Prepared target fallback) (mode : Mode)
    (level : Fin StoredFiberTables.levelCount) (cursor : Cursor prepared)
    (field : F) (tail : Fields level.val) :
    Holds mode cursor (prepend field tail).value ↔
      ∃ branch ∈ (branches prepared mode level cursor).value,
        BranchMember branch field ∧ Holds mode branch.next tail := by
  cases mode with
  | success =>
      change Sampling.FirstAccepted.boundedSample verifier cursor.digits.length
        (candidateList (prepend field tail).value.get) = some cursor.digits ↔ _
      rw [prepend_get, success_step_iff]
      cases shape : cursor.digits with
      | nil =>
          simp only [branches, shape, List.mem_cons, List.not_mem_nil, or_false,
            exists_eq_left, makeBranch, BranchMember, FieldPreimageRectangle.Member,
            ChunkClass.Member, true_and, Holds, shape]
          simp [Sampling.FirstAccepted.boundedSample, Sampling.FirstAccepted.firstAccepted]
      | cons first rest =>
          cases rest <;>
            simp only [branches, shape, List.mem_cons, List.not_mem_nil, or_false,
              exists_eq_or_imp, exists_eq_left, makeBranch, BranchMember, Holds,
              advance_digits, shape, List.tail_cons, List.tail_nil, List.length_cons,
              List.length_nil]
  | aborts =>
      change Sampling.FirstAccepted.boundedSample verifier cursor.digits.length
        (candidateList (prepend field tail).value.get) = none ↔ _
      rw [prepend_get, abort_step_iff]
      cases shape : cursor.digits with
      | nil => simp only [branches, shape, List.length_nil, List.not_mem_nil, false_and, exists_false]
      | cons first rest =>
          simp only [branches, shape, List.mem_cons, List.not_mem_nil, or_false,
            exists_eq_or_imp, exists_eq_left, makeBranch, BranchMember, Holds,
            advance_digits, shape, List.tail_cons, List.length_cons, List.length_tail]

end NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredDecoderBranches
