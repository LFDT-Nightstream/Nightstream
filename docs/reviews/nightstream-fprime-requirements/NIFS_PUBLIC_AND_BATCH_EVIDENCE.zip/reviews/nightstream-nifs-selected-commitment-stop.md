# Selected stored commitment check: stopped criterion

The complete selected-check criterion remains open. It must prove
`PiCCSStoredCommitmentCheck.check_value` and `check_work_le` for every stored
witness and each of the 17 sources. The check selects the actual fresh or
running commitment array, computes all required dense rows with the selected
setup, and compares stored coefficients. The proposed bound is
`22 * (StoredCommitment.rowWork carrier + 874) + 18` named operations.

Three full attempts used the target
`NightstreamFPrime.Export.Stage1.PiCCSStoredCommitmentCheck` through the root
build queue. No attempt passed.

- Round 1: terminal exit 1. The module reported a namespace error, a fold
  bound expression mismatch, and an unreduced running-source index. Other
  errors followed from the namespace failure. Log:
  `/tmp/nightstream-nifs-selected-commitment-check-1.log`.
- Round 2: root terminated the build after 195 seconds. Build exit 1;
  Lean exit 143. Sustained CPU use and about 7.5 GB RSS were observed. No
  source diagnostic was emitted before termination. Log:
  `/tmp/nightstream-nifs-selected-commitment-check-2.log`. Resource record:
  `/tmp/nightstream-nifs-selected-commitment-check-2-resource-stop.json`.
- Round 3: root terminated the build after more than six minutes. Build
  exit 1; Lean exit 143. Sustained CPU use and about 7.6 GB RSS continued.
  No source diagnostic was emitted before termination. Log:
  `/tmp/nightstream-nifs-selected-commitment-check-3.log`. Resource record:
  `/tmp/nightstream-nifs-selected-commitment-check-3-resource-stop.json`.

The suspected cause is concrete-row elaboration or normalization in the
selected value/work proof path. This is not proved; the logs do not locate
the stalled declaration. The path is `rowOpening_value` to the selected row
laws, then `compareRow`/`checkRow` value and work laws, then the two full check
exports. Selected shape reduction and the actual 4,708,530-block row result
remain possible expansion sites. Round 3 used explicit theorem arguments,
symbolic result-array helpers, and local/private opacity attributes. These
changes did not produce a terminal proof result.

Root preserved the complete final draft byte for byte at
`/home/nicoarq/develop/Nightstream-nifs-proof-links/docs/reviews/nightstream-fprime-requirements/drafts/NIFS_STORED_COMMITMENT_CHECK.lean.txt`:
273 lines, 14,057 bytes, SHA-256
`4089ad6a02977033253203275054ae5a268c38772677f3e99cd9d53424a9feb3`.
The new active module was removed. Its two exports have no registered audit.

The selected `PiCCSStoredWitnessCheck` adapter is unchanged by this criterion.
Its remaining primitive contracts are `commitmentCheck` and `matrixEntry`.
The generic stored row and coefficient programs remain passed and audited;
they do not establish the stopped selected-check exports.

The project three-round rule ends this criterion for this turn. No restore,
repair, fourth build, narrowed check, or dense witness execution was made
after the stop. This note records the open criterion; it does not claim a
runtime bound for the unvalidated selected adapter.
