import NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredFiberTables
import NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredFiberCopies

/-!
Preparation for the complete scalar inverse. Runtime data consists of the
stored target list, table, small weights, equality flag and normalizer.
The input Vectors occur as type/proof parameters after preparation; they
are not retained as duplicate runtime copies. Every cached value is proved.
-/

namespace NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredInverseInput

open ProductionAlphabet FieldPairLaw FieldDecoderFiberCount
open _root_.NightstreamFPrime.Spec.Folding.PiRLC.PaperForkExtractionWork (Result)

abbrev Target := StoredFiberTables.Target

private def equalPrefix (left right : Array Coefficient) :
    (count : Nat) → count ≤ left.size → count ≤ right.size → Result Bool
  | 0, _, _ => ⟨true, 3⟩
  | count + 1, leftBound, rightBound =>
      let l := left[count]'(by omega)
      let r := right[count]'(by omega)
      let lv := l.val
      let rv := r.val
      if lv = rv then
        let earlier := equalPrefix left right count (by omega) (by omega)
        ⟨earlier.value, earlier.work + 11⟩
      else ⟨false, 10⟩

private theorem equalPrefix_value (left right : Array Coefficient) (count : Nat)
    (leftBound : count ≤ left.size) (rightBound : count ≤ right.size) :
    (equalPrefix left right count leftBound rightBound).value = true ↔
      ∀ index (inside : index < count),
        left[index]'(by omega) = right[index]'(by omega) := by
  induction count with
  | zero => simp only [equalPrefix, Bool.true_eq, true_iff]; intro index inside; omega
  | succ count ih =>
      by_cases same : (left[count]'(by omega)).val = (right[count]'(by omega)).val
      · have entries : left[count]'(by omega) = right[count]'(by omega) := Fin.ext same
        simp only [equalPrefix, if_pos same]
        rw [ih (by omega) (by omega)]
        constructor
        · intro earlier index inside
          by_cases before : index < count
          · exact earlier index before
          · have last : index = count := by omega
            subst index
            exact entries
        · intro all index inside
          exact all index (by omega)
      · simp only [equalPrefix, if_neg same, Bool.false_eq_true, false_iff]
        intro all
        exact same (congrArg Fin.val (all count (by omega)))

private theorem equalPrefix_work (left right : Array Coefficient) (count : Nat)
    (leftBound : count ≤ left.size) (rightBound : count ≤ right.size) :
    (equalPrefix left right count leftBound rightBound).work ≤ 11 * count + 3 := by
  induction count with
  | zero => rfl
  | succ count ih =>
      have previous := ih (by omega) (by omega)
      unfold equalPrefix
      dsimp only
      split
      · omega
      · change (10 : Nat) ≤ _
        omega

attribute [irreducible] equalPrefix

private def sameTarget (left right : Target) : Result Bool :=
  let result := equalPrefix left.toArray right.toArray coefficientCount
    (by simp only [Vector.size_toArray]) (by simp only [Vector.size_toArray])
  ⟨result.value, result.work + 6⟩

private theorem sameTarget_value (left right : Target) :
    (sameTarget left right).value = true ↔ left = right := by
  change (equalPrefix left.toArray right.toArray coefficientCount _ _).value = true ↔ _
  rw [equalPrefix_value]
  constructor
  · intro entries
    apply Vector.ext
    intro index inside
    exact entries index inside
  · intro same
    subst right
    intro index inside
    rfl

private theorem sameTarget_work (left right : Target) :
    (sameTarget left right).work ≤ 11 * coefficientCount + 9 := by
  have bounded := equalPrefix_work left.toArray right.toArray coefficientCount
    (by simp only [Vector.size_toArray]) (by simp only [Vector.size_toArray])
  change (equalPrefix left.toArray right.toArray coefficientCount _ _).work + 6 ≤ _
  omega

structure Weights where
  rr : Nat
  rt : Nat
  rv : Nat
  tt : Nat
  th : Nat
  vv : Nat

def expectedWeights : Weights :=
  let m := pairModulus - 1
  ⟨m, m * acceptedQuotientCount, m * rejectionBucket,
    m * acceptedQuotientCount * acceptedQuotientCount,
    m * acceptedQuotientCount * chunkModulus, m * rejectionBucket * rejectionBucket + 1⟩

private def makeWeights (_ : Unit) : Result Weights :=
  let m := chunkModulus * chunkModulus - 1
  let rt := m * acceptedQuotientCount
  let rv := m * rejectionBucket
  let tt := rt * acceptedQuotientCount
  let th := rt * chunkModulus
  let vv := rv * rejectionBucket + 1
  ⟨⟨m, rt, rv, tt, th, vv⟩, 19⟩

private theorem makeWeights_value : (makeWeights ()).value = expectedWeights := rfl

theorem targetList_eq (target : Target) : List.ofFn target.get = target.toList := by
  have value := congrArg Vector.toList (Vector.ofFn_getElem (xs := target))
  simpa only [Vector.toList_ofFn, Vector.get, Fin.val_cast] using value

/-- All runtime caches have proof links to the original stored inputs.
The target/fallback parameters themselves are used only in these proofs. -/
structure Prepared (target fallback : Target) where
  digits : List Coefficient
  tables : StoredFiberTables.Tables
  weights : Weights
  same : Bool
  count : Nat
  digits_eq : digits = target.toList
  tables_eq : tables = (StoredFiberTables.build target).value
  weights_eq : weights = expectedWeights
  same_iff : same = true ↔ target = fallback
  count_eq : count =
    let initial := (StoredFiberTables.read tables (Fin.last FieldShortfall.fieldLaneCount)
      ⟨0, by decide⟩).value
    initial.success + if same then initial.aborts else 0

/-- Build each cache once. The largest wrapper branch has 23 named
operations; the five complete callee costs are charged separately. -/
def prepare (target fallback : Target) : Result (Prepared target fallback) :=
  let tables := StoredFiberTables.build target
  let digits := StoredFiberCopies.toList (count := coefficientCount) target
  let equal := sameTarget target fallback
  let weights := makeWeights ()
  let table := tables.value
  let inputDigits := digits.value
  let equalFlag := equal.value
  let weightValues := weights.value
  let initial := StoredFiberTables.read table (Fin.last FieldShortfall.fieldLaneCount) ⟨0, by decide⟩
  let cell := initial.value
  let count := if equalFlag then cell.success + cell.aborts else cell.success
  ⟨⟨inputDigits, table, weightValues, equalFlag, count,
    StoredFiberCopies.toList_value target, rfl, makeWeights_value, sameTarget_value target fallback,
    by dsimp only; cases equalFlag <;> simp only [Bool.false_eq_true, if_false, Nat.add_zero, if_true]⟩,
    tables.work + digits.work + equal.work + weights.work + initial.work + 23⟩

def prepareWork : Nat := StoredFiberTables.buildWork + (9 * coefficientCount + 8) +
  (11 * coefficientCount + 9) + 19 + 7 + 23

theorem prepare_work_le (target fallback : Target) : (prepare target fallback).work ≤ prepareWork := by
  have tables := StoredFiberTables.build_work_le target
  have equal := sameTarget_work target fallback
  change (StoredFiberTables.build target).work + (StoredFiberCopies.toList target).work +
    (sameTarget target fallback).work + 19 +
    (StoredFiberTables.read (StoredFiberTables.build target).value
      (Fin.last FieldShortfall.fieldLaneCount) ⟨0, by decide⟩).work + 23 ≤ prepareWork
  rw [StoredFiberCopies.toList_work, StoredFiberTables.read_work]
  unfold prepareWork
  omega

/-- The normalizer access itself is a projection and a Result construction. -/
def normalizer (prepared : Prepared target fallback) : Result Nat := ⟨prepared.count, 2⟩

theorem normalizer_work (prepared : Prepared target fallback) : (normalizer prepared).work = 2 := rfl

theorem digits_length (prepared : Prepared target fallback) :
    prepared.digits.length = coefficientCount := by
  rw [prepared.digits_eq]
  exact Vector.length_toList

theorem read_value (prepared : Prepared target fallback) (level : Fin StoredFiberTables.levelCount)
    (position : Fin StoredFiberTables.rowWidth) :
    (StoredFiberTables.read prepared.tables level position).value.success =
        successCount level.val (prepared.digits.drop position.val) ∧
    (StoredFiberTables.read prepared.tables level position).value.aborts =
        abortCount level.val (coefficientCount - position.val) := by
  rw [prepared.tables_eq, prepared.digits_eq, ← targetList_eq]
  exact StoredFiberTables.read_build_value target level position

theorem count_value (prepared : Prepared target fallback) :
    prepared.count = successCount FieldShortfall.fieldLaneCount prepared.digits +
      if target = fallback then abortCount FieldShortfall.fieldLaneCount coefficientCount else 0 := by
  rw [prepared.count_eq]
  dsimp only
  rw [(read_value prepared _ _).1, (read_value prepared _ _).2, List.drop_zero, Nat.sub_zero]
  by_cases same : prepared.same = true
  · rw [if_pos same, if_pos (prepared.same_iff.mp same)]
  · rw [if_neg same, if_neg (mt prepared.same_iff.mpr same)]

theorem count_positive (prepared : Prepared target fallback) : 0 < prepared.count := by
  rw [count_value]
  have positive := StoredFiberTables.successCount_pos FieldShortfall.fieldLaneCount prepared.digits (by
    rw [digits_length]
    decide)
  omega

theorem count_lt_twoPow2048 (prepared : Prepared target fallback) : prepared.count < 2 ^ 2048 := by
  rw [count_value]
  have bound := StoredFiberTables.count_sum_le FieldShortfall.fieldLaneCount prepared.digits
  rw [digits_length] at bound
  have width := StoredFiberTables.field_window_count_lt_twoPow2048
  split_ifs <;> omega

end NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredInverseInput
