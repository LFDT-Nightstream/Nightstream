Checked cut: parent 944a6c10 plus the listed source hashes. Static, library build (3853 jobs, 1s), and axioms (3942 jobs, 47s) passed in order. The preceding uncached library build passed in333s. Only propext, Classical.choice, and Quot.sound are allowed.

Independent local PiCCS review by nifs_conformance found no actionable finding: the exact existing interface, preserved protocol input, derived StateBinding, constructed Sequence.Prefix and generated PhaseHolds are used. This is local PiCCS completeness, not whole-package completeness.

Root reviewed the same-seed prefix reduction: full smaller carrier is preserved, zero padding is appended only at its end, seed equality is explicit, and nonzero/strict bound/kernel are preserved. This proves no MSIS hardness. Root reviewed the guarded law: false-mark paths retain operational draws, the same continuation is used, inactive guarded calls abort, and first source-failure mass is a partition identity. No visited acceptance invariant, FS model instantiation or work composition is claimed at this cut.

Package data, identity pins and Rust sources are unchanged by this proof cut.
