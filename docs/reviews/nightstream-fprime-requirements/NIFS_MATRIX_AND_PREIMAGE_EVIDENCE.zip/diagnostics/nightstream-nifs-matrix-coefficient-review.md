# Independent stored-row coefficient review

Reviewer: Worker 3, `/root/conformance_review`.
Worktree: `/home/nicoarq/develop/Nightstream-nifs-proof-links`.
Baseline: `42aece71461d8997f62da5920b2874011c9e86c9`.

Result: **no remaining defect found after the field-zero clock correction**.
This is source review before the first full build of `CoefficientWork`.
It does not certify a checked theorem, selected matrix-entry adapter, row
generator, or machine-runtime bound. The reviewer made no active edit and
ran no build, test, generator, or matrix execution.

## Value and actual inputs

The program consumes one already stored `SparseForm logicalWidth`, an output
coefficient in `Fin 54`, and an assignment column in the completed carrier.
It reads the assignment column once, derives its block by division by 54,
and derives its within-block assignment lane by remainder. It then considers
source lanes 0 through 53 in increasing order.

For each lane, the logical-width guard is
`(column.val / 54) * 54 + lane < logicalWidth`. A live logical source invokes
the stored sparse coefficient scan and the existing exact Phi81 kernel
weight, then multiplies them. A source outside the logical width contributes
zero. This is the correct guard: the queried assignment column can lie in
the completion tail while valid source lanes in its block still contribute
to nonconstant output coefficients. The code does not zero the entire result
merely because that queried column lies in the tail.

`SparseWork.coefficient` scans the complete stored entry list. Every matching
column contributes, including duplicates and cancellations, in the same
order as `SparseForm.coefficient`. There is no first-match lookup, sorting,
deduplication, or assumption that entry count is at most logical width.
All 54 source lanes are considered; only logical live lanes perform the
scan. No sparse form is generated or copied by this coefficient program.

The value theorem has the exact source parameters: row arity, fresh/running
counts, matrix count, logical width, matrix family, constraint polynomial,
one selected matrix slot, one Boolean vertex, output coefficient, and
completed assignment column. Its explicit premise states that the stored
form's coefficient at every logical column equals that matrix row. The
result is the corresponding coefficient of `Phi81MatrixSource.source`.

This premise is a row-generation/refinement obligation for the caller. It
is not an executed matrix callback or a new global model assumption. The
matrix family, vertex, and polynomial appear in the theorem, not the
program's arguments. The same source uses the completed layout, zero-extends
the supplied matrices, retains the supplied polynomial, and uses the existing
Phi81 kernel. `sum_value`, `term_value`, and the final `sumRange_congr` follow
that source's 54-lane expansion, including both encoding branches. No matrix
slot is dropped or merged. A later selected use must retain all 14 CCS slots;
Pad remains its separate owner.

## Clock correction and final counts

The initial reviewed file had SHA-256
`97bf08522aba1474eca2e0fcd5562ac648bf60ea1d7109043103175a4681f71b`.
The reviewer initially reported no count defect. The coordinator then asked
for an explicit check against the Sparse/Retained convention for constructing
field constants. That check found three missing field-zero construction
charges. The initial no-defect statement was withdrawn for those constants.
The coordinator corrected them before the first build, and the final source
was read again.

Final counts are:

- live term: 14 operations outside its two child clocks — two comparisons
  and branches (4), flat-index arithmetic (2), two `Fin` constructors (2),
  two calls and value reads (4), multiplication (1), and Result construction
  (1);
- logical-tail term: 8, including its executed comparisons/branches and
  arithmetic, field zero, and Result construction;
- out-of-range source-lane term: 4, including comparison, branch, field
  zero, and Result construction;
- empty sum: 3 for dispatch, field zero, and Result construction;
- sum step: 8 for dispatch/descent, two calls and value reads, addition,
  and Result construction;
- outer wrapper: 8 for column read, division/remainder, `Fin` construction,
  term closure, sum call, result-value read, and Result construction.

The duplicate-aware scan contributes at most `10*entries.length + 8`.
The existing kernel contributes `kernelWork`. The final proposed bound is
therefore `54*(10*entries.length + 8 + kernelWork + 14 + 8) + 3 + 8`.
It covers rejected source lanes as well as live lanes. Clock instrumentation
is excluded under the stated convention. This does not expand the imported
kernel's existing named-work model into a machine-runtime theorem.

## Limits and source identities

The stored row still needs to be generated, and its actual entry-list length
and equality to the selected matrix row still need the caller's proof.
Selected vertex decoding, row ownership/dispatch, and full matrix-entry
integration are outside this file. No full matrix or generated row family
was executed. No build result is claimed in this source review.

Paths are relative to `formal/nightstream-fprime/NightstreamFPrime/`.
The final coefficient file has 160 lines and 8,092 bytes. Hashes record byte
identity only.

| Source | SHA-256 |
|---|---|
| `Export/MatrixProgram/CoefficientWork.lean` | `e611f567f52e2dcfb7c4e9088c5ae4fff39d738ff866f65a3fad92e08fe79ef0` |
| `Export/MatrixProgram/SparseWork.lean` | `f0fb6484581a5844c45c8d0db1b4b4519691661cdf8433c4db8dcedf3be8ed09` |
| `Spec/Folding/PiCCS/PaperJoint/StoredWitnessCheckEntries.lean` | `b314be8e9a80db5db9ae8eb62f7a9f098eaa76ba3eb74af80d0779c305791f02` |
| `Spec/Folding/PiCCS/PaperJoint/MatrixCoefficientSource.lean` | `9721862260763811173e0e9ba38c4d99ef028a083d6a63563c27750dbd1247bd` |
| `Spec/Folding/PiCCS/PaperJoint/Phi81MatrixSource.lean` | `430e4faec7596099004f844e76e819824aa0d846727cf3bf385fac48e1c63c9d` |
| `Spec/Folding/PiCCS/PaperJoint/Phi81CarrierLayout.lean` | `e4c1c64f4c3734ead4192603f4bce9ca170754e5d16e679f677150a6557e179d` |
| `Spec/Folding/PiCCS/PaperJoint/Phi81ColumnLayout.lean` | `a6c6bd5b42f06f267565e74877a793d2a8824790941e5a93b0f6c858fafd848c` |
| `Layout/ProductionRelation.lean` | `e1451dfc43741b1788a6b49bb0bc04424bc34c700f87ff042e1b2fc4b6069f73` |
