import NightstreamFPrime.Spec.Folding.PiRLC.PaperForkExtractionWork
import Mathlib.Data.List.FinRange
import Mathlib.Logic.Equiv.Fin.Basic

/-!
Ordered interval selection for stored branch counts. The global scalar
inverse uses this for its field branches and its success/abort split.
No function oracle supplies counts. The clock charges the concrete list
walk; proofs and clock instrumentation are excluded.
-/

namespace NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredFiberIntervals

open _root_.NightstreamFPrime.Spec.Folding.PiRLC.PaperForkExtractionWork (Result)

abbrev Position (counts : List Nat) := Σ index : Fin counts.length, Fin (counts.get index)

/-- Skip zero intervals without a division or a random retry. -/
def select : (counts : List Nat) → Fin counts.sum → Result (Position counts)
  | [], rank => Fin.elim0 rank
  | count :: rest, rank =>
      let value := rank.val
      if first : value < count then
        ⟨⟨⟨0, by simp⟩, ⟨value, first⟩⟩, 10⟩
      else
        let reduced := value - count
        let child := select rest ⟨reduced, by
          have bound := rank.isLt
          simp only [List.sum_cons] at bound
          omega⟩
        let position := child.value
        let index := position.1
        let inside := position.2
        let next := index.val + 1
        ⟨⟨⟨next, by have := index.isLt; simp only [List.length_cons]; omega⟩, inside⟩,
          child.work + 18⟩

/-- Add the earlier stored intervals back in the same order. -/
def join : (counts : List Nat) → (index : Fin counts.length) →
    Fin (counts.get index) → Result (Fin counts.sum)
  | [], index, _ => Fin.elim0 index
  | count :: _, ⟨0, _⟩, rank =>
      ⟨⟨rank.val, by have := rank.isLt; simp only [List.get_eq_getElem, List.getElem_cons_zero] at this
                    simp only [List.sum_cons]; omega⟩, 6⟩
  | count :: rest, ⟨index + 1, bound⟩, rank =>
      let child := join rest ⟨index, by simpa only [List.length_cons, Nat.add_lt_add_iff_right] using bound⟩ rank
      let value := child.value
      ⟨⟨count + value.val, by
        have bound := value.isLt
        simp only [List.sum_cons]
        omega⟩, child.work + 13⟩

theorem join_select (counts : List Nat) (rank : Fin counts.sum) :
    (join counts (select counts rank).value.1 (select counts rank).value.2).value = rank := by
  induction counts with
  | nil => exact Fin.elim0 rank
  | cons count rest ih =>
      by_cases first : rank.val < count
      · apply Fin.ext
        simp only [select, dif_pos first, join]
      · have below : rank.val - count < rest.sum := by
          have bound := rank.isLt
          simp only [List.sum_cons] at bound
          omega
        have child := ih ⟨rank.val - count, below⟩
        apply Fin.ext
        simp only [select, dif_neg first, join]
        change count + (join rest (select rest ⟨rank.val - count, below⟩).value.1
          (select rest ⟨rank.val - count, below⟩).value.2).value.val = rank.val
        rw [child]
        omega

theorem select_join (counts : List Nat) (index : Fin counts.length)
    (rank : Fin (counts.get index)) :
    (select counts (join counts index rank).value).value = ⟨index, rank⟩ := by
  induction counts with
  | nil => exact Fin.elim0 index
  | cons count rest ih =>
      rcases index with ⟨index, bound⟩
      cases index with
      | zero =>
          have first : rank.val < count := rank.isLt
          simp only [join, select, dif_pos first]
      | succ index =>
          have inside : index < rest.length := by simpa only [List.length_cons] using bound
          have child := ih ⟨index, inside⟩ rank
          have later : ¬count + (join rest ⟨index, inside⟩ rank).value.val < count := by omega
          simp only [join, select, dif_neg later, Nat.add_sub_cancel_left]
          change
            (⟨⟨(select rest (join rest ⟨index, inside⟩ rank).value).value.1.val + 1, _⟩,
              (select rest (join rest ⟨index, inside⟩ rank).value).value.2⟩ : Position (count :: rest)) = _
          rw [child]

theorem select_work_le (counts : List Nat) (rank : Fin counts.sum) :
    (select counts rank).work ≤ 18 * counts.length := by
  induction counts with
  | nil => exact Fin.elim0 rank
  | cons count rest ih =>
      by_cases first : rank.val < count
      · change (select (count :: rest) rank).work ≤ _
        simp only [select, dif_pos first, List.length_cons]
        omega
      · have below : rank.val - count < rest.sum := by
          have bound := rank.isLt
          simp only [List.sum_cons] at bound
          omega
        have child := ih ⟨rank.val - count, below⟩
        simp only [select, dif_neg first, List.length_cons]
        omega

theorem join_work_le (counts : List Nat) (index : Fin counts.length)
    (rank : Fin (counts.get index)) :
    (join counts index rank).work ≤ 13 * counts.length := by
  induction counts with
  | nil => exact Fin.elim0 index
  | cons count rest ih =>
      rcases index with ⟨index, bound⟩
      cases index with
      | zero => simp only [join, List.length_cons]; omega
      | succ index =>
          have inside : index < rest.length := by simpa only [List.length_cons] using bound
          have child := ih ⟨index, inside⟩ rank
          simp only [join, List.length_cons]
          omega

/-- The selected interval is inhabited, even if other stored counts are zero. -/
theorem selected_positive (counts : List Nat) (rank : Fin counts.sum) :
    0 < counts.get (select counts rank).value.1 :=
  lt_of_le_of_lt (Nat.zero_le _) (select counts rank).value.2.isLt

end NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredFiberIntervals
