# Stored ring arithmetic: scoped source review

Reviewer: Worker 2, `/root/fiat_shamir_model`.
Date: 2026-09-10.
No active source edits, Lean commands, Rust commands, or backend calls ran.

The reviewed source is
`formal/nightstream-fprime/NightstreamFPrime/Spec/Phi81Relation/EvaluationHomomorphism/StoredRingArithmetic.lean`,
SHA-256 `b8adc58eb144b8896d007b33034d0ba52ca2194e5813f424fc6c424f61a91e90`.
The imported builder owner is
`Spec/Folding/Nifs/StoredAssignmentArithmetic.lean`, SHA-256
`5286553017b90af1c5f50ce2b85103da4c776e4103fd55dcc6f7591f71371362`.
These hashes identify reviewed bytes; they are not protocol authority.

## Result and scope

No value or storage-interface defect was found in this scope. The work
theorems bound the returned named-operation clock. They do not establish
compiled Lean runtime, machine instructions, or a complete count of every
primitive control operation. This review does not assert that the new
module has passed Lean or the combined axiom gate; the coordinator owns
those checks.

The shared builder convention is explicit: each coordinate contributes its
program clock plus two grouped operations for the loop branch and array
push. Initial capacity and final return have separate charges. This is the
existing `StoredAssignmentArithmetic` convention. `Vector.ofFnM.go` also
contains comparison, index increment, and bounded-index construction; those
are within the inherited grouped loop convention, not separate primitive
charges in `build`. Result-clock instrumentation is outside the measured
program clock. No wider runtime claim follows from these counters.

## Value and access checks

- `StoredRing` is `Vector F 54`, the same carrier as the stored inverse.
  The semantic coefficient function is the vector's array view.
- `rawTerm` reads both actual vector arrays. On its live path, its charge
  15 accounts for three comparisons and branches, one subtraction, two
  bounded indices, two array projections and reads, one field product, and
  a result return. Its charges 3, 5, and 8 follow the executed rejection
  prefixes. No semantic key or arbitrary coefficient function receives a
  constant access charge.
- `sum` traverses a bounded prefix structurally. `raw_prefix_value`
  matches the existing coefficient convolution, including the zero terms.
- `coefficient` matches `ringFMul`: the low coefficient, the selected
  negative fold, and the positive second reduction at degrees 81 through
  106. All public-call indices are fixed ring coordinates or their fixed
  offsets. There is no field-sized enumeration.
- `multiply`, `one`, and `add` call the array builder. Each returns all 54
  stored coefficients. Their value theorems identify the exact existing
  ring operations, rather than a separate arithmetic relation.
- `raw_work_le`, `coefficient_work_le`, and the public work bounds compose
  the same calls used to produce their returned values. The multiplication
  bound allows three raw convolutions for every output coordinate; this
  also covers coordinates where the final convolution is skipped.

## Consumer boundary

The interface is suitable for a materialized power loop: `multiply` can
square an array or multiply two arrays, and `one` constructs its identity.
Read-only aliasing of the two multiplication operands does not change the
value or returned work statements. The output is a fresh builder result.

`multiply` and `add` are suitable components of a dense commitment dot
product. The complete commitment consumer still must own its key expansion,
packing, stored key and witness access, zero accumulator, traversal, and
comparison costs. This module alone supplies none of those totals.

A power-based inverse still needs its executed exponent construction and
power loop, a sufficient depth bound, the unit-input equality, and its own
work theorem. Selection against the existing xgcd implementation remains
subject to the coordinator's runtime comparison. No inverse selection,
Fiat-Shamir model, or cryptographic premise is approved by this review.
