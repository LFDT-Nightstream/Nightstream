#!/usr/bin/env python3
"""Seal the allocation source and existing evidence; run no build or test."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


BASE = "c21f4ac8f1a5bdbd23a20e93d970670c5addb6f0"
REPORT = "docs/reviews/nightstream-fprime-requirements/NIFS_UNUSED_ALLOCATIONS.md"
ARTIFACT_DIR = "formal/nightstream-fprime/artifacts/"
FIXTURES = {
    "candidate.json": "nightstream-fprime-stage1-poseidon2-hash-chain-v1-candidate.json",
    "expanded.json": "nightstream-fprime-stage1-poseidon2-hash-chain-v1-expanded.json",
    "binding.json": "nightstream-fprime-stage1-poseidon2-hash-chain-v1-binding-v1.json",
    "base-fixture.json": "nightstream-fprime-stage1-base-step-fixture-v1.json",
    "setup.json": "nightstream-fprime-ajtai-setup-v1-parity.json",
    "piccs-parity.json": "nightstream-fprime-stage1-piccs-parity-v1.json",
    "pirlc-parity.json": "nightstream-fprime-stage1-pirlc-parity-v1.json",
    "pidec-parity.json": "nightstream-fprime-stage1-pidec-parity-v1.json",
    "application-parity.json": "nightstream-fprime-stage1-poseidon2-hash-chain-v1-parity.json",
    "pilot-parity.json": "nightstream-fprime-stage1-pilot-parity-v1.json",
    "piccs-ownership.json": "nightstream-fprime-stage1-piccs-ownership-v1.json",
}


def info(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("worktree", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.worktree.resolve()
    evidence = Path("/tmp/nightstream-unused-allocation-evidence")
    if args.output.exists():
        raise SystemExit("Use a fresh archive path; existing evidence is not overwritten.")
    report = root / REPORT
    if "PENDING_FINAL_" in report.read_text():
        raise SystemExit("The report still has a pending final gate.")

    def git(*arguments):
        return subprocess.check_output(["git", "-C", str(root), *arguments])

    changed = set(git("diff", "--name-only", BASE, "--").decode().splitlines())
    changed.add(REPORT)
    sources = sorted(path for path in changed if not path.startswith(ARTIFACT_DIR))
    # This unchanged owner supplies the same-seed key and zero-extension proof.
    sources.append("formal/nightstream-fprime/NightstreamFPrime/Spec/AjtaiSetupV1/Prefix.lean")
    source_delta = git("diff", "--binary", BASE, "--", ".", ":(exclude)" + ARTIFACT_DIR)
    logs = set()
    for pattern in (
        "nightstream-unused-allocations-*.log",
        "nightstream-unused-nonzero-*.log",
        "nightstream-unused-pilot-*.log",
        "nightstream-unused-optimized-parity-*.log",
    ):
        logs.update(Path("/tmp").glob(pattern))
    required = [
        Path("/tmp/nightstream-unused-allocations-" + name + ".log")
        for name in (
            "strict-assignment-1", "strict-assignment-2", "static-repin",
            "build-repin", "axioms-repin", "identity-repin", "loader-repin",
            "pilot-binding-repin",
        )
    ]
    for path in required:
        if not path.is_file():
            raise SystemExit("Missing final or attempt log: " + str(path))

    installed = []
    for fixture, artifact in FIXTURES.items():
        original = info(evidence / "fixtures" / fixture)
        copied = info(root / ARTIFACT_DIR / artifact)
        if original["sha256"] != copied["sha256"]:
            raise SystemExit("Installed fixture differs: " + artifact)
        installed.append({"source": original, "installed": copied, "exact_copy": True})
    published = info(root / ARTIFACT_DIR / "nightstream-fprime-stage1-poseidon2-hash-chain-v1.json")
    if published["sha256"] != installed[0]["source"]["sha256"]:
        raise SystemExit("Published package differs from the checked candidate.")

    records = {}
    for name in sources:
        path = root / name
        if path.is_file():
            records["source/" + name] = path
    for path in sorted(logs):
        records["logs/" + path.name] = path
    for path in evidence.rglob("*"):
        if path.is_file() and path.name not in {"candidate.json", "expanded.json"}:
            records["comparison/" + str(path.relative_to(evidence))] = path
    for name in (
        "nightstream-convert-nonzero-parity.py",
        "nightstream-unused-optimized-parity-result.json",
        "nightstream-unused-optimized-parity-result.md",
        "nightstream-unused-optimized-parity-readiness.json",
        "nightstream-unused-optimized-parity-readiness.md",
        "nightstream-unused-optimized-parity.patch",
    ):
        records["prepin/" + name] = Path("/tmp") / name
    records["packaging.py"] = Path(__file__).resolve()
    manifest = {
        "scope": "Unused retained allocation removal; no full native C/R/D or whole witness closure claim.",
        "base": BASE,
        "head": git("rev-parse", "HEAD").decode().strip(),
        "status": git("status", "--short").decode(),
        "source_delta_sha256": hashlib.sha256(source_delta).hexdigest(),
        "installed_exact_copies": installed,
        "published_package": published,
        "members": {name: info(path) for name, path in sorted(records.items())},
        "large_artifact_policy": "Candidate, published and expanded bytes stay in the tracked artifact store; identities above retain their exact SHA-256 and sizes.",
        "attempt_note": "strict-assignment-1 reached the 300 s cap and was killed. Its timing wrapper's Exit status: 0 does not indicate success. strict-assignment-2 completed.",
    }
    with zipfile.ZipFile(args.output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
        archive.writestr("source.patch", source_delta)
        for name, path in sorted(records.items()):
            archive.write(path, name)
    print(json.dumps(info(args.output), indent=2))


if __name__ == "__main__":
    main()
