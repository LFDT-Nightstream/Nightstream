# Independent consumer documentation and map review

Reviewer: Worker 3, `/root/conformance_review`.
Checked source cut: `286dc71a543d28d52e430e9466ab5cecea01de7d`.
Worktree: `/home/nicoarq/develop/Nightstream-nifs-proof-links`.

Result: no necessary false or stale claim remains in the requested delta.
One state-scope correction was required and is now present: the comparison
preserves the sampler's `Batch.finalState`, separately from the complete
Running result. The NIFS verifier does not return a separate full-verifier
state. The coordinator fixed that wording in all three new report sections
and in the Fiat–Shamir map node.

## Reviewed bytes and boundary

I compared the map with `/tmp/nightstream-nifs-consumers-map-before.json`
and read the new report sections, changed active-criteria text, and current
model-note introduction. I did not repeat the closed source/audit review.
The conformance report at the code cut remains an exact byte prefix of the
current report; its original review and later historical scope are preserved.

All report paths below have worktree-relative prefix
`docs/reviews/nightstream-fprime-requirements/`.

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `NIFS_PROOF_LINKS.md` | 74165 | `8a5d92ecc40e35de1fbcd0d39c31275135fc0e83257aae5c32ed78991028fe58` |
| `NIFS_FIAT_SHAMIR_MODEL_DECISION.md` | 45955 | `b1225eb8ad79ba5a6174aef7a2c8d05ef1b050155167bbd4882d5c2558ebb0d1` |
| `NIFS_CONFORMANCE_REVIEW_773f3d0f.md` | 77703 | `bab8cfe09dfa18d70bae107e366af90575f184758553a250cfd2c81b42ac4e0d` |
| `site/requirements.json` | 471576 | `fde8abe5953b111c8027f49b1759e4396f90d69f3f5822b79e8c252834e2a296` |

The baseline map is 633038 bytes, SHA-256
`862d9b5633ffe066b50dae69cad8d81ba4f4646b9c804c12e467a25875f616a5`.
The final map uses the compact serialization; the checks below compare
parsed node objects, not formatting.

## Node preservation and links

Both maps contain 454 nodes. Exactly 451 complete node objects are unchanged.
Only `N.security.binding`, `N.security.fiat_shamir`, and
`N.conformance.owners` change. In each, only `code` and `remaining` change.
All proof/connection/Rust statuses remain respectively:

- binding: assumption / partial / not_required;
- Fiat–Shamir: assumption / open / implemented;
- owners: not_required / partial / not_required.

Only `nodes` and the new `nifs_consumers_update` change at the top level.
Earlier milestone metadata is unchanged. The new metadata identifies the
correct code cut, 402 records and 24 additions, the named remaining links,
and false values for model approval, PaperExact execution, and publication.

All thirty added or repositioned link records match their named declarations.
There are fifteen distinct destinations:

- PiDECOrdinarySourceWork: commitmentRow_data 337, commitmentRow_lengths 349,
  commitmentRow_work_le 360;
- PiDECCommitmentMatrixWork: commitmentForms_value 516,
  commitmentForms_lengths 532, commitmentForms_work_le 542;
- TotalizedComparison: accepted_actual_implies_comparison 205;
- PerApplicationSamplerComparison:
  verifierBoundRowsZero_implies_base_or_comparison 89;
- StoredFiberTables: build_value 481, build_work_le 493,
  read_build_value 538, initial_success_pos 545;
- StoredSamplerFiberTables: fiber_card 18, fiber_positive 32,
  fiber_lt_twoPow2048 41.

## Claim consistency

The reports distinguish actual accepted verifier output from the comparison
experiment and preserve the base/recursive step split. They use the same
canonical key, proof, statement, and actual C outgoing sampler state. They
do not add theorem8 or a cryptographic premise. The accepted-output link is
now checked; the earlier inactive comparison draft is correctly superseded.
The current selected commitment draft remains inactive and unvalidated.

The selected PiDEC form statement covers every Fin1188 row at the existing
selected geometry. The lengths 1/657/1/42 match the selector/A/B/C theorem;
the declared bound evaluates to 2218+10+17*14843+154+12+4=254729. The report
keeps full matrix dispatch and other row families open. Checking that report
against the exported statements does not replace the coordinator's independent
source review of the full PiDEC implementation.

The stored DP text correctly covers all 33-by-55 paired cells, exact decoder
counts, positive complete scalar fibers, and the integer-size bound. Its
425407 construction count and read-seven result are explicitly named work.
The omitted literal/wrapper charges and their correction remain recorded.
Global weighted rank/unrank, uniform-rank sampling and expected work, product
and joint cache/query laws, additive schedule/initialization, state restoration,
and fixed-Poseidon2 security transfer remain open. No random inverse, bit-time,
gas, numerical security level, model approval, or full conformance is claimed.

The report's 402 complete records, 24 additions, permitted axioms, and passing
static status agree with `/tmp/nightstream-nifs-consumers-milestone-review.md`.
Its distinction between authorship, coordinator review, and independent
worker review remains explicit. I do not treat review of documentation about
my two comparison files as independent approval of their source proofs.

The 17:20 protected-review log has the same review contents as 16:20; its only
text differences are the new timestamp and one blank-line separator. The
retained final map-build log reports 454 nodes. The map-test log reports seven
tests, 0.077 seconds, and OK. I did not rerun those commands.

The coordinator is packaging `NIFS_CONSUMERS_EVIDENCE.zip` with these notes.
This review checks its documentation reference, not the final ZIP inventory.
No active file, archive, or source was edited for this review, and no build,
test, PaperExact, backend, or publishing command was run.
