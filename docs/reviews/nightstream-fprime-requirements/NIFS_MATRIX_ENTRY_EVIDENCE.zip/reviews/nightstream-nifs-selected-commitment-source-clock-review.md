# Selected commitment source-clock review

Independent reviewer: Worker 3, `/root/conformance_review`.
Continuation starts at `225b271f`. No implementation file, build, or test
was changed or run for this review.

The complete selected commitment value proof now passes. Its old returned
counter bound also remains a valid Lean theorem about that counter. The
earlier source-review statement that those counts cover complete source
operations was too broad: iterator, literal, call, and projection operations
were omitted. This does not revoke any value theorem or declared-counter
theorem. It leaves an explicit counter-to-source/runtime refinement to prove.

## Source identities

These are the pre-correction bytes read under
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/`:

| Owner | SHA-256 |
| --- | --- |
| `Export/Stage1/PiCCSStoredCommitmentCheck.lean`, 309 lines | `24928891f8abef0de640675ea8dac2bb8d14311d25ce2688f7177f3bcae9fcb8` |
| `Spec/Phi81Relation/PiRLCAlgebra/StoredCommitment.lean` | `f955c6708d95871688ffe8312869a4790b021c801634905fe1bdaf4378c26890` |
| `Spec/Phi81Relation/EvaluationHomomorphism/StoredRingArithmetic.lean` | `b8adc58eb144b8896d007b33034d0ba52ca2194e5813f424fc6c424f61a91e90` |
| `Spec/Folding/Nifs/StoredAssignmentArithmetic.lean` | `5286553017b90af1c5f50ce2b85103da4c776e4103fd55dcc6f7591f71371362` |
| `Spec/AjtaiSetupV1/Work.lean` | `70fb5515ac20ca03dda5b260654b1ed6738f515d2009440c0a0007a0d4a8e561` |

The coordinator's full symbolic-wrapper check is retained in
`/tmp/nightstream-nifs-selected-commitment-symbolic-1.log`, terminal exit 0,
10 seconds. Temporary diagnostic markers were removed before the selected
source hash above was read. The corrections proposed below have not yet been
validated at the time of this record.

## Exact finite-loop administration

Lean 4.30 implements Fin.foldl at
`/home/nicoarq/.elan/toolchains/leanprover--lean4---v4.30.0/src/lean/Init/Data/Fin/Fold.lean:27`:

```text
foldl n f init = loop init 0
loop x i = if i<n then loop (f x <i>) (i+1) else x
```

This is a direct Nat-index loop. The Fin.foldl_succ theorem used in the
proof is a semantic equation; its reindexed function does not describe an
additional executed closure chain.

Each live iteration has seven operations outside the callback body:
comparison, branch, Fin constructor, callback call, literal one, increment,
and recursive loop call. The zero literal and first loop call add two; the
terminal comparison and branch add two. Therefore the administration is
7*n+4, excluding the external Fin.foldl call and callback-body work. An
already-false accumulator still executes this administration at every
remaining index; it only skips the test/dense-row calls.

The selected advance true branch needs five operations: accumulated.value,
branch, test call, checked.value, and Result. The false branch needs four:
accumulated.value, branch, false literal, and Result. The original true-four
clock omitted the test call.

## Exact proposed selected-wrapper counts

The coordinator accepted explicit toArray/Nat-index reads for this leaf.
They remove the ambiguity in treating Vector.get as a single primitive.
Core Vector.get at `Init/Data/Vector/Basic.lean:100` contains a vector-to-array
projection, an index projection, and the actual array lookup. The proposed
code spells out and shares the needed Nat indices directly. Type/index
proofs are erased. Fixed F equality remains the existing two-operation
primitive (comparison and Result).

| Owner / precise proposed body | Count outside callee work |
| --- | ---: |
| publicCommitment fresh: source.val, literal one, comparison/branch, input.commitment, Result | 6 |
| publicCommitment running: same four prefix operations; literal one/subtraction; input.running/prior.commitments; toArray/read at the rebased Nat; Result | 11 |
| compareCoefficient: row.val/lane.val once, literal54/multiply/add, two toArray/read pairs, equalF call, checked.value, Result | 12, plus equalF=2, hence 14 |
| allFin: callback closure, initial true/Result, Fin.foldl call, result.value, Result | 6, plus 7*n+4 and callback bodies |
| compareRow: computed.value, coefficient closure, literal54, allFin call, compared.value, Result | 6 |
| selectedRow Result wrapper: StoredCommitment.row call, returned value read, Result | 3 |
| checkRow Result wrapper: selectedRow call, compareRow call, returned value read, Result | 4 |
| final check: source.val/toArray/lookup; publicCommitment call/value; row closure; literal22; allFin call; checked.value; Result | 10 |

For publicCommitment's running branch, the executable rebased index is Nat,
not a newly constructed Fin followed by another Fin projection. For
compareCoefficient, the flat Nat column is used directly for the array read.
The same authoritative address and row/lane bounds still determine both.
The selectedRow and checkRow Result wrappers are explicit data/clock
wrappers; their construction and value reads are counted, not assumed free.

The allFin initial Result must charge two for true and its constructor.
Adding `7*count+8` to the final folded counter then accounts for its internal
administration and remaining wrapper operations. If test work is bounded
by b, the resulting bound is

```text
allFin(n,b) <= n*(b+12)+10.
```

Thus the 54-lane comparison is at most 54*(14+12)+10=1414. compareRow adds
six, giving computed.work+1420. If Rcounter is the existing declared row
counter bound, the explicit selectedRow and checkRow wrappers give
checkRow <= Rcounter+3+1420+4 = Rcounter+1427. The outer allFin and public
selection/return then give the exact proposed selected counter bound

```text
22*(Rcounter+1439)+31.
```

This is a composition of the existing child counter with the corrected
selected wrapper/iterator charges. Rcounter must not be renamed a complete
source-operation or machine-runtime bound. A complete refinement of its
direct children remains open. No new correctness/work premise is to be
introduced merely to hide that obligation.

## Directly consumed child-counter gaps

The scope below is the called commitment path. It does not request an audit
or edit of unrelated scalar APIs.

1. **StoredCommitment.step, lines92-106.** Its four child clocks are summed
   with only one extra operation. The value body has four calls, four value
   projections (key, witness, product, sum), and Result construction: nine
   operations outside child clocks. StoredCommitment.advance at133 needs
   four, not three: accumulated.value, next call, returned value, Result.
   The row at190 invokes Fin.foldl but rowWork210 contains no 7*n+4 iterator
   allowance. Its closure creation, zero call/Unit, count calculation, fold
   call, and final value/Result also require an explicit wrapper account.
   These differences are source-operation refinement gaps, not false Lean
   equations about the old .work fields.

2. **StoredAssignmentArithmetic.build, lines24-32/74.** This is the exact
   shared builder boundary used by zero, keyBlock, witnessBlock, and stored
   ring arithmetic. It calls Vector.ofFnM, whose implementation at
   `Init/Data/Vector/OfFn.lean:90` has a direct index loop, a callback, and an
   Array.push. The old +2 per coordinate and width+1 initialization are
   declared counters; they do not enumerate the actual comparison/branch,
   Fin/index movement, calls/projections, StateM value construction, and
   possible shared-array prefix-copy work under the current convention.
   Its source-operation refinement must provide the common counted builder
   contract before its downstream arithmetic can close runtime work.

3. **StoredRingArithmetic.sum, lines22-27.** Base source work is dispatch,
   F-zero, and Result: three, versus the current counter two. A successor
   has dispatch/predecessor, recursive/term calls, two value projections,
   F addition, and Result: eight, versus counter four. The raw wrapper at67
   also has a captured closure, the count54 literal, sum call, value read,
   and Result: five, versus counter two. multiply/add use the shared build
   boundary above. Their existing value/counter laws remain valid; they
   do not supply the missing single source-operation refinement.

4. **AjtaiSetupV1.Work.quarter, lines71-95.** Its +1 outside child clocks
   omits 21 child calls, 28 .value projections, and four rotation literals;
   the full wrapper is 54 including Result. The double wrapper at121 has
   eight quarter calls, eight value projections, 32 index literals, and
   Result: 49, versus counter one. The recursive rounds wrapper at157 has
   seven successor operations (dispatch/predecessor, two calls, two value
   reads, Result), versus counter three. Fixed F/Word arithmetic remains
   named primitive work. Correcting these composite wrappers and their
   callers is a further source-clock obligation; the current coefficient
   value theorem and returned 27509 counter theorem are not revoked.

The small row wrappers zero/keyBlock/witnessBlock each call the shared build
with a coordinate closure, a count54 literal, and value/Result construction.
That is five outside the builder clock, versus the current two. The zero
coordinate itself constructs F zero and Result (two). Retaining the existing
carrierColumn helper in witnessBlock also requires its actual calls/index
operations; an explicit equivalent Nat-array implementation can discharge
those locally. No arbitrary semantic coefficient function receives a unit
read cost in any of these proposed corrections.

## Scope of current progress

The full check_value theorem is about the same complete-carrier stored
witness, selected Ajtai setup, source order, and complete 22-by-54 public
commitment. There is no sparse, honest-witness, opening, or zero-tail premise.
The coordinator can install that concrete value consumer and the corrected
declared counter while keeping the child-counter-to-source/runtime link
explicit in the requirement map. That is partial work progress, not full
extraction-runtime closure. No protocol, profile, model, backend, or numerical
resource limit is changed by this review.

The paused additive Fiat–Shamir analysis is retained separately at
`/tmp/nightstream-nifs-co25-additive-online-route-partial.md`. It supplies no
approved model or proved security transfer.

## Final inactive source and consumer review

The final full consumer criterion stopped after three attempts. This section
reviews the exact retained source only; it does not grant a passing gate,
installed consumer, audit, or approval. It supersedes the earlier proposed
Nat-array wrapper constants with the final Vector.get implementation.

Retained checker:
`docs/reviews/nightstream-fprime-requirements/drafts/NIFS_STORED_COMMITMENT_CHECK_SYMBOLIC_AND_COUNTS.lean.txt`,
342 lines, 18514 bytes, SHA-256
`138ce7017eafedb57ef9208a78e5eb2da31b60b6b46df063f17a2ff5c9fda4b0`.
It is byte-identical to the frozen clean /tmp source reviewed before removal.
Retained consumer:
`docs/reviews/nightstream-fprime-requirements/drafts/NIFS_STORED_COMMITMENT_CONSUMER.lean.txt`,
368 lines, 22275 bytes, SHA-256
`86974a09a4e2bb5ec67239c7f376880ab5ad7ff48080cfbdabd5738b8bb4ac6c`.
I read the clean checker and complete changed consumer interface, then
compared the consumer draft with the restored committed owner.

The getter convention is explicit: Vector.get costs four for its call,
array projection, Fin-value projection, and array read. Public selection
therefore costs6/14. A coefficient comparison costs nineteen: six to
construct the flattened Fin (two index reads, literal54, multiply/add,
Fin constructor), eight for the two gets, three for equalF call/value/Result,
and the equalF counter two. The witness source get costs four, so the final
check's wrapper is eleven. These bodies retain the original Vector.get value
path; no semantic function is executed as an unpriced array reader.

advance is5/4 and allFin is n*(testBound+12)+10 as derived above. The complete
coefficient loop is54*(19+12)+10=1684; compareRow adds six, giving1690.
selectedRow is again the direct alias of StoredCommitment.row. checkRow
adds five: selectedRow call, its forwarded child-row call, compareRow call,
returned value read, Result. Removing the proposed selectedRow Result wrapper
removes its extra value projection and Result construction, saving two.
Thus checkRow is bounded by Rcounter+1695, and the full declared composition is

```text
22*(Rcounter+1707)+35
```

where Rcounter=StoredCommitment.rowWork carrier. At its current declared
value7789876785763, this expression is171377289324375. This number is a
counter expansion, not measured work, a runtime bound, or a resource limit.
The source header and final workBound comment preserve the child-counter
refinement gap. No further wrapper-count defect was found in these bytes.

The selectedRow value path still calls the exact indexed production setup
once per evaluated row. compareRow receives that same Result value/work.
The generic returned_true_iff, returned_work_le, and compareRow_of_value
helpers are proof-only congruences; they do not alter the protocol or narrow
the input domain. The complete check_value statement still covers every
typed stored witness and source, using all22 rows and54 lanes for acceptance.
False accumulators skip child calls but still traverse the finite loop.

The proposed consumer's semantic commit and statement definitions, including
statement_eq_key, are unchanged. Its new private commitmentCheck_value is
the selected leaf theorem at exactly those definitions. scalarProgram
overrides commitmentCheck with the concrete checker; scalarBounds uses its
declared workBound. The only removed parameters are the commitment value
premise of scalar_finish_source_iff and the commitment counter premise of
scalar_check_work_le. Their replacements are the actual leaf theorems.
The remaining matrix value/work premises still range over every matrix,
coefficient, vertex, and carrier column. Outcomes and candidates are not
restricted to honest, sparse, well-formed, or already-accepted probes.
No new public-gate, opening, key, or cryptographic premise is introduced.

No mathematical source defect was found in that intended integration. It
is nonetheless inactive and unvalidated as a complete consumer. The
selected active PiCCSStoredWitnessCheck is restored byte-for-byte to HEAD:
358 lines, 21730 bytes, SHA-256
`7b1b92821e25fc76e7af47293860b39bc1941e22e4dbcbc2986a47ac26e3d9e9`.
The candidate PiCCSStoredCommitmentCheck active file is absent, and the NIFS
audit file has no import or registration for it. Both selected commitment
and matrix contracts therefore remain in the active consumer.

I checked `/tmp/nightstream-nifs-selected-commitment-consumer-3.log`:
the full gate exits1 with the temporary run_cmd parse error at94:56 after
a declaration documentation comment. The log SHA-256 is
`1f8687756d92d549a7d27ae35f32cfdac0fde726486deae6154c1c4283fa0873`.
The separate `/tmp/nightstream-nifs-selected-commitment-kernel-progress-final.log`
contains the progress markers through check_value and check_work_le;
SHA-256 `420cffdec67f9d8fd376053d1975c1382bc13622a2134b14a3bd52f54f0f8b6f`.
I compared the instrumented source with the clean draft: only the marked
diagnostic command blocks differ. These diagnostics do not turn the failed
full gate into a successful module or consumer check. No fourth or narrower
invocation was performed by this reviewer, and the coordinator stopped the
criterion under the three-round policy.

The coordinator's stop record is
`/tmp/nightstream-nifs-selected-commitment-symbolic-stop.md`, SHA-256
`e5f617b6d55f5609ce1186c8c6727b3dfbffa08319c990c2be1e42e04a65ba14`.
All directly consumed child-counter gaps listed above remain open. The source
review supplies neither installation approval nor full extraction/runtime
or protocol-conformance closure.
