# Independent matrix/preimage documentation and map review

Reviewer: Worker 3, `/root/conformance_review`.
Compared the prepared documentation with code cut
`4049d6133972475eaa4cd61e27d447da48349392` in
`/home/nicoarq/develop/Nightstream-nifs-proof-links`.

Result: **pass; no necessary correction found**. The changed sections of
`NIFS_PROOF_LINKS.md`, `NIFS_FIAT_SHAMIR_MODEL_DECISION.md`, and
`NIFS_CONFORMANCE_REVIEW_773f3d0f.md` agree with the scoped source review and
the final 361-record / 25-addition audit. No active edit, build, test, or
generator ran during this documentation review.

The work formulas retain their named-operation scope and the corrected
construction charges. The reports distinguish a stored-row expansion from
its still-required selected row generator. They distinguish exact local
field-preimage rectangles from full decoder fibers and random inverse
sampling/work. No full matrix-entry bound, machine-runtime theorem, or new
Rust conformance result is claimed.

Both full commitment and verifier-comparison attempts remain inactive and
unvalidated after three checks, with no adapter or audit registration. The
round-2 commitment diagnostic records arrival after `check` and before
`check_value`; the text does not promote that diagnostic to a full checked
module. The comparison's two final PiDEC congruence goals remain open.
Actual producer/representation, inverse selection and Fiat--Shamir transfer
remain separate. No model, quantum claim, PaperExact execution, backend
execution, or publication is approved by this update.

The linked [CFRG draft, sections 3.2 and 8.4](https://datatracker.ietf.org/doc/html/draft-irtf-cfrg-fiat-shamir-03#section-8.4)
confirms the 17 August 2026 date, its XOF construction, and its stated
indifferentiability/state-restoration requirements. Those statements do not
discharge this project's concrete additive schedule or pending adapters;
that last conclusion is this review's applicability assessment. No new
security result is adopted from the draft.

Both JSON snapshots have 454 nodes in the same order. Only
`N.security.binding`, `N.security.fiat_shamir`, and `N.conformance.owners`
change. Their changed fields are `code` and `remaining`. All connection,
proof, Rust, requirement, parent, and dependency fields are preserved. The
other 451 complete node objects are unchanged. Every added code reference
names the declaration present at its stated line in the committed source.

The only changed root fields are `nodes` and the new
`nifs_matrix_preimage_update`. Its code commit, four-module scope, validation
counts, stopped links, and remaining work match the records. Its model,
PaperExact, and publication flags remain false. Earlier metadata is unchanged;
the exporter labels its older repository commit as the base and explicitly
separates recorded updates.

The map build log reports 454 records. The test log reports seven passing
tests. No command was rerun. The 15:35 protected-review log differs from the
09:20 record only in separator blank lines and final newline; protected
contents and absence results are unchanged. The conformance report's earlier
bytes remain an exact prefix, so the original immutable-cut review is intact.
Archive packaging is the coordinator's separate check. The unvalidated next
PiDEC source is not a claim of this milestone.

| Reviewed path under `docs/reviews/nightstream-fprime-requirements/` | Bytes | SHA-256 |
|---|---:|---|
| `NIFS_PROOF_LINKS.md` | 67,700 | `a8366a6ab168e07d2a3a6f596004a2315e41dceba0943e3d47dc5eab76d1664f` |
| `NIFS_FIAT_SHAMIR_MODEL_DECISION.md` | 42,998 | `13f83e84157827799fa08f036d0e6a7b3ca67df20cced3461ae943da4452e417` |
| `NIFS_CONFORMANCE_REVIEW_773f3d0f.md` | 75,355 | `0c1c89fb3576441a3a292575e94e76c6bf0dfa1def8801ce3157729df807fa5a` |
| `site/requirements.json` | 465,277 | `1bf4b2b82d9e3dbd8dc2ee0d4e7ab256416723f3f8e5d53b28a4134954f734c4` |

The source, audit, committed-file identities and their limits are retained
separately in `/tmp/nightstream-nifs-matrix-preimage-milestone-review.md`.
