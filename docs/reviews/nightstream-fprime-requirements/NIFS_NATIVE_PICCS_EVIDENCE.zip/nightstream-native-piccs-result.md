# Selected native PiCCS result

The normal CPU selected prover passes from the actual executed base witness and sixteen actual virtual-zero initial witnesses. The test computes the actual fresh commitment with the selected fixed key. It supplies no prepared matrix evaluations, openings, oracle, or verifier artifact. The existing canonical driver binds and samples once. The selected package owns its header, fixed parameters, transcript, and checked row cache.

The new CPU owner keeps the original packed witness storage, uses exact zero-suffix prefixes and factored equality weights, and computes terminal Pad and matrix openings internally. Pad retains the complete final ring block. A small case checks a nonzero running tail, fresh-tail rejection, odd and singleton folds, and the zero matrix. The existing generic cache still checks matrix binding.

| Check | Result | Whole invocation | Peak RSS |
|---|---|---:|---:|
| Small row semantics | 1 passed, attempt 1 | 12.45 s | 432,516 KiB |
| Existing normal CPU regression | 4 passed, attempt 1 | 7.53 s | 380,768 KiB |
| Selected binary preparation | passed, attempt 1 | 52.90 s | 1,402,460 KiB |
| Full actual-base PiCCS | 1 passed, attempt 1 | 231.52 s | 28,165,268 KiB |

Every cargo-test invocation used the project-required outer `timeout --signal=KILL 300s`. The full test includes actual witness execution, actual fixed-key commitment, both matrix-cache passes, every sumcheck round, all terminal openings, normal optimized verification, and all retained-value assertions. Source plus commitment completed at 38.764 seconds; the selected prover completed at 230.536 seconds. The test itself took 231.18 seconds.

All 28 round messages, transcript states/challenges/claims, commitments, public values, 17 Pad families, and all 17 × 14 × 54 matrix coefficients matched the retained result. Matrix slot 13 is zero. The retained data is used only in assertions. The expected fixture identifies its archived Lean-checked source record; this native test does not assert that Lean separately recomputed every matrix operation.

The pre-run memory estimate was 28.457 GiB with 41.556 GiB available. The actual peak was 26.860 GiB. The estimate includes cache capacities, the measured package/row visitor peak, original masks, 17 block views, row tables, fold overlap, and terminal scratch. This resource result covers the actual base case, not seventeen nonzero full-width witnesses.

The implementation and all fixture bytes are frozen. Exact file hashes and logs are in `/tmp/nightstream-native-piccs-result.json`; memory accounting is in `/tmp/nightstream-native-piccs-memory-estimate.json`. Formatting passed before validation (`/tmp/nightstream-native-piccs-fmt-1.log` and `-2.log`). No source repair was needed for these checks. The queue was released to the D-loader check after the full pass.

The complete native C→R→D call remains open. This pass does not establish that a generic seventeen-source execution fits memory, nor does it change the profile, parameters, pins, transcript, backend, features, environment, or approved security model.
