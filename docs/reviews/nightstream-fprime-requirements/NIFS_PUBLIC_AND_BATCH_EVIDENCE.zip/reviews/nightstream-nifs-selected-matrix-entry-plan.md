# Selected matrix-entry work plan

Prepared by Worker 3 (`/root/conformance_review`), 2026-09-10, from read-only
source inspection. No code, build, full matrix evaluation or generation was
performed. This is a proposed proof/implementation boundary, not closure.

The existing compact row accessor supplies value authority. Its generation
and lookup work is not yet proved. The smallest suitable leaf owner is
`Export.Stage1.PiCCSStoredMatrixEntry`, using independent selected owners
and the existing `Result` type. It must not import `PiCCSStoredWitnessCheck`.

## Independent interface and final consumer bridge

The leaf can reuse the exact selected carrier expression already used by
the checker:

```lean
abbrev carrier : Phi81Relation.Shape :=
  PaperAlgebra.FullShape PiDECInputCheck.logicalWidth PiDECInputCheck.publicFits

def entry
    (matrix : Fin productionShape.matrixCount)
    (coefficient : Fin productionShape.coefficientCount)
    (vertex : BooleanVertex productionShape.cubeVariables)
    (column : Fin carrier.carrierWidth) : Result F

theorem entry_value
    (matrix : Fin productionShape.matrixCount)
    (coefficient : Fin productionShape.coefficientCount)
    (vertex : BooleanVertex productionShape.cubeVariables)
    (column : Fin carrier.carrierWidth) :
    (entry matrix coefficient vertex column).value =
      (Lifecycle.PiRLC.v1_1.InputBinding.relationSource PiDECInputCheck.relation).matrixSource.coefficientMatrix
        baseOps matrix coefficient vertex column

def workBound : Nat

theorem entry_work_le
    (matrix : Fin productionShape.matrixCount)
    (coefficient : Fin productionShape.coefficientCount)
    (vertex : BooleanVertex productionShape.cubeVariables)
    (column : Fin carrier.carrierWidth) :
    (entry matrix coefficient vertex column).work ≤ workBound
```

These are signatures only. The entry implementation does not depend on the
public proof input: its matrix source is fixed by `PiDECInputCheck.relation`.
The final `matrixEntry_value (input : PiCCSInputCheck.Input) ...` theorem
belongs in `PiCCSStoredWitnessCheck`. It connects this leaf equality to
`(statement input).matrixSource.coefficientMatrix`; that field is
definitionally the same independent relation source. The consumer can then
install `entry` in `scalarProgram` and `workBound` in `scalarBounds`.
This direction avoids the import cycle in the first proposed interface.

The necessary private generation leaf is:

```lean
def selectedPort (matrix : Fin 14) (row : Fin selectedPlan.rowCount) :
    Result (ProductionRelation.SparseForm PiDECInputCheck.logicalWidth)

theorem selectedPort_value (matrix : Fin 14)
    (row : Fin selectedPlan.rowCount) :
    (selectedPort matrix row).value = selectedPlan.portForm row matrix
```

Here `selectedPlan` is a local abbreviation for the existing
`PerApplicationFixedPoint.structuralPlan Poseidon2HashChainV1Package.application
Poseidon2HashChainV1Package.fits`. Its actual work and returned entry-list
length need structural bounds. A sparse form can contain repeated columns;
logical width alone does not bound the length of its list.

## Existing semantic chain

The selected input owner is
[PiDECInputCheck.relation](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PiDECInputCheck.lean:42).
Its `relation_eq_selected` theorem reaches the existing fixed-point relation.
[relationSource](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/PiRLC/v1_1/InputBinding.lean:58)
selects the same `PaperAlgebra.matrixSource relation.system`.

The reusable value links are:

- [PerApplicationFixedPoint.relation_matrices](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PerApplicationFixedPoint.lean:102).
- [PerApplicationCanonicalPackage.matrixProgram_row?](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PerApplicationCanonicalPackage.lean:243).
- [allPort_coefficient_eq_logicalRelation_matrix](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/Poseidon2HashChainV1MatrixRows.lean:81).
- [Phi81CarrierLayout.extendMatrix](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Folding/PiCCS/PaperJoint/Phi81CarrierLayout.lean:143), which fills only the original matrix's completion suffix with zero.
- [MatrixSource.coefficientMatrixOf](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Folding/PiCCS/PaperJoint/MatrixCoefficientSource.lean:221), the exact 54-lane coefficient expansion.
- [StoredWitnessCheckEntries.kernelWeight_value/work_le](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Folding/PiCCS/PaperJoint/StoredWitnessCheckEntries.lean:167).

The counted Boolean vertex index is already implemented in
`StoredWitnessCheckEntries`; its current helper and value/work lemmas are
private. Minimal exposure would avoid duplicating the `7 * arity + 2`
traversal. It gives 198 named operations for the selected 28-coordinate row.

## Why the current accessor is not a closed work leaf

[MatrixProgram.Program.row?](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/MatrixProgram/Program.lean:113)
selects a compact block by scanning its ordered block list. Most block
constructors compute a local row. Ordinary blocks instead call
[Ordinary.Block.row?](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/MatrixProgram/Ordinary.lean:86),
which selects a source index, invokes `sourceRow`, applies the source
projection and compiles substitutions.

The selected `sourceRow` is
[PackageSourceRows.packageSourceRow?](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PackageSourceRows.lean:17).
It maps both complete package instruction/assertion lists, appends them,
then filters the full decoded list for a unique row owner. No counted or
direct-index replacement was found. Package construction and that full
scan must not disappear behind a constant callback charge. The existing
custody theorem remains useful as the semantic reference for a counted
row-at implementation derived from those same source owners.

Other necessary charges include compact program/geometry construction,
block and index-schedule selection, source-row construction, source
projection, substitution range/grid scans, sparse-form scale/append and
allocation, and the selected port call. `SourceSubstitution.form?` performs
both full range and grid searches to detect missing or overlapping mappings.
These checks cannot be silently omitted from a claimed refinement of that
interpreter.

## Entry execution and selected dimensions

Decode the Boolean row once. A row outside the active prefix is zero.
For a live row, construct the selected sparse form once before the 54-lane
loop. Decode the queried carrier column as block/assignment lane. At each
source lane, reconstruct `54 * block + lane`, read its raw matrix coefficient
by a duplicate-aware sparse-list scan when it is inside logical width, and
multiply by the existing counted Phi81 kernel weight. Sum in the semantic
order and retain the returned work from every call.

Do not return zero merely because the queried assignment column is beyond
logical width. Coefficient expansion mixes the source lanes of that block.
The logical-width zero guard belongs to each reconstructed source column.
Only the existing constant-coefficient tail theorem directly establishes
zero at a queried completion-tail column.

| Selected quantity | Proved value |
|---|---:|
| Matrix slots / coefficient lanes | 14 / 54 |
| Boolean row domain | `2^28` |
| Active logical rows | 6,377,559 |
| Logical width | 254,260,583 |
| Completed carrier width | 254,260,620 |
| Ring blocks | 4,708,530 |
| Completion suffix length | 37 |

Sources: [selected width and row count](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/Poseidon2HashChainV1Package.lean:140)
and [selected carrier/block facts](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/Poseidon2HashChainV1Setup.lean:27).
Every numeric bound above comes from the selected profile or these identities.
No sparse-form length or generation-cost constant has been invented.

Preserve the complete `Fin 14` API. Slot 13 can use the existing proved
`slot13_matrix_zero` fact while remaining a matrix slot. Pad stays with its
separate existing owner. The entry work bound must combine one proved row
generation bound with 54 coefficient scans, kernel calls and scalar/control
work. Closing that bound requires actual generation and list-size proofs;
the existing matrix equality theorem alone does not provide them.
