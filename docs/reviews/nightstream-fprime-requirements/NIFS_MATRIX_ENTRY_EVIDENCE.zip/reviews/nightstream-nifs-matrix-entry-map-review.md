# Matrix-entry milestone documentation and map review

Independent reviewer: Worker 3 (`/root/conformance_review`), 2026-09-10.
Code cut: `361a4d7fc4e7869b19374872177e3723b4314719`.
Scope: only the new milestone text, the two related Active criteria edits,
and the map delta from `/tmp/nightstream-nifs-matrix-entry-map-before.json`.
No build, test, publication, protocol execution, or active-file edit was run.
Previously closed source and audit proofs were not reviewed again.

Result: no necessary false or stale claim found in this delta. The source
counter, runtime, stopped-criterion, and CO25 limits are preserved.

## Exact map delta

The baseline SHA-256 is
`e15fc1641b0a477f336875c3347b32d7f2e4e59713615e31ee3545a60608d79b`.
The reviewed current `site/requirements.json` SHA-256 is
`9fe5c8d9797b7ef52a39a8a773eeb0f3fa551c7235cc8a53eea67c7de5236f20`.

Both parsed maps have the same 454 node IDs in the same order. Exactly these
three nodes change; every other node is equal as parsed data:

| Node | Changed fields | Unchanged proof / connection / Rust state |
| --- | --- | --- |
| `N.security.binding` | `code`, `remaining` | `assumption` / `partial` / `not_required` |
| `N.security.fiat_shamir` | `remaining` | `assumption` / `open` / `implemented` |
| `N.conformance.owners` | `code`, `remaining` | `not_required` / `partial` / `not_required` |

I compared the actual `proof`, `connection`, and `rust` fields for all 454
nodes; all are unchanged. The 451 other nodes are wholly unchanged. Outside
the node array, the only change is the new `nifs_matrix_entry_update`
metadata entry. All previous metadata entries remain equal.

The two changed code lists each add the same three references and remove
none. All six added references point to the correct current declarations in
`Export/Stage1/PiDECCommitmentMatrixEntry.lean`:

- line 126: `globalRow_val`
- line 248: `entry_value`
- line 263: `entry_work_le`

These are the three exports in the final 405-record audit. The metadata uses
the exact code commit and records the 18-second full entry check, 405 complete
audit records, three new exports, 3,765 jobs, five-second audit wrapper, and
permitted axioms. Its model, PaperExact-execution, and publication flags are
all false. The scope does not promote this block entry to a complete matrix
dispatcher or an installed full checker primitive.

The source JSON is byte-identical to `site/dist/requirements.json`.
The retained local build log reports 454 generated nodes; the retained map
test log reports seven tests in 0.074 seconds and `OK`:

- [build 2](/tmp/nightstream-nifs-matrix-entry-map-build-2.log), SHA-256
  `26dddda940417552de885f55f35163a76b372cba81b5984ee36f52ec92f4901d`
- [test 1](/tmp/nightstream-nifs-matrix-entry-map-tests-1.log), SHA-256
  `3e5917dfc1786bd7a112da89dae00c8042e7da2032f142c53166e98151766c7c`

## New documentation claims

I read the full added sections and their exact Git diff against the code cut.
The reviewed document hashes are:

| Document | SHA-256 |
| --- | --- |
| `NIFS_PROOF_LINKS.md` | `7c16bfaa300f923252258d6ed44854748e98b8ad87f0055194eff912b44c04ed` |
| `NIFS_FIAT_SHAMIR_MODEL_DECISION.md` | `5fe014f32131372d1b3dad6d6c3a33b7d356ab06b7c0bd8ba6b77877bbde9451` |
| `NIFS_CONFORMANCE_REVIEW_773f3d0f.md` | `acf89eb8270f409bbf02c5fc53534dffb2c593e9c8faa4c47b171f7460e35849` |

All paths are under `docs/reviews/nightstream-fprime-requirements/`.
The conformance document preserves its complete previous bytes as an exact
prefix. The model note adds only its new section. The proof-links note adds
the milestone section and updates two current Active criteria lines.

The new text correctly states the block scope: 1,188 rows at
`[6021547,6022735)`, all 14 ports, all 54 coefficient lanes, and all carrier
columns. The completion-column statement is read with the exact source-lane
guard: the theorem includes the 37 tail columns; the implementation does not
zero a query merely because its column lies in that tail. It supplies no
full-dispatch, other-row-family, or full primitive installation claim.

The 892,400 bound is consistently a composed declared-counter bound.
The listed builder, dense-row, ring-sum, and Ajtai composition gaps are
concrete source/runtime refinement obligations. Existing value and declared
counter results remain valid. The new text neither adds a cryptographic
premise for those implementation gaps nor claims that runtime is closed.

The stopped commitment consumer and three-fact inverse interface remain
inactive. The ten-second earlier file check is distinguished from the failed
later full consumer criterion. Completed kernel markers and the compiled
rank-case proof are not presented as passing full gates or approved subsets.
The active selected checker still has commitment and full matrix-entry
premises. The global inverse and uniform-rank/random-law work remain open.

The CO25 section presents the elementary online relabeling and joint decoder
coupling as mathematical analysis. It retains the required raw-state cache,
visible/pending edge, cursor, initialization, and security-game proofs. It
does not claim a checked security transfer, failed-trace equality, concrete
Poseidon2 security, or model approval. The stated cursor/count issue is kept
as a required exact match, not a refutation of the paper's security theorem.

The 18:20 protected-review record has the same four path sections and same
review contents as the retained 17:20 record, ignoring only the record time
and outer blank lines. Its SHA-256 is
`d7c565a01e5797cf678a3ecf2d7b3e6ecca42845aa338ccecff4fb49f0954a12`.
No old review suite was run for this comparison.

The earlier final milestone review now records the coordinator's observed
terminal exit 0 for static session 19543 at 18:43, before the code commit.
The retained static text itself says all boundary checks passed. This note
does not perform or approve evidence-archive assembly, deployment, backend
execution, or a broader Stage 1 conformance review. Archive assembly follows
this frozen review note under the coordinator's existing task.
