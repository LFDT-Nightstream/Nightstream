# Conditional preimages of the totalized scalar decoder

Analysis only, 2026-09-10. This is a plan for the identified codec obligation.
It does not select a Fiat–Shamir model or claim a checked inverse codec.
No source, dependency, or build change is part of this note.

Fix the supplied fallback scalar `f`. Let `ψ_f : F^32 -> Scalar` be the
existing scalarwise totalized field decoder. Its scalar target has 54
ordered residues in `Fin 5`; residue zero represents centered coefficient
`-2`. Input messages must be available as 54 stored trits, or their access
cost must remain explicit. A semantic function lookup is not a free read.

## One field lane, without word enumeration

Write `h=2^16`, `M=h^2`, `m=M-1`, `q=m*M+1`, `v=h-1`, and
`a=v/5=13107`. The ordered candidates are low `l`, then high `r`, and their
word is `w=l+h*r`. Use these sets:

| Set | Meaning | Size | Contains zero |
|---|---|---:|---|
| `R={h-1}` | Rejection | 1 | No |
| `T_d={5i+d : 0<=i<a}` | Accepted residue `d` | `a` | Exactly when `d=0` |
| `V={0,...,h-2}` | Any accepted candidate | `v` | Yes |
| `H={0,...,h-1}` | Any candidate | `h` | Yes |

For any such rectangle `A x B`, its field-preimage count is

```text
W(A,B) = m*|A|*|B| + [0 in A and 0 in B].
```

This follows from the checked `FieldPairLaw` preimage counts. Every word
has the common fields `w+t*M`, `0<=t<m`; word zero also has field `q-1`.
The common fields range through `0,...,q-2`, so the extra field is disjoint.

There is a compact local rank map. Put `C=m*|A|*|B|`. For a rank below `C`,
divide by `|A|*|B|` to obtain `t` and a pair rank. Divide the pair rank by
`|A|`, with the remainder as the low-set index and quotient as the high-set
index. Return `l+h*r+t*M`. If rank `C` exists, return `q-1`. Set indexing
uses constants, identity, or `i -> 5i+d`; none of these enumerates `M` words
or the 13107 candidates of a residue class. The reverse map uses the same
quotient/remainder coordinates and a separate test for `q-1`.

## Two separate counting tables

For requested scalar `s`, let `S_n(j)` count suffixes of `n` field pairs
that finish with output `s`, starting from a prefix whose first `j`
accepted digits already match `s`. The count is capped at `j=54`.
A prefix that already mismatched `s` has no successful continuation and is
not represented by these states. Thus accepted count alone is not the
prefix invariant: the matched-prefix condition is essential.

Use `n=0,...,32` and `j=0,...,54`:

```text
S_0(j)  = [j=54]
S_n(54) = q*S_(n-1)(54) = q^n                 (n>0)

S_n(j) = m*S_(n-1)(j) + 2*m*a*S_(n-1)(j+1)
       + (m*a^2 + [s_j=0 and s_(j+1)=0])*S_(n-1)(j+2)
                                                        (j<=52, n>0)

S_n(53) = m*S_(n-1)(53)
        + (m*a*(h+1) + [s_53=0])*S_(n-1)(54).          (n>0)
```

For `j<=52`, the disjoint rectangles are `(R,R)`, `(R,T_sj)`,
`(T_sj,R)`, and `(T_sj,T_s(j+1))`. They advance the count by 0, 1, 1, and
2. At `j=53`, use `(R,R)`, `(R,T_s53)`, and `(T_s53,H)`. In the last case,
the low candidate completes the scalar, so the high candidate is unrestricted.
At `j=54`, every remaining pair is unrestricted. This retains both the
low/high order and the complete unused tail of the 64-candidate window.

Define a different table `A_n(j)` for abort. It depends only on the capped
number of accepted digits, and puts **no restriction on their residues**:

```text
A_0(j) = [j<54]
A_n(54) = 0
A_n(j) = m*A_(n-1)(j)
       + 2*m*v*A_(n-1)(min(54,j+1))
       + (m*v^2+1)*A_(n-1)(min(54,j+2)).             (j<54, n>0)
```

Its rectangles are `(R,R)`, `(R,V)`, `(V,R)`, and `(V,V)`. Their weights
sum to `q`. Reaching 54 cannot lead to abort. An aborting prefix whose
accepted digits differ from `f` must remain in this table; counting only
prefixes that match `f` would exclude valid members of the fallback fiber.

The intended totalized fiber count is the disjoint sum

```text
N_f(s) = S^s_32(0) + [s=f]*A_32(0).
```

Surjectivity has a direct witness. For the first 27 lanes, choose the field
word `s_(2i)+h*s_(2i+1)` with common-block index `t=0`. Set the last five
lanes to zero. All 64 candidates are accepted, and the first 54 give `s`.
Thus `S^s_32(0)>0` for every scalar, regardless of fallback. Separately,
32 common representatives of `(R,R)` witness a nonempty abort fiber.

## One uniform rank, then deterministic unranking

Request one exact uniform rank in `[0,N_f(s))`. For `s=f`, partition it
first into the success interval of size `S^f_32(0)` and the abort interval
of size `A_32(0)`. For other targets, use only the success interval.

At a table state, retain the ordered rectangle branches separately, even
where their equal weights were merged in the recurrence. Branch `b` has
interval length `W_b*C_b`, where `C_b` is the next suffix count. Select
the interval containing the current rank and subtract its prefix. Divide
the residual by `C_b`: the quotient is the local field rank and the
remainder is the suffix rank. Only positive intervals can be selected,
so division by zero is excluded. Decode the local field using the rectangle
map above, append that field at the current lane index, and continue.

This construction suggests a bijection
`Fin(N_f(s)) ≃ {fields : F^32 // ψ_f(fields)=s}`. Its inverse classifies the
first field into the unique branch and uses `prefix+localRank*C_b+tailRank`.
No floating-point weights or conditioning by trial decoding are needed.

Conditional weighted transitions are another implementation: choose each
branch with mass `W_b*C_b/currentCount`, then a uniform local field and a
uniform suffix. They need more uniform-integer calls. Global rank/unrank
keeps the random interface to one call per scalar and gives a direct
finite-bijection proof target.

## Costs and the random interface

Each table has `(32+1)*(54+1)=1815` entries. With coefficients prepared
once, the displayed success recurrence uses, per nonbase row, 162
count-by-word multiplications and 107 additions. The displayed abort
recurrence uses at most 162 such multiplications and 108 additions per row.
This includes the saturated success column's multiplication by `q` and
sets the abort saturated column to zero. There are 32 nonbase rows.
These are recurrence arithmetic counts, not a complete execution clock.

All table counts are at most `q^32<2^2048`. Transition weights are at most
`q<2^64`. Unranking takes 32 lane steps, at most four rectangle tests per
step, and at most one division of a full fiber rank by a suffix count per
step. The local rectangle arithmetic uses at most 64-bit ranks. A complete
cost theorem must also charge stored-trit reads and equality with fallback,
coefficient preparation, count-array reads/writes, allocation, control,
integer arithmetic workspace, and output construction. Charge the abort
table when needed; reuse requires an explicit counted cache interface.

Keep integer-operation costs explicit, for example `Mul(L,64)`, `Add(L)`,
and `Div(L,L)` with `L<=2048`. Do not infer bit-time or machine runtime from
an arithmetic-operation count. An implementation may provide one primitive
`UniformBelow(N)` with its exact law and an explicit cost contract `U(N)`.
That contract is not supplied by this plan.

Alternatively, independent fair bits can implement exact `UniformBelow`:
for `N=1` return zero; otherwise draw `ell=ceil(log2 N)` bits and repeat if
the encoded integer is at least `N`. Acceptance probability is `N/2^ell`.
Expected iterations are `2^ell/N<2`, and expected bits are
`ell*2^ell/N<2*ell`, with `ell<=2048`. Almost-sure termination, independence,
and this expected-work statement still need proofs. There is no finite
worst-case iteration or bit bound for this rejection implementation. No
truncation, new abort, numerical retry cap, or approximate law is selected.
If the chosen paper time interface requires a worst-case bound, that
interface needs a separate resolution rather than an expected-time claim
being substituted for it.

## Required proof and integration work

1. Prove the rectangle rank bijection, field bounds, disjoint common/extra
   cases, and exact local cardinality.
2. Prove the ordered success and unrestricted abort transition partitions,
   including `j=53`, saturation, mismatched-prefix exclusion for success,
   and the complete unused tail. Connect them to the existing bounded decoder.
3. Prove both table cardinality recurrences, the disjoint totalized fiber
   formula, the explicit surjectivity witness, and positive normalizers.
4. Prove rank/unrank inverses and the uniform-fiber law:
   `Pr[K_f(s)=x] = [ψ_f(x)=s]/N_f(s)` for the exact uniform rank primitive.
5. Prove the stored implementation's value and work refinements, including
   the chosen integer and random-sampling cost contracts.
6. For the scalarwise 17-coordinate decoder, prove its fiber is the product
   of scalar fibers. Independent scalar inverse calls then give the uniform
   batch fiber; their work adds over the selected 17 coordinates.
7. Prove the joint resampling identity required by the eventual transfer:
   `K_f(ψ_f(U(F^32)))` is uniform on `F^32`, including its pairing with the
   decoded scalar. In contrast, `K_f(U(Scalar))` is generally not uniform
   on `F^32` when fibers differ. Its distance equals the forward decoder's
   distance from uniform Scalar; a zero-distance claim is not available.

[Chiesa–Orrù](https://eprint.iacr.org/2025/536), Lemma 3.2 and D2SAlgo
steps 3a–3f, need exact conditional preimages and cache consistency. Cache
the sampled raw answer by the complete oracle query, not merely by its
decoded scalar. Equal outputs for different new queries do not authorize
reusing one raw preimage. The paper's `t_(psi^-1)` interface, exact schedule,
additive absorption, successor-state/cache law, state-restoration extraction,
and fixed-Poseidon2 transfer remain separate obligations. This plan closes
none of those model or integration requirements.
