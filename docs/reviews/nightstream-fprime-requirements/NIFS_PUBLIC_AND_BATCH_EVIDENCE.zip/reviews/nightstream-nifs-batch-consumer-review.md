# Independent ordered sampler-batch review

Reviewer: Worker 3 (`/root/conformance_review`), independent of the authors
of the two reviewed batch modules. Date: 2026-09-10.

No defect was found in the stated finite-law or deterministic sampler
claims. The product comparison has explicit positive normalizations.
The selected target is a uniform successful ordered scalar list. Failure
mass is retained on the decoder side. The actual sampler equality retains
the exact source order and successful final state, without asserting that
its deterministic field windows are independent random fields.

This is a source review of the frozen contents below in
`/home/nicoarq/develop/Nightstream-nifs-proof-links`. It does not extend
the original immutable `773f3d0f` conformance review. No active source was
edited, and this reviewer ran no build, test, prover, backend or PaperExact
command. The hashes identify reviewed source; they are not authority.

## Source identities

Paths are relative to `formal/nightstream-fprime/NightstreamFPrime/`.

| Source | Lines | SHA-256 |
|---|---:|---|
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/BatchOutputLaw.lean` | 184 | `442491d8f82495ea3841b730f9e047b89350cab606a059a322fffd98e317466a` |
| `Lifecycle/PiRLC/v1_1/SamplerBatchOutputLaw.lean` | 213 | `a27623d6a5dadb8e0eaf29fc251eff176f4d5d2b71d4ecd1233781170e46340a` |
| `Lifecycle/PiRLC/v1_1/SamplerOutputLaw.lean` — previously reviewed scalar law | 67 | `ffca33b3cb9bf4c50318992249d944f2f8325163f893769e6abcc86a0e58b1b2` |
| `Lifecycle/PiRLC/v1_1/SamplerFieldShortfall.lean` — actual field-window link | — | `037ced259569c69670ba5a2f530c96f588ea9c70757ebf258f4ba042d700d1b2` |
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldBatchShortfall.lean` — selected cardinality | — | `861adca1519c469fd45cb49288729d46c94f34dedfd7afaf3116d43c0021f84d` |
| `Lifecycle/Transcript.lean` — actual sampler | — | `c202204c451ca96c03e6c27e0320970a6fe4d867e99d486284dcd887f99c6d32` |
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/ProductionSchedule.lean` — fixed block schedule | — | `ca29cca26017f5b3564f6f2b15ad6bd5d22aa8b45a022c620deb6e76cfb5e458` |

Both primary files were read in full. The scalar decoder, actual sampler,
source schedule, field-window definition and cardinality dependencies were
checked at the referenced definitions. The primary hashes were read again
after review and were unchanged.

## Generic finite comparison

`BatchOutputLaw.independent_batch_event_error_le` at line 137 quantifies
over finite left and right input types, arbitrary deterministic output
maps, every scalar output event, every natural batch count and every event
on the resulting ordered output function. The output type need not itself
be finite: the two counted input spaces are finite.

Both scalar input normalizations are explicit positive premises. The
scalar premise bounds the absolute difference for every output event.
The batch conclusion compares equal mass on every function in
`Fin count -> Left` with equal mass on every function in
`Fin count -> Right`. Thus independence is part of the specified product
experiment. It is not inferred from marginal laws on an arbitrary source.

The proof preserves normalization:

- `product_frequency` at line 37 uses an explicit equivalence between an
  event subtype on a product and the sum of its slices. It retains the
  full product cardinality.
- `replace_left` at line 53 averages the scalar event bound over a common
  finite coordinate and uses its positive denominator when cancelling.
- `product_error` at line 81 uses one intermediate product distribution.
  Its two comparisons share the unchanged coordinate at each step.
- `cons_frequency` at line 116 uses `Fin.consEquiv`. It preserves the
  first coordinate and the ordered tail.
- The count-zero case proves equality on the unique empty function. The
  successor case derives a positive left-tail cardinality and proves the
  bound `count * error` by induction. There is no division by a potentially
  zero source size and no new numerical cap.

This generic theorem is a finite event-frequency result. It does not
introduce a random oracle, sampler, rejection policy or runtime model.

## Selected successful target and abort scope

`SamplerBatchOutputLaw.fieldDecodeBatch` at line 18 calls the existing
scalar `fieldDecode` in increasing coordinate order using `List.ofFn`
and `Option` traversal. It returns `none` if any coordinate fails.

`field_batch_output_event_error_le` at line 37 specializes the generic
comparison to `FieldBatch = Fin 17 -> (Fin 32 -> F)` and
`Scalar = Fin 54 -> Fin 5`. The exact denominators are
`(q^32)^17` and `(5^54)^17`, with `q` the Goldilocks modulus. Positivity
is proved from these actual cardinalities. The selected count 17 comes
from `PaperProfile.arity.total`; it is not an added limit.

The target gives equal mass to all ordered scalar functions and maps each
to `some (List.ofFn scalars)`. Distinct functions give distinct ordered
length-17 lists. Consequently this is the uniform target on successful
ordered scalar lists, with zero target mass on `none`. It is not a uniform
distribution over arbitrary RingF values or arbitrary lists.

The decoder side counts every field batch. It is not conditioned on
successful scalar or batch decoding. For any event, including `none`, the
proved bound is

`17 * (32 * FieldPairLaw.pairDeviation + choose(64,11) / 65536^11)`.

This follows from the existing all-Option scalar event bound at
`SamplerOutputLaw.field_output_event_error_le:54`. The collection maps
are checked pointwise by `collect_ofFn_map` and `collect_ofFn_some`.
No failed coordinate is replaced by a default scalar, omitted, retried,
sorted or moved. A target made only of successful coordinates remains
successful after collection.

## Exact actual-source list and state

`sampleBatch_ring_list_eq_fieldDecodeBatch` at line 159 is a separate
deterministic equality for every initial transcript state and every count.
Its left side is the actual `Transcript.PiRlcSampler.sampleBatch` output.
Its right side decodes `SamplerFieldShortfall.fieldWindow initial index`
at that same index, then applies the existing `Phi81StrongSet.embedScalar`
to each scalar in order.

The proof matches the actual `Fin.lastCases` batch recurrence with list
append at the final index. This preserves indices `0` through `count-1`;
the selected instance therefore preserves the existing fresh-then-running
challenge order. `sampleRingChallenge` is exactly `sampleScalar` followed
by `embedScalar`, and the previously reviewed scalar theorem identifies
that sample with the same field-window decoder. The proof does not use an
independent-field premise.

`sampleBatch_output_state_eq_fieldDecodeBatch` at line 189 also retains
the complete successful final transcript state. It invokes the existing
`piRlcChallengesWithState_finalState` theorem on the actual successful
batch and proves an equality of `Option (List RingF * Transcript.State)`.
Failure remains `none` on both sides. It does not assert that an aborted
call returns a final or partially consumed state.

The state on the right is exactly `stateAt specification initial count`.
The source definition enters each scalar with the existing `[4, index]`
separator and advances through its fixed eight digest blocks. Each digest
reads the four current rate lanes before the next Poseidon2 permutation.
Thus the equality preserves the existing schedule; it does not replace
the state with a digest, a fresh seed or an independently chosen state.

The list/state equality is a value theorem. It does not prove that list
traversals, repeated source computations or transcript operations have a
particular cost, nor that two implementations have the same work trace.

## Security and validation scope

There is no supported implication from the finite independent-field
experiment to the actual Poseidon2-derived joint field-window law in these
files. A security transfer still needs that source/game comparison,
including any conditioning or failure events it requires. The deterministic
list/state equality does not supply it. No Fiat--Shamir, adaptive-query,
retry, extractor-work or state-restoration probability claim was found.

The retained focused build logs were read. Both contain successful
completion and terminal exit zero, with no source error. Replayed linter
warnings occur in the consumer log. No command was rerun by this reviewer.

| Record under `/tmp/` | Reported result | SHA-256 |
|---|---|---|
| `nightstream-nifs-batch-output-law-2.log` | module 9.1s, command 9s; bounded 1500s, exit 0 | `dbfa41ec1a2fcd4d39d73e297983c469888e1e14a6d23b303e5b250fe558a008` |
| `nightstream-nifs-sampler-batch-output-3.log` | module 1.4s, command 2s; bounded 1500s, exit 0 | `14f3b2843809e6574b8a593f298504efe9172d96e5b9ea9712b9aa6201762cd3` |

The new exported claims are the generic
`independent_batch_event_error_le` and the three selected theorems
`field_batch_output_event_error_le`,
`sampleBatch_ring_list_eq_fieldDecodeBatch`, and
`sampleBatch_output_state_eq_fieldDecodeBatch`.
No final combined allowed-axiom/static audit for this milestone was
supplied to this review. The focused results do not approve broad Stage 1
closure or establish the missing source/game comparison.
