# Dense commitment work preparation

Independent source preparation by Worker 3 (`/root/conformance_review`),
2026-09-10. This is a plan for the remaining `commitmentCheck` primitive.
No implementation, build, test, prover or backend was run. No cost theorem
is claimed. The plan concerns the extractor's arbitrary-witness checker,
not public verifier cost. None of the large counts below is a test request.

## Exact owner chain

The selected
[PiCCSStoredWitnessCheck.commit](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PiCCSStoredWitnessCheck.lean:38)
is `PaperAlgebra.openingMaps productionAjtaiKey |>.commit`.
[PaperAlgebra.openingMaps](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/PaperAlgebra.lean:149)
uses `PiRLCAlgebra.Commitment.commit`.
[ajtaiRow](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Phi81Relation/PiRLCAlgebra/Commitment.lean:71)
is the canonical ring sum over every complete witness block:

```
C[row] = sum_block ringFMul(key[row,block], assignmentBlock(witness,block)).
```

[productionAjtaiKey](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/Poseidon2HashChainV1Setup.lean:117)
is the indexed `productionSetup.verifierKey` through
`PerApplicationCanonicalPackage.commitmentKey`. For each `(row,block,lane)`,
[AjtaiSetupV1.Setup.verifierKey](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/AjtaiSetupV1.lean:64)
computes

```
ChaCha20.first256Nat(seed, row, block, lane) mod q.
```

The seed is the existing verifier-owned canonical 32-byte production seed.
There is one ChaCha20 block per coefficient. The nonce is
`row_u32_le || block_u64_le`, and the counter is the coefficient lane.
There is no coefficient rejection or retry. This is the already selected
setup; the plan adds no generator or cryptographic premise.

## Smallest counted path

Keep the existing interface

```
commitmentCheck : StoredWitness shape carrier -> Fin shape.sourceCount -> Result Bool.
```

Use the existing `PaperForkExtractionWork.Result` and local private loops.
The selected adapter belongs beside the other selected primitives, under
`Export/Stage1`; the bounded coefficient routine belongs with the existing
`AjtaiSetupV1` owner if a separate file is needed. No new public interface,
cross-call cache or generic commitment framework is needed.

1. Read the selected witness array once. Select the corresponding existing
   fresh or running public commitment array, charging the branch and reads.
2. Traverse commitment rows with direct finite indices. For each row,
   initialize a stored 54-coefficient accumulator.
3. Traverse every complete witness block with direct finite indices. Build
   one 54-lane key block by calling the counted coefficient generator once
   per lane. Copy the corresponding 54 stored witness coefficients, or
   use direct bounded array reads with every repeated read charged. Compute
   the ring product and add it to the stored row accumulator. Release the
   current block before advancing.
4. Compare every coefficient of the completed row with the selected public
   commitment. A mismatch may return false immediately. The bound covers
   the full dense path, including all rows on an accepting input.

This traverses every block for arbitrary stored witnesses. It uses no
sparse support list, honest-witness premise or zero-skipping assumption.
It never materializes the full key. It must not invoke a function-valued
key from inside each convolution term, because that would repeat ChaCha20
expansion instead of performing a stored coefficient read.

The semantic `ringFSum` uses recursive function projections. It is a value
target, not a suitable artifact-sized executable traversal. A direct
`Fin.foldl` over blocks needs a structural equality to that sum, using
field addition associativity. Do not build `List.finRange blockCount` or
an accumulated `index.succ` accessor chain. The existing stored array
builder in `StoredAssignmentArithmetic.build` can be reused for fixed
54-lane outputs, with its value/work lemmas.

## Required coefficient count

Let `R` be the symbolic commitment row count, `M` the complete witness
block count, and `d=54` the fixed ring degree. The full dense path generates
`R*M*d` key coefficients and computes `R*M` ring products for one witness.
These counts assume only local retention of the current key block.

The selected source proves `R=22`, `M=4,708,530`, and carrier width
`M*d=254,260,620`, in
[Poseidon2HashChainV1Setup](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/Poseidon2HashChainV1Setup.lean:19).
Thus one arbitrary witness requires, on the full path:

```
22 * 4,708,530 = 103,587,660 ring block products
22 * 4,708,530 * 54 = 5,593,733,640 ChaCha20 coefficient generations.
```

The parent checker invokes this primitive per source. The selected source
count is 17; the full parent bound must retain that factor. Early rejection
can reduce executed work. It cannot justify a smaller bound for arbitrary
successful witnesses. No dense execution was attempted.

## Generator operations and reusable lemmas

The exact generator is
[ChaCha20.lean](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/AjtaiSetupV1/ChaCha20.lean:28).
Count the actual current functions first; do not silently replace them with
a different byte or word implementation.

- `initialState` constructs 16 words. Its eight `littleEndian32` calls read
  seed offsets 0 through 31 from a list. The 32 reads visit prefixes with
  total length `1+...+32=528`; charge list traversal, control and the byte
  arithmetic. These are not constant-time list lookups. Charge nonce and
  counter division/modulus and state construction as well.
- `runDoubleRounds 10` performs eight quarter rounds per double round:
  exactly 80 quarter rounds per coefficient generation.
- Each current `quarterRound` has five array reads (the original B word is
  read twice), four array writes, four `add32`, four `xor32` and four
  `rotateLeft32` calls. Each named word operation still needs its internal
  Nat arithmetic, shifts, modular reduction, branch and result count.
- `blockWords` computes all 16 feed-forward words: 32 array reads and 16
  modular additions, plus its range/map construction. `first256Nat` then
  takes eight words, reverses that list and folds it. Charge all these
  current list operations; do not charge only eight feed-forward words
  without first proving a different executed implementation equivalent.
- The final fold has eight multiply/add steps. Its prefix value after `j`
  words is below `2^(32*j)`, derived from canonical output words. Hence the
  final reduction has a 256-bit dividend and the fixed Goldilocks modulus.
  Charge that reduction and the final field/result constructors.

[WordOperations](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/AjtaiSetupV1/WordOperations.lean)
already exports the following useful deterministic facts:

- `add32_eq_bitvec`, `xor32_eq_bitvec`, `rotateLeft32_eq_bitvec`;
- `quarterRound_eq_bitvec`, `quarterRound_canonical`, `quarterRound_size`;
- `initialState_canonical`, `initialState_size`, `getWord_canonical`;
- `runDoubleRounds_canonical`, `runDoubleRounds_size`;
- `initialState_rfc_framing`, `doubleRound_eq_schedule`,
  `runDoubleRounds_eq_iterate`, `blockWords_eq_feedForward`;
- `blockWords_length`, `blockWords_canonical`.

These give value and operand-size invariants, not work counts. The current
quarter-round updates can copy a shared 16-word array; retain that cost or
prove the relevant execution representation bound. Do not assume unique
buffers or unproved compiler optimizations.

`IndexEncoding.initialState_seed_word` identifies the seed positions.
`initialState_index_injective` uses the explicit bounds `row<2^32`,
`block<2^64`, `lane<2^32`; the selected dimensions satisfy them. Those bounds
are not new acceptance limits for a general counted value theorem. For
symbolic dimensions, include the input-index bit lengths in arithmetic work
or state the named-operation model explicitly. The generator's modulo
semantics remains defined even outside those index ranges.

`wideCoefficientNat_lt` and `Setup.coefficientNat_lt` already establish the
final field range. No uniform-key or reduction-bias assumption is needed
for this deterministic value/work proof.

## Dense ring multiplication and lookup work

The smallest proof change can follow the exact formula in
[Spec.Algebra.ringFMul](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Algebra.lean:81):
for each of 54 output coefficients, compute its low convolution, the
degree-54/27 folded convolution, and the possible degree-81 second fold.
Each raw convolution traverses the fixed 54 input indices and reads from
the two retained arrays. This gives at most `3*d*d` raw-term visits per
ring product, with all conditions, reads and field operations charged.
The new Pad routine's `raw_prefix_value` proof is a local proof pattern;
it is private and specialized, not a reusable generic multiplication API.

Prove a stored multiplication value lemma by structural induction over the
raw convolution loop, then the exact output reduction branches. This avoids
a new multiplication algorithm. `CarrierAction.assignmentBlock` identifies
the witness block through `carrierColumn`; the existing
`decode_carrierColumn` law fixes that flattening. Every carrier block is
complete, so no padding/default-read premise is needed.

Use array reads for stored witness coefficients, key coefficients and row
accumulators. Charge direct index multiplication/addition, Fin construction,
array access and output allocation. Avoid list indexing in artifact-sized
data. The selected public commitments are already arrays:
`Input.commitment : Vector F 1188` and
`Input.running.commitments : Vector (Vector F 1188) 16` in
[PiCCSInputCheck](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PiCCSInputCheck.lean:36).
The flat row/lane offset is `row*54+lane`. Its exact semantic links are the
definitions `proofValues`, `runningFromInput` and `outputCommitments`.
Charge fresh/running selection and all actual array/record reads. A semantic
commitment function itself does not receive a free lookup bound.

## Value and work obligations

The local counted routines must return value and work from one execution.
The required sequence is:

1. Counted word/block/wide-coefficient value equalities to the existing
   `ChaCha20` and `AjtaiSetupV1` definitions, with size invariants and derived
   work bounds.
2. A key-block value equality for every `(row,block,lane)` of the selected
   setup, and a witness-block equality to `CarrierAction.assignmentBlock`.
3. Stored multiplication and addition value/work lemmas; then a structural
   row-fold equality to `Commitment.ajtaiRow` for symbolic `R,M`.
4. The Boolean comparison equivalence, for every stored witness and source:

```
(commitmentCheck input stored source).value =
  decide (PiCCSStoredWitnessCheck.commit (stored.get source).get =
    (PiCCSStoredWitnessCheck.statement input).commitments source).
```

5. A bound derived from those same calls, schematically

```
sourceRead + R * (rowInit(d) +
  M * (keyBlock(d,R,M) + witnessBlock(d) + ringMul(d) + rowAdd(d) + blockControl) +
  rowCompare(d) + rowControl) + return.
```

Each named term must be defined from the implementation and proved, not
left as a new assumed primitive bound. Specialize the symbolic theorem to
`R=22`, `M=4,708,530`, then install this program and bound in the existing
selected `scalarProgram`/`scalarBounds` boundary. Preserve universal scope
over arbitrary stored witnesses. The parent checker already supplies the
source loop and its rejection accounting.

This preparation proves no cost theorem and gives no wall-time estimate.
It requires no sparse commitment theorem, full-key materialization, new
cache, interface, cryptographic assumption or numerical execution limit.
