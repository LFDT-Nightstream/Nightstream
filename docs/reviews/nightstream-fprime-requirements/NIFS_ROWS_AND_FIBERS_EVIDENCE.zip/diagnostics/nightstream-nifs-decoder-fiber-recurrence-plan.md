# Exact decoder-fiber recurrence: next source plan

Prepared by Worker 2, 2026-09-10. Source work is conditional on the final
`FieldPreimageRectangle` build passing and the coordinator accepting this
boundary. No new decoder, random primitive, transcript law, or model is
selected. The coordinator owns all builds and audits.

## Smallest semantic interface

Use a new Spec owner
`Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldDecoderFiberCount.lean`.
For a symbolic number `n` of field lanes, retain the carrier `Fin n -> F`.
Its ordered candidate-list view appends `FieldPairLaw.candidates` low then
high for every lane in `List.ofFn` order. This is only a list view of the
existing candidate function. Sampling remains the existing
`FirstAccepted.boundedSample ProductionAlphabet.verifier`.

Let `SuccessFiber n target` be the subtype of field windows whose existing
bounded sampler, with need `target.length`, returns `some target`. Let
`AbortFiber n need` be the subtype whose same sampler returns `none`.
The target is a `List Coefficient`, not a centered integer or field list.
This makes each successful state a requested suffix; it does not admit
prefixes that already produced a wrong digit.

Define arithmetic functions `successCount n target` and `abortCount n need`
by the recurrences below. They specify counts. They do not claim an efficient
table implementation: directly evaluating repeated recursive calls would
not establish the planned stored-DP work bound.

Public mathematical targets are the two exact subtype-cardinality identities
and the selected 32-lane candidate-list equality. Base, saturated, one-digit,
and two-digit recurrence equations can remain transparent definition
equations. Branch decomposition bijections should stay private until a
rank/unrank consumer requires their interface. Avoid a general branching
framework or an arbitrary-predicate class API.

## Rectangle weights and ordered transitions

Write `h=65536`, `M=h*h`, `m=M-1`, `q=m*M+1`, `a=13107`, and `v=65535`.
Use only `FieldPreimageRectangle.ChunkClass` and `rectangle_card`:

```text
W(A,B) = m*size(A)*size(B) + [A.HasZero and B.HasZero].
```

Here `HasZero (.residue d)` means `d.val=0`. It refers to raw candidate zero
and raw alphabet index zero. `ProductionAlphabet.centeredValue d=d.val-2`,
so raw index zero represents centered coefficient -2; centered zero has raw
index 2. No zero test may move across the centered/ring embedding unchanged.
The existing `symbol` and `scalarOfList` interfaces preserve raw alphabet
indices; the later ring embedding is outside these count states.

For success, the base is `S(0,[]) = 1` and `S(0,d::tail) = 0`.

| Remaining target | Disjoint first-lane rectangles and next target |
|---|---|
| `[]` | `(H,H)` with `[]` |
| `[d]` | `(R,R)` with `[d]`; `(R,T_d)` with `[]`; `(T_d,H)` with `[]` |
| `d::e::tail` | `(R,R)` with the same target; `(R,T_d)` with `e::tail`; `(T_d,R)` with `e::tail`; `(T_d,T_e)` with `tail` |

The recurrence therefore is

```text
S(n+1,[]) = q*S(n,[])
S(n+1,[d]) = m*S(n,[d]) + (m*a*(h+1)+[d.val=0])*S(n,[])
S(n+1,d::e::tail) = m*S(n,d::e::tail) + 2*m*a*S(n,e::tail)
                    + (m*a*a+[d.val=0 and e.val=0])*S(n,tail).
```

The singleton-target `(T_d,H)` branch is essential: a matching low chunk
completes the output, so the high chunk is unrestricted. Saturation retains
all later fields, including all unused candidates in the 64-position window.

For abort, use no target digits. Its base is `A(0,k)=[0<k]`, and
`A(n+1,0)=0`. For `k+1` needed accepts, partition the first lane into
`(R,R)`, `(R,V)`, `(V,R)`, `(V,V)`. These advance by zero, one, one, and two
accepts, with subtraction clamped at zero:

```text
A(n+1,k+1) = m*A(n,k+1) + 2*m*v*A(n,k)
             + (m*v*v+1)*A(n,k-1).
```

This retains every aborting window, including accepted prefixes whose digits
do not match the chosen fallback. The four abort weights sum to `q`.

## Structural proof route

Prove the head-pair success and abort event partitions from existing
`acceptedCandidates`, `acceptedSymbols`, and `boundedSample` equations.
Use the existing success-length and none-iff-shortfall lemmas to retain the
exact output length and failure condition. A wrong accepted digit excludes
only its success branch; it must never restrict an abort branch.

Split a `Fin (n+1) -> F` window into its first field and its suffix. Construct
explicit disjoint-sum/product bijections for the branch fibers, then apply
`Nat.card_congr`, product/sum cardinality, and `rectangle_card`. Keep `n`,
the requested suffix, and all field-window carriers symbolic. No enumeration
of `F`, `2^32` words, or `5^54` targets is needed. Do not solve a subtype
cardinality goal by rewriting through concrete Fintype instances.

Prove the selected candidate-list equality using `List.ofFn_mul` at two
chunks per lane, the existing little-endian `pairEquiv`, and the already
fixed `fieldLaneCount=32`, `candidateBound=64`. Then the generic count
identities apply to the exact current field-window view.

## Narrow Lifecycle consumer

A new `Lifecycle/PiRLC/v1_1/SamplerFiberCount.lean` may import the Spec owner
and the frozen `SamplerOutputLaw` / `SamplerTotalizedOutputLaw` owners. No
Spec module may import these Lifecycle definitions.

First prove the missing codec direction for lists of length 54:
`List.ofFn (scalarOfList values) = values`. Combine it with the existing
`scalarOfList_ofFn` and bounded-success length to identify

```text
fieldDecode fields = some s
  iff boundedSample ... = some (List.ofFn s).
```

The full selected fiber target, for the arbitrary supplied fallback `f`, is

```text
Nat.card {fields // totalizedFieldDecode f fields = s}
  = successCount 32 (List.ofFn s)
    + if s=f then abortCount 32 54 else 0.
```

Use a disjoint sum of success and abort fibers. Keep this scalarwise
totalization as a comparison-only function: the actual protocol still
aborts. The comparison identity makes no assertion about failed successor
states or Poseidon2 output distributions.

## Closing evidence and remaining obligations

The complete next mathematical criterion is the two finite count identities,
the exact selected list-view link, and the totalized scalar-fiber formula.
The coordinator runs the focused Spec and Lifecycle targets and audits every
export. The existing three-round rule applies to each bounded criterion.
No source is added while Rectangle round 3 is pending.

After these counts, the complete inverse still needs explicit positive-fiber
witnesses, the stored DP and its value/work refinement, global rank/unrank
inverses, an exact uniform-rank primitive with its time contract, the uniform
fiber law and joint resampling/cache theorem, and the 17-coordinate product
fiber transport. Exact transcript schedule, additive absorption, extraction,
and fixed-Poseidon2 transfer remain separate. The 17 August 2026 CFRG draft
is a nonclosing reference; its generic claims supply no Nightstream theorem.
