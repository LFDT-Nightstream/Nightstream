Selected PiDEC commitment matrix entries: full owner criterion passed on round 3.

Active source: `/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PiDECCommitmentMatrixEntry.lean`. Final size: 282 lines, 15,846 bytes. Final SHA256: `19378ec8c18868d7cfd3dca32c5e42b83b27e41662dea62ebfa047fdb06926d7`. The active file and its prior owners are frozen.

Root ran the same complete target, `NightstreamFPrime.Export.Stage1.PiDECCommitmentMatrixEntry`, through the normal capped validation queue in all three rounds. No worker build, resource override or narrower replacement check was used.

| Round | Result | Complete source hash | Log |
|---|---|---|---|
| 1 | Exit 1; module 9.5s. The append proof needed its final definitional equality, the port decoder namespace was wrong, and local aliases in clock hypotheses did not align. | `cf7a2b3b25e535780e538f78b4e3962e1b816e2a3e6bd6d5fb870487bef67a49` | `/tmp/nightstream-nifs-pidec-commitment-matrix-entry-1.log` |
| 2 | Exit 1; module 17s. Only the 14 port cases remained, each blocked on the exact SelectivePolynomial.meaningfulPortCount definition. | `3bd7d051dfd43942cbfcc558f56b7c8fa085d64f12c20248dd41c2f61d2142c0` | `/tmp/nightstream-nifs-pidec-commitment-matrix-entry-2.log` |
| 3 | Exit 0; 3660 jobs, module 17s, wrapper 18s. Full criterion passed. | `19378ec8c18868d7cfd3dca32c5e42b83b27e41662dea62ebfa047fdb06926d7` | `/tmp/nightstream-nifs-pidec-commitment-matrix-entry-3.log` |

The first source had 281 lines and 15,734 bytes; round 2 had 281 lines and 15,775 bytes. Both repairs changed proof code only. Runtime, complete coordinate coverage and the declared bound stayed unchanged across all three builds.

The three public theorem exports for root's audit registration are:

- `PiDECCommitmentMatrixEntry.globalRow_val`.
- `PiDECCommitmentMatrixEntry.entry_value`.
- `PiDECCommitmentMatrixEntry.entry_work_le`.

Paper authority is corrected SuperNeo v1.1 [Section 7.3](/home/nicoarq/develop/Nightstream/docs/superneo-paper-v1_1/07_superneo_folding_scheme_for_ccs.md), with [Appendix B.2](/home/nicoarq/develop/Nightstream/docs/superneo-paper-v1_1/11_appendix_B_deferred_theorems_and_proofs.md), for the coefficient-matrix witness checks. Section 7.5 and Appendix B.4 own the commitment recomposition rows used by this packet. The Nightstream profile remains Goldilocks, b = 2, k_rho = 16, B = 65536, 17 sources, 16 children, 14 matrices, 54 coefficients and 28 row variables. Pad remains separate from the matrix family.

The public entry takes a matrix index, coefficient index, typed local row `Fin 1188`, and any column in the selected completed carrier. Its theorem covers all 14 ports, all 54 coefficients, every local row, and all 254260620 carrier columns. It has no supplied semantic matrix equality or kernel-work premise.

The full row/source consumer is now linked to the actual selected relation:

1. `PiDECOrdinarySourceWork` generates the exact ordered A16/B0/C1 source row. `PiDECCommitmentMatrixWork.commitmentForms` constructs its two selected retained blocks and full ordinary forms once. It preserves coefficient values, zero constants, duplicate columns and entry order.
2. The new structural `fullRow` proof follows the existing plan append tree. The PiRLC-complete prefix has 5998867 rows; the preceding PiDEC public packet has 22680 rows. Thus the commitment packet begins at 6021547 and occupies `[6021547, 6022735)`. The source's `globalRow` is proved to reach those exact selected-plan forms, using the fixed-point plan equality. The constant offset is not justified only by a numeric bound.
3. `selectPort` reads selector/A/B/C for ports 1/2/3/4. Ports 0 and 5–13 are empty on these ordinary rows. Its exact value is the original full 14-port view. The maximum entry-list length is 657; the other live lengths are selector 1, B 1 and C 42.
4. `Poseidon2HashChainV1MatrixRows.allPort_coefficient_eq_logicalRelation_matrix` and `PiDECInputCheck.relation_eq_selected` connect the stored form to the actual key-facing logical matrix. `CoefficientWork.coefficient_value` then connects all 54 expanded coefficient lanes to `(InputBinding.relationSource PiDECInputCheck.relation).matrixSource.coefficientMatrix` at `selectedPlan.rowLayout.toVertex (globalRow row)`.

The executable call uses the proved logical-width literal 254260583 and erased width transports. Coefficient expansion retains the source-lane width check, including for queries in the 37-column completion suffix. It does not replace that rule with a zero check on the queried assignment column.

The proved bound is for the **composed declared clock**, with this derivation:

| Component | Declared bound |
|---|---:|
| Existing kernel raw sum | 54 × (28 + 4) + 4 = 1732 |
| Existing selected kernel | 3 × 1732 + 12 = 5208 |
| Existing coefficient expansion for at most 657 entries | 54 × (6570 + 8 + 5208 + 14 + 8) + 11 = 637643 |
| Complete commitment form generation | 254729 |
| Full port selector | at most 20; live ports cost 6/9/12/15 |
| Entry wrapper | 8: three calls, three value reads, width literal and Result |
| Complete typed-local-row entry | 254729 + 20 + 637643 + 8 = 892400 |

The existing kernel and other callee bounds concern their returned `Result.work` counters. They do not yet have a complete refinement to the current detailed source-operation model; some earlier call and loop administration charges are not represented there. Therefore 892400 is not a complete source-operation, machine-runtime, bit-complexity or wall-time bound. Counter-to-execution refinement remains a named separate obligation.

The local row is already typed when entry is called. The global offset and Boolean vertex appear in its semantic reference, not in the executed entry program. A full global dispatcher must separately execute and count vertex decoding, range checks and local-index subtraction. No offset callback was assigned a free clock.

Remaining scope is explicit: the relation-to-actual-entry link is closed for this complete 1188-row block. The other source-producing families, all-row dispatcher, full selected matrixEntry installation, and complete runtime-cost refinement remain open. No partial matrix implementation was installed as the full checker primitive. Root owns combined audit registration and the milestone; this note does not claim those later steps have run.
