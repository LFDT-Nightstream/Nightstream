# Independent selected PiDEC matrix-entry review

Reviewer: Worker 3, `/root/conformance_review`.
Worktree: `/home/nicoarq/develop/Nightstream-nifs-proof-links`.
Scope: the complete new PiDECCommitmentMatrixEntry owner, its append-tree
embedding, exact selected coefficient-matrix target, and composed declared
clock. No source edit, build, test, or matrix generation was run for this review.

Result: no defect found in the stated value or declared-clock scope. The
full build is still a separate pending record at this point. This local
entry owner does not close global row dispatch, Boolean-vertex conversion,
all other matrix-row families, or source/runtime refinement of child clocks.

## Reviewed source

The new file is
`formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PiDECCommitmentMatrixEntry.lean`:
281 lines, 15734 bytes, SHA-256
`cf7a2b3b25e535780e538f78b4e3962e1b816e2a3e6bd6d5fb870487bef67a49`.
Relevant consumed source identities, under the same NightstreamFPrime prefix:

| Owner | SHA-256 |
| --- | --- |
| `Export/Stage1/PiDECCommitmentMatrixWork.lean` | `daacaf6cccad805757b70ead43c866de82774f0cba5f302fce1c06f44ece638f` |
| `Export/MatrixProgram/CoefficientWork.lean` | `2369a33a7858af3c3ce27f04055470ec56d7454bc269d273fa650f7150e16890` |
| `Export/Stage1/Poseidon2HashChainV1MatrixRows.lean` | `fac3b1c6382ef5d33678fb11a367dec374c91132b968b88b6cc38aaf3b8108d4` |
| `Spec/Folding/PiCCS/PaperJoint/StoredWitnessCheckEntries.lean` | `b314be8e9a80db5db9ae8eb62f7a9f098eaa76ba3eb74af80d0779c305791f02` |

## Exact row and relation

The private fullRow at lines59-84 walks the existing append tree. Its two
right embeddings contribute 5998867 rows from the complete PiRLC prefix and
22680 rows from the PiDEC public plan. Thus the commitment packet starts at
6021547. The commitment component is the left side of PiDEC recomposition;
the enclosing transition, application, next-preimage, and public-output
append operations embed it on the left and add no further offset.

The counts are existing plan theorems:
DirectPiRLCSamplerCompletePrefixPlan.piRlcCompletePlan_rowCount gives
5998867; PiDECDirectPlan.publicPlan_rowCount gives 22680;
PiDECDirectPlan.commitmentPlan_rowCount gives 1188. fullRow_val proves their
sum through leftIndex_val/rightIndex_val, rather than assuming the constant.
globalRow then maps every local Fin1188 into the selected plan at that offset.
It is a semantic row reference; the entry program does not execute it.

fullRow_port uses append port laws to reach the same commitmentDirectForms.
globalRow_port transports through the existing per-application fixed-point
plan equality. PiDECInputCheck.relation_eq_selected identifies the compact
PiDEC relation with the selected fixed-point relation. The existing
Poseidon2HashChainV1MatrixRows.allPort_coefficient_eq_logicalRelation_matrix
then identifies every stored port coefficient with that relation's matrix
at the canonical row vertex. No caller supplies an alternative matrix or row.

## All ports, coefficients, and columns

The runtime selector at lines150-162 returns selector/A/B/C for ports1/2/3/4
and an actual empty sparse form for the other ports of this ordinary row.
The proof covers all fourteen matrix indices. Empty ports here are the
existing matrix entries, not omitted evaluations or aliases for Pad. The
separate Pad family is unchanged.

entry constructs the requested row's complete forms once, selects one stored
port once, and calls the existing coefficient expansion once. That expansion
scans all 54 source lanes with duplicate-aware sparse coefficient scans.
Its logical-width guard tests each source lane. It does not zero a query just
because the assignment column is in the completed carrier tail. This matters
for the selected logical width254260583 and complete carrier254260620: all
37 tail columns remain in the theorem's input domain.

The public entry_value theorem quantifies over every matrix port, every
coefficient lane, every local row, and every complete-carrier column. Its
target is exactly
`(Lifecycle.PiRLC.v1_1.InputBinding.relationSource PiDECInputCheck.relation).matrixSource.coefficientMatrix`
at the selected row vertex and baseOps. The private coefficient_for_relation
helper has a row equality parameter, but the public theorem discharges it
with selected_port_coefficient. The kernel is the concrete Phi81 kernel,
through existing kernelWeight_value/work laws. There is no public kernel,
matrix, row-coefficient, or sparse-shape premise.

The explicit selected-width literal changes only the computational dimension
argument. Equality transports on forms and columns are proof casts. The
coefficient_cast lemma proves the complete Result transport, and the value
proof uses it before substituting the exact relation.

## Declared counter composition

The new port selector charges one index read and three operations for each
literal/comparison/branch. Live field/result costs two. Its four live branches
cost6/9/12/15; the empty branch adds Unit/call/value/Result and the actual
SparseWork.empty counter, for20. Its stored form length is at most657 by the
complete form-length theorem (selector/A/B/C lengths1/657/1/42).

The coefficient expansion includes the existing concrete kernel's declared
5208 bound. Its monotone length bound evaluates to
54*(10*657+8+5208+14+8)+3+8=637643. The outer entry charges three calls,
their three value reads, the selected-width literal, and Result: eight.
Therefore entryWork is exactly254729+20+637643+8=892400.

This composes declared child counters with the new wrapper charges. The
source header and entryWork comment state that scope explicitly. It is not
a complete source-operation, compiler, allocation, or machine-runtime bound
for the child implementations. In particular, the existing CoefficientWork
and kernel counters are reused as declared counters, not promoted to runtime
theorems by this adapter. The global dispatcher, row/vertex conversion,
other row families, and final selected matrixEntry installation remain open.
No new cryptographic assumption, profile, execution budget, or backend
authorization follows from these three local exports.

## Final source and full check

The final file is282 lines,15846 bytes, SHA-256
`19378ec8c18868d7cfd3dca32c5e42b83b27e41662dea62ebfa047fdb06926d7`.
I compared it with the retained original cf7a2b3b source. The only changes
are proof repairs: final reflexivity after append-port transport, the correct
Layout.meaningfulPort? namespace and explicit meaningful-port-count unfolding,
and explicit local counter/length types in entry_work_le. No executable body,
counter formula, source domain, or public theorem statement changes. The
original value and declared-clock review therefore applies to the final bytes.

I read `/tmp/nightstream-nifs-pidec-commitment-matrix-entry-3.log`:
the complete target passed with3660 dependency jobs,17 seconds for the module,
18 seconds for the wrapper, and terminal exit0. The log SHA-256 is
`633673de5ff3f8da83159231ce89fec9800cf296ab13ae474f08180ee665ac14`.
The combined audit is separate pending evidence at this point. This passing
local entry theorem does not change the global-dispatch, other-row-family,
selected-consumer, or child-counter/runtime limits above.
