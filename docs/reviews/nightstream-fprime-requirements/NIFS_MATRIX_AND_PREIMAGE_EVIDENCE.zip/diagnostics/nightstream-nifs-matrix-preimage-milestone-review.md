# Independent matrix/preimage milestone review

Reviewer: Worker 3, `/root/conformance_review`.
Code cut: `4049d6133972475eaa4cd61e27d447da48349392`.
Worktree: `/home/nicoarq/develop/Nightstream-nifs-proof-links`.

Result: **the four modules, their declared scope, and all 25 new audit
registrations agree with the retained checked source and records**.
The reviewer read the final sources and parsed the full audit independently.
No build, test, generator, backend, or active source edit was performed.
Requirements-map updates and archive assembly are outside this review.

## Four active owners

`SparseWork` has ten exports: `empty_value`, `empty_work`,
`singleton_value`, `singleton_work`, `add_value`, `add_work`, `scale_value`,
`scale_work`, `coefficient_value`, and `coefficient_work_le`.
They relate the counted operations to the existing sparse forms. Add copies
the left list through two reverse passes and shares the right tail. Scale
preserves list order and zero entries. Coefficient lookup scans all entries
and sums every matching column, including duplicates. The bounds use list
length, not distinct-column count: add is `10*left.length+13`, scale is
`14*length+13`, and coefficient lookup is at most `10*length+8`. Empty and
singleton cost three and five, respectively. No row-generation callback
receives a free work bound from these results.

`CoefficientWork` has two exports: `coefficient_value` and
`coefficient_work_le`. It considers all 54 source lanes of the queried
assignment block and applies the logical-width guard to each source lane.
Each live lane invokes the duplicate-aware stored-row scan and the existing
Phi81 kernel. A queried completion-tail column is not itself a reason to
return zero. The semantic row-equality premise is explicit and belongs to
the caller that constructs the row. The theorem uses exactly the supplied
matrix family, matrix slot, Boolean row, polynomial and source dimensions.
It does not execute that matrix function. Its corrected clock is
`54*(10*entries.length+8+kernelWork+14+8)+3+8`.

The final coefficient file differs from the previously reviewed `e611…`
bytes only in the proof's `dsimp only [term]` and the field-access syntax in
the value theorem. Reversing those two text changes reproduces the full
reviewed SHA-256 exactly. The corrected field-zero charges, runtime
definitions, and public theorem meanings remain unchanged. The prior count
correction is retained in `nightstream-nifs-matrix-coefficient-review.md`.

`RetainedWork` has three exports: `form?_value`, `form?_length`, and
`form?_work_le`. It constructs one requested slot after the same slot and
whole-block geometry checks as `RetainedBlock.form?`. It preserves ascending
coordinate order and the existing retained reconstruction weights
`1,3,3^2,...`; this is the existing balanced-ternary retained-slot encoding,
not a change to the NIFS binary decomposition profile. The successful form
has exactly `block.kind.width` entries. Its repeated tail scaling is charged:
the coordinate clock is `7*n^2+49*n+8`, and the complete wrapper bound is
`7*width^2+49*width+25`. Geometry and slot rejections cost 13 and five. It
does not construct all retained slots or establish full selected matrix-row
dispatch/generation work.

`FieldPreimageRectangle` has ten exports: `ChunkClass.index_value`,
`ChunkClass.member_zero_iff`, `ChunkClass.member_card`, `common_rank_value`,
`common_unrank_value`, `extra_rank_value`, `extra_unrank_value`,
`rank_unrank`, `unrank_rank`, and `rectangle_card`. The four classes mean
reject 65535, one accepted residue modulo five, all accepted candidates,
and all candidates. The class equivalences are arithmetic, with cardinality
one, 13,107, 65,535, and 65,536, respectively. The raw-zero test on a residue
uses alphabet index zero; it is not the zero of the later balanced embedding.

For `M=2^32`, the field decomposition has `M-1` common blocks of `M` words
and the extra field `q-1`. Common ranks place the low index first, then high,
then block. The final rank exists exactly when both candidate classes contain
raw zero. The cardinality is `(M-1)*low.size*high.size + zeroBonus`.
The actual field/candidate maps and both restrictions are preserved by the
equivalences; no field words are enumerated. These ten results do not prove
a full 32-field decoder fiber, a random sampler, its work, an adaptive oracle
law, or a Poseidon2/Fiat--Shamir transfer.

The Sparse/Retained review by Worker 2 and the rectangle review by the root
remain separately attributed records. This milestone review independently
checked the final source definitions, public statements and claimed scopes.
All work figures are the stated named-operation clocks, excluding clock
instrumentation. They are not machine-instruction, allocator, bit-complexity,
wall-time or gas theorems. The existing kernel/builder clock scope is not
expanded by these callers.

## Exact registration and validation check

The final source has 361 distinct `#audit_axioms` registrations. Its original
336 names remain the same prefix in the same order. The 25 additions equal
the complete public theorem sets of the four modules: `10 + 2 + 3 + 10`.
No new theorem is missing and no extra theorem is attributed to these owners.
The registration order need not equal declaration order within a module;
the recorded audit follows its registration order exactly.

Independent parsing of the complete final log found 361 headers, 361 complete
records and 361 distinct names, with no missing or extra record. The names
match the source order exactly. The only axioms are `propext`,
`Classical.choice` and `Quot.sound`; there are no source errors. The build
completed 3,727 jobs with terminal exit zero in three seconds.

| Full focused check | Final recorded result |
|---|---|
| SparseWork round 2 | exit 0; 3s wrapper, 1.7s module |
| CoefficientWork round 2 | exit 0; 3s wrapper, 1.7s module |
| RetainedWork round 3 | exit 0; 2s wrapper, 1.8s module |
| FieldPreimageRectangle round 3 | exit 0; 1s wrapper, 1.2s module |

These are the log's separate measurements; they are not runtime benchmarks
of the represented matrix or sampler tasks. Static-2 reports
`[boundary] all checks passed`. That text contains no separate terminal-code
line, so this reviewer does not infer one from the text alone. Static-1 had
reported an unrelated pending ordinary-source module as unreachable. That
pending work is not in this five-file milestone.

The manifest contains exactly five distinct files: the four modules and
`tests/AxiomsNifsClosure.lean`. Every current file and every corresponding
blob in code commit `4049d613…` matches both its recorded SHA-256 and byte
length. The commit contains exactly those five paths. Its new-export list
matches the 25 appended registrations in order.

## Stopped links remain open

The resumed selected commitment check is inactive after three attempts.
Its last full log reports a 799s module attempt and Lean exit 143, followed
by build failure. The preserved 292-line draft has SHA-256
`8e17f212c162c279941377e9772fe4e51441f0820d7c879abb475724997595a9`
at `drafts/NIFS_STORED_COMMITMENT_CHECK_RESUMED.lean.txt`. Its source review
did not find a value/count defect, but it did not pass validation or install
the adapter. The older 273-line draft remains separately preserved.

This worker's totalized verifier comparison also remains inactive after
three full failed rounds. The 235-line draft and its final PiDEC/output
congruence diagnostics are retained in
`nightstream-nifs-totalized-comparison-stopped.md`. This author status is
not independent approval. The complete accepted-verifier adapter remains
open, despite the earlier finite output and successful-list laws.

Both stopped modules are absent from active source, this code commit, and
the audit names. No fourth or narrowed retry is claimed. The unchanged
selected witness checker still has commitment and matrix-entry contracts.
Stored producer, complete representation/runtime, inverse selection and
Fiat--Shamir transfer remain separate. No map status, model approval,
publication, or broader conformance closure follows from this milestone.

## Exact identities

Source paths are relative to `formal/nightstream-fprime/`.

| Source | Bytes | SHA-256 |
|---|---:|---|
| `NightstreamFPrime/Export/MatrixProgram/SparseWork.lean` | 8,356 | `f0fb6484581a5844c45c8d0db1b4b4519691661cdf8433c4db8dcedf3be8ed09` |
| `NightstreamFPrime/Export/MatrixProgram/CoefficientWork.lean` | 8,097 | `2369a33a7858af3c3ce27f04055470ec56d7454bc269d273fa650f7150e16890` |
| `NightstreamFPrime/Export/MatrixProgram/RetainedWork.lean` | 5,682 | `ba3cbe568115f14105fe7665134bc916da0420638adbbde9454602ceb9b7e7fc` |
| `NightstreamFPrime/Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldPreimageRectangle.lean` | 13,144 | `cb7c539cb13b21e0a3acd82e2b6d5945a4f1be50b8f10eb45f5b63116c3c89d6` |
| `tests/AxiomsNifsClosure.lean` | 40,319 | `15d41347532500a60c1aadbb8441e1ca2771bd6e7c1910741c46635b839d1766` |

| Retained record under `/tmp/` | SHA-256 |
|---|---|
| `nightstream-nifs-matrix-preimage-axioms-1.log` | `cde7f13495a1c3019790a3a35870b74612cc82bc22d3b457caac60dcb56fc033` |
| `nightstream-nifs-matrix-preimage-code-files.json` | `07b5614b069ca9d55b7cb4ce95cce59261b651da098c36b77da37afc6da27e53` |
| `nightstream-nifs-matrix-preimage-static-2.log` | `ad9e1e52d1607f377312108c20dbf84566406a2fdee0bfc46b65be21824f33e0` |
