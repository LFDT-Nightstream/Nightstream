"""Resume the documented fixture generators with the current identity.

Each generator has its own project guard and cap. Every join checks its source,
point, commitment and public-input headers. These are generated fixtures;
independent raw-assignment and opening evaluations are separate checks.
"""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys

store = Path(__file__).resolve().parent
root = store / 'fixtures'
identity = json.loads((root / 'identity.json').read_text())
context = json.loads((root / 'context.json').read_text())
cargo = ['cargo', 'run', '--locked', '--release', '--target-dir',
         '/Users/nijaar/starstream/nightstream-stage1-evidence/review-folding-closure-708431f5/cargo-target',
         '-p', 'neo-fold-clean', '--bin', 'generate_pi_ccs_fixture', '--']
key = [str(root / 'candidate.json'), *map(str, identity)]
families = ','.join(['K', *[f'A{i}' for i in range(14)]])
joins = []


def run(label, kind, command):
    subprocess.run([sys.executable, '-B', str(store / 'run.py'), label, kind,
                    *map(str, command)], check=True)


def rust(label, operation, *args, keyed=True):
    run(label, 'rust', [*cargo, operation, *(key if keyed else []), *args])


def lean(label, operation, *args):
    run(label, 'lean', ['bash', 'scripts/validate.sh', operation, *args])


def read(name):
    return json.loads((root / name).read_text())


def write(name, value):
    raw = (json.dumps(value, separators=(',', ':')) + '\n').encode()
    with (root / name).open('xb') as sink:
        sink.write(raw)
    joins.append({'file': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    (root / 'recursive-assembly.json').write_text(json.dumps(joins, indent=2) + '\n')


def zeros(*dimensions):
    return [zeros(*dimensions[1:]) for _ in range(dimensions[0])] if dimensions else 0


def checked_families(directory, point):
    pad = read(f'{directory}/family-K.json')
    matrices = [read(f'{directory}/family-A{j}.json') for j in range(14)]
    assert pad[:6] == [1, identity, context, point, 0, 0]
    assert len(pad[6]) == len(pad[7]) == len(pad[8]) == 16
    for j, matrix in enumerate(matrices):
        assert matrix[:6] == [1, identity, context, point, 1, j]
        assert matrix[6:8] == pad[6:8] and len(matrix[8]) == 16
    return pad, matrices


folded = root / 'first-fold-opening'
children = root / 'first-fold-children'
output = root / 'recursive-piccs-child-families-complete'
output.mkdir()
rust('recursive-child-k-retry', 'child-family-at-rounds', folded, children, 'K',
     root / 'recursive-piccs-rounds.json', output / 'family-K.json')
rust('recursive-child-a-retry', 'child-family-at-rounds', folded, children,
     ','.join(f'A{i}' for i in range(14)), root / 'recursive-piccs-rounds.json',
     root / 'recursive-piccs-child-matrices-complete')
for j in range(14):
    data = (root / 'recursive-piccs-child-matrices-complete' / f'family-A{j}.json').read_bytes()
    with (output / f'family-A{j}.json').open('xb') as sink:
        sink.write(data)
for old in (root / 'recursive-piccs-child-families').glob('family-*.json'):
    assert old.read_bytes() == (output / old.name).read_bytes(), old.name
manifest = json.loads((store / 'inputs.json').read_text())
manifest['child_output_evaluations'] = str(output)
(store / 'inputs.json').write_text(json.dumps(manifest, indent=2) + '\n')
running = read('first-fold-running.json')
point = read('recursive-piccs-rounds.json')[9]
pad, matrices = checked_families('recursive-piccs-child-families-complete', point)
assert pad[6] == running[2] and pad[7] == running[1]
fresh = read('recursive-piccs-fresh-families.json')
assert len(fresh) == 6 and fresh[0] == 1
combined = copy.deepcopy(fresh)
combined[0] = 2
combined[4] = [fresh[4][0], *pad[8]]
combined[5] = [fresh[5][0], *[[matrices[j][8][child] for j in range(14)] for child in range(16)]]
combined.append(running)
assert all(pair == [0, 0] for output in combined[5] for pair in output[13])
write('recursive-piccs-input.json', combined)
lean('recursive-positive-lean', 'pi-ccs-input-check', root / 'recursive-piccs-input.json', root / 'recursive-piccs-lean.json')
assert read('recursive-piccs-lean.json')[-1][0] == 1
rust('recursive-native-driver', 'child-complete-driver', root / 'recursive-opening-cache',
     root / 'recursive-piccs-lean.json', root / 'recursive-running-prefix.u64', folded, root / 'recursive-native-input.json')
assert (root / 'recursive-piccs-input.json').read_bytes() == (root / 'recursive-native-input.json').read_bytes()
print('recursive_native_input_byte_equality=passed', flush=True)
lean('current-piccs-ownership', 'pi-ccs-ownership-audit', *identity, root / 'pi-ccs-ownership.json')
lean('current-pilot-fixture', 'pilot-parity', *context, root / 'pilot.json')
