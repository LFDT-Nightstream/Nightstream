# Next selected PiDEC matrix consumer

Worker1 source plan retained by root, 2026-09-10. No implementation or closure claimed.

Owner: Export/Stage1/PiDECCommitmentMatrixWork.lean. Proposed commitmentForms : Fin1188 -> Result (OrdinaryRow.Forms PiDECInputCheck.logicalWidth). Its value must equal PiDECMatrixProgram.commitmentDirectForms at the selected relation and PerApplicationMatrixProgram.piDecGeometry for Poseidon2HashChainV1Package.application.

Call PiDECOrdinarySourceWork.commitmentRow once. Its returned row already uses projected Spartan columns. Existing piDecCommitmentPackageSourceRow?_eq_some, PerApplicationSourceProjection.base_row and PiDECMatrixProgram.commitmentBlock_row? connect this typed source to the actual block; do not charge a package scan or function-valued projection as one operation.

The16 A terms select proof slots child*1188+index; C selects parent commitment slot index. Construct the actual two selected retained blocks once and prove their fields. Use RetainedWork.form? and substitution_location_form?; the latter establishes uniqueness over all seven ranges. This specialization applies only to the generated rows.

Traverse actual returned A/B/C lists, using SparseWork.scale/add/singleton/empty. Preserve coefficient values, duplicates, order and zero constant entries. Exact returned entry lengths: selector1, A657, B1, C42. The ordinary forms occupy ports1-4; all other10 matrix slots are empty.

Source-row work is2218. Each of17 retained forms costs at most13801; scaling41 entries costs587; append of that41-entry head costs423. These plus constant-form construction yield subtotal254103. This is not a complete bound: count block construction, slot arithmetic, list dispatch, calls/value reads, option handling and record construction from the actual implementation.

The complete selected dispatcher and other source-row families remain necessary before CoefficientWork can close matrixEntry. The selected checker still has commitment and matrix-entry contracts.
