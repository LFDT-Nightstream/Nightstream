"""Run current registered command bodies as explicitly local diagnostics.

This retains command completion checks but does not create lean-graph approval,
checkpoint records, or an independent source review. Cargo uses this task's
existing build directory and still builds the current source for each command.
"""
import datetime
import json
import os
from pathlib import Path
import re
import subprocess
import sys

store = Path(__file__).resolve().parent
source = Path('/Users/nijaar/starstream/Nightstream-fprime-conformance-fixes')
target = '/Users/nijaar/starstream/nightstream-stage1-evidence/review-folding-closure-708431f5/cargo-target'
policy = json.loads((source / 'scripts/lean_graph/obligations.json').read_text())
inputs = json.loads((store / 'inputs.json').read_text())
sys.path.insert(0, str(source / 'scripts'))
from lean_graph.runner import completion


def expand(value):
    def replace(match):
        kind, name, index = match.groups()
        if kind == 'output':
            path = output / name
            path.parent.mkdir(parents=True, exist_ok=True)
            return str(path)
        path = Path(inputs[name])
        assert path.exists(), ('missing input', name, path)
        if kind == 'value':
            result = json.loads(path.read_text())
            return str(result[int(index)] if index is not None else result)
        return str(path)
    return re.sub(r'\{(input|value|output):([^:{}]+)(?::([0-9]+))?\}', replace, value)


def substitute(value):
    if isinstance(value, str):
        result = expand(value)
        return json.loads(result) if value.startswith('{value:') else result
    if isinstance(value, list):
        return [substitute(item) for item in value]
    if isinstance(value, dict):
        return {key: substitute(item) for key, item in value.items()}
    return value


for gate_name in sys.argv[1:]:
    gate = policy['gates'][gate_name]
    output = store / 'diagnostics' / gate_name
    output.mkdir(parents=True, exist_ok=False)
    for index, command in enumerate(gate['commands']):
        argv = [expand(item) for item in command['argv']]
        if argv[0] == 'cargo':
            argv[2:2] = ['--target-dir', target]
        cwd = source / command['cwd']
        guarded = ['python3', '-B', str(source / 'scripts/lean_graph/guard.py'),
                   '--kind', command['kind'], '--cwd', str(cwd), '--', *argv]
        data = json.dumps(substitute(command['stdin_json'])).encode() if 'stdin_json' in command else None
        log = output / f'{index}.log'
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with log.open('xb') as sink:
            result = subprocess.run(guarded, input=data, stdout=sink, stderr=subprocess.STDOUT,
                                    env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
        raw = log.read_text(errors='replace')
        record = {'gate': gate_name, 'index': index, 'started_at': started,
                  'command': guarded, 'stdin': json.loads(data) if data else None,
                  'exit': result.returncode, 'log': str(log),
                  'scope': 'local registered-command diagnostic; no accepted closure'}
        reason = None
        try:
            assert result.returncode == 0, f'exit {result.returncode}'
            expected = command['completion']
            completion(raw, {k: v for k, v in expected.items() if k != 'equal_files'})
            for left, right in expected.get('equal_files', []):
                assert Path(expand(left)).read_bytes() == Path(expand(right)).read_bytes(), 'result bytes differ'
        except Exception as error:
            reason = str(error)
        record['outcome'] = 'failed' if reason else 'passed'
        record['reason'] = reason
        (output / f'{index}.json').write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps({'gate': gate_name, 'outcome': record['outcome'], 'reason': reason, 'log': str(log)}), flush=True)
        if reason:
            print('\n'.join(raw.splitlines()[-25:]), flush=True)
            raise SystemExit(1)
