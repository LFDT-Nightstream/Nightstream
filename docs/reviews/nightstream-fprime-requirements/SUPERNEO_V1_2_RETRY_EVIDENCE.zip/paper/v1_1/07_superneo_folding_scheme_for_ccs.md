# 7 SuperNeo's folding scheme for CCS

## 7.1 Relations

**Definition 18 (Structure).** We define a **structure** as a collection of elements

$$\mathbf{s} := \left\{ \{M_j \in \mathbb{L}^{m \times n_L}\}_{j \in [t]}, f \in \mathbb{L}[X_1, \dots, X_t] \text{ with } \deg(f) < u \right\},$$

which consists of matrices and a polynomial of total degree less than  $u$ .

**Definition 19 (Norm-bounded CCS).** Let  $\mathcal{L} : \mathbb{R}_{\mathbb{F}}^{n_R} \rightarrow \mathbb{C}$  be an arbitrary  $\mathbb{R}_{\mathbb{F}}$ -module homomorphism. Let  $\mathbf{s}$  be a structure as defined in Definition 18. We define the **norm-bounded CCS relation**,  $\text{CCS}(b, \mathcal{L})$ , as follows:

$$\left\{ (\mathbf{s}; (c \in \mathbb{C}, x \in \mathbb{L}^{n_{L,\text{in}}}); w \in \mathbb{L}^{n_L - n_{L,\text{in}}}) : \begin{array}{l} \text{For } z := [x, w] \in \mathbb{L}^{n_L}, \\ z^b := \text{Flat}_{\mathbb{L}}(z) \in \mathbb{F}^{n_{\mathbb{F}}}, \\ \mathbf{z} := \text{Pack}_{\mathbb{L}}(z) \\ \quad = \text{Pack}_{\mathbb{F}}(z^b) \in \mathbb{R}_{\mathbb{F}}^{n_R}, \\ c = \mathcal{L}(\mathbf{z}) \wedge \|z^b\|_{\infty} < b \wedge \\ f(\widetilde{M_1 z}, \dots, \widetilde{M_t z}) \in \text{ZS}_{\log m}(\mathbb{L}) \end{array} \right\}$$

**Definition 20 (Norm-bounded CCS Evaluation Relation).** Let  $s$  be a structure as defined in Definition 18. Let  $\mathcal{L} : R_{\mathbb{F}}^{n_R} \rightarrow \mathbb{C}$  be an arbitrary  $R_{\mathbb{F}}$ -module homomorphism. Define  $\mathcal{L}_{\text{in}} : R_{\mathbb{F}}^{n_R} \rightarrow R_{\mathbb{F}}^{n_{R,\text{in}}}$  to be the trivial  $R_{\mathbb{F}}$ -module homomorphism that projects the first  $n_{R,\text{in}}$  indices. Recall from Definition 1 that  $n_{\mathbb{F}} \leq m$  and  $n_{\text{pad}} := m - n_{\mathbb{F}}$ . Define

$$\text{Pad} := \begin{bmatrix} I_{n_{\mathbb{F}}} \\ 0_{n_{\text{pad}} \times n_{\mathbb{F}}} \end{bmatrix} \in \mathbb{F}^{m \times n_{\mathbb{F}}}.$$

We define the **norm-bounded CCS evaluation relation**,  $\text{CE}(b, \mathcal{L})$ , as follows:

$$\left\{ \begin{array}{l} \left( s; \left( \begin{array}{c} c \in \mathbb{C}, \\ x \in \mathbb{L}^{n_{L,\text{in}}}, \\ r \in \mathbb{K}^{\log m}, \\ y \in R_{\mathbb{K}}, \\ \{y_j \in R_{\mathbb{A}}\}_{j \in [t]} \end{array} \right); z \in \mathbb{L}^{n_L} \right) : \begin{array}{l} z^b := \text{Flat}_{\mathbb{L}}(z) \in \mathbb{F}^{n_{\mathbb{F}}}, \\ \mathbf{x} := \text{Pack}_{\mathbb{L}}(x) \in R_{\mathbb{F}}^{n_{R,\text{in}}}, \\ \mathbf{z} := \text{Pack}_{\mathbb{L}}(z) \\ \quad = \text{Pack}_{\mathbb{F}}(z^b) \in R_{\mathbb{F}}^{n_R}, \\ c = \mathcal{L}(\mathbf{z}) \wedge \mathbf{x} = \mathcal{L}_{\text{in}}(\mathbf{z}) \\ \wedge \left\| z^b \right\|_{\infty} < b \wedge \\ h := \text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad})) \cdot \mathbf{z} \in R_{\mathbb{F}}^m, \\ y = \tilde{h}(r) \wedge \\ \forall j \in [t], \\ h_j := \text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j)) \cdot \mathbf{z} \in R_{\mathbb{L}}^m, \\ y_j = \tilde{h}_j(r). \end{array} \right\}$$

## 7.2 A folding scheme for CCS via interactive reductions

**Definition 21 (Global Reduction Parameters).**

Here, we define the global parameters used in our reductions:

- Define the fields  $\mathbb{F}, \mathbb{L}, \mathbb{K}, \mathbb{A}$ , extension degrees  $\tau, \nu$ , and rings  $R_{\mathbb{F}}, R_{\mathbb{L}}, R_{\mathbb{K}}, R_{\mathbb{A}}$  as in Definition 1. The dimensions  $m, n_L, n_{L,\text{in}}, n_{\mathbb{F}}, n_{\mathbb{F},\text{in}}, n_R, n_{R,\text{in}}$ , CCS parameters  $u, t$ , instance counts  $k, K$ , and norm bounds  $b, B$  are also as in Definition 1.
- Let  $\mathcal{C} \subseteq R_{\mathbb{F}}$  be a strong sampling set (Definition 6) with expansion factor  $T$  such that  $(K+k)T(b-1) < B$  and  $1/|\mathcal{C}| = \text{negl}(\lambda)$ .
- Let  $\text{com} := (\text{Setup}, \text{Commit})$  be a ring commitment scheme (Definition 7), which is homomorphic and  $(2B, \mathcal{C})$ -relaxed binding. For  $\text{pp} \leftarrow \text{Setup}(1^{\lambda}, n_R)$ , define  $\mathcal{L} := \text{Commit}(\text{pp}, \cdot) : R_{\mathbb{F}}^{n_R} \rightarrow \mathbb{C}$ , which is a  $R_{\mathbb{F}}$ -module homomorphism.
- Let  $\mathcal{L}_{\text{in}} : R_{\mathbb{F}}^{n_R} \rightarrow R_{\mathbb{F}}^{n_{R,\text{in}}}$  be the trivial  $R_{\mathbb{F}}$ -module homomorphism that projects the first  $n_{R,\text{in}}$  indices.
- Let  $s$  denote a structure as defined in Definition 18.

In Section 8, we instantiate these parameters with concrete values.

## 7.3 Interactive reduction for CCS – $\Pi_{\text{CCS}}$

**Overview.** The interactive reduction  $\Pi_{\text{CCS}}$  checks that the  $K$  incoming CCS instances (Definition 19) indeed satisfy the required CCS constraints, the  $k$  *evaluation* claims (Definition 20), from the prior folding step, hold for point  $r$ , and checks that the norms of all of the flattened witness vectors (all  $K+k$  of them) involved are less than  $b$ . To do so,  $\Pi_{\text{CCS}}$  relies on the classic sum-check protocol (Definition 11). The approach is inspired by similar reductions from [14, 56].  $\Pi_{\text{CCS}}$  defines helper polynomials that, when used in the sum-check protocol, will perform the previously specified checks.  $\mathbf{F}(\vec{X})$  encodes the CCS constraints (all  $K$  of them).  $\mathbf{NC}(\vec{X})$  encodes the norm constraints (all  $K+k$  of them).  $\mathbf{Eval}_{\mathbb{K}}(\vec{X})$  encodes the flattened-witness evaluation claims (all  $k$  of them).  $\mathbf{Eval}_{\mathbb{A}}(\vec{X})$  encodes the relation evaluation claims (all  $kt$  of them). Finally,  $Q(\vec{X})$  is defined such that if its sum over the boolean hypercube  $\{0, 1\}^{\log(m)}$  equals to the constructed sum  $T$ , then all the respective checks hold.

### CCS reduction $\Pi_{\text{CCS}}$

**Parameters:** Refer to Definition 21.

**Input**  $\in \text{CCS}(b, \mathcal{L})^K \times \text{CE}(b, \mathcal{L})^k$

$$(\mathbf{s}; \quad (c_i \in \mathbb{C}, x_i \in \mathbb{L}^{n_{L,\text{in}}}); \quad w_i \in \mathbb{L}^{n_L - n_{L,\text{in}}})_{i=1}^K,$$

$$(\mathbf{s}; \quad c_i \in \mathbb{C}, x_i \in \mathbb{L}^{n_{L,\text{in}}}, r \in \mathbb{K}^{\log m}, y_i \in \mathbb{R}_{\mathbb{K}}, \{y_{i,j} \in \mathbb{R}_{\mathbb{A}}\}_{j \in [t]}; \quad z_i \in \mathbb{L}^{n_L})_{i=K+1}^{K+k}$$

**Output**  $\in \text{CE}(b, \mathcal{L})^{K+k}$

$$(\mathbf{s}; \quad c_i \in \mathbb{C}, x_i \in \mathbb{L}^{n_{L,\text{in}}}, r' \in \mathbb{K}^{\log m}, y'_i \in \mathbb{R}_{\mathbb{K}}, \{y'_{i,j} \in \mathbb{R}_{\mathbb{A}}\}_{j \in [t]}; \quad z_i \in \mathbb{L}^{n_L})_{i \in [K+k]}$$

**Setup**  $\mathcal{G}(1^\lambda, n_R) \rightarrow \text{pp}$ : Output  $\text{pp} \leftarrow \text{Setup}(1^\lambda, n_R)$ .

**Encoder**  $\mathcal{K}(\text{pp}, \mathbf{s}) \rightarrow (\text{pk}, \text{vk})$ : Output  $((\text{pp}, \mathbf{s}), \perp)$ .

**Reduction**  $\langle \mathcal{P}, \mathcal{V} \rangle((\text{pk}, \text{vk}), u_1, w_1) \rightarrow (u_2; w_2)$ :

1.  $\mathcal{V}$ : Send challenges  $\alpha \xleftarrow{\$} \mathbb{K}^{\log m}$  and  $\gamma \xleftarrow{\$} \mathbb{K}$  to  $\mathcal{P}$ .
2.  $\mathcal{V} \leftrightarrow \mathcal{P}$ : For all  $i \in [K]$ , define  $z_i := [x_i, w_i] \in \mathbb{L}^{n_L}$ . Recall from Definition 20 the matrix  $\text{Pad} \in \mathbb{F}^{m \times n_{\mathbb{F}}}$ . For every  $i \in [K+k]$ , define

$$\begin{aligned} z_i^b &:= \text{Flat}_{\mathbb{L}}(z_i) \in \mathbb{F}^{n_{\mathbb{F}}}, \\ z_i^{b, \text{pad}} &:= \text{Pad} z_i^b \in \mathbb{F}^m, \\ \mathbf{z}_i &:= \text{Pack}_{\mathbb{L}}(z_i) = \text{Pack}_{\mathbb{F}}(z_i^b) \in \mathbb{R}_{\mathbb{F}}^{n_R}, \\ h_i &:= \text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad})) \cdot \mathbf{z}_i \in \mathbb{R}_{\mathbb{F}}^m. \end{aligned}$$

For every  $i \in [K+k]$  and  $j \in [t]$ , define

$$h_{i,j} := \text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j)) \cdot \mathbf{z}_i \in \mathbb{R}_{\mathbb{L}}^m.$$

Finally, define  $\vec{X} := (X_1, \dots, X_{\log m})$ . For  $i \in \{K+1, \dots, K+k\}$ ,  $j \in [t]$ , and  $\ell \in [d]$ , define

$$\begin{aligned} \mathbb{I}_{\mathbb{K}}(i, \ell) &:= (i - K - 1) + k(\ell - 1), \\ \mathbb{I}_{\mathbb{A}}(i, j, \ell) &:= (i - K - 1) + k(j - 1) + kt(\ell - 1). \end{aligned}$$

$$\mathbf{F}(\vec{X}) := \sum_{i=1}^K \gamma^{i-1} \cdot f(\widetilde{M_1 z_i}, \dots, \widetilde{M_t z_i}) \in \mathbb{A}[\vec{X}],$$

$$\text{NC}(\vec{X}) := \sum_{i=1}^{K+k} \gamma^{i-1} \cdot \prod_{a=-b+1}^{b-1} (\widetilde{z_i^{b, \text{pad}}} - a) \in \mathbb{K}[\vec{X}],$$

$$\text{Eval}_{\mathbb{K}}(\vec{X}) := \text{eq}(\vec{X}, r) \cdot \sum_{i=K+1}^{K+k} \sum_{\ell=1}^d \gamma^{\mathbb{I}_{\mathbb{K}}(i, \ell)} \cdot \widetilde{\text{cf}(h_i)}_{\ell} \in \mathbb{K}[\vec{X}],$$

$$\text{Eval}_{\mathbb{A}}(\vec{X}) := \text{eq}(\vec{X}, r) \cdot \sum_{i=K+1}^{K+k} \sum_{j=1}^t \sum_{\ell=1}^d \gamma^{\mathbb{I}_{\mathbb{A}}(i, j, \ell)} \cdot \widetilde{\text{cf}(h_{i,j})}_{\ell} \in \mathbb{A}[\vec{X}].$$

Define the sum-check polynomial

$$Q(\vec{X}) := \text{Eval}_{\mathbb{K}}(\vec{X}) + \gamma^{kd} \cdot \text{Eval}_{\mathbb{A}}(\vec{X}) + \gamma^{kd(t+1)} \cdot \text{eq}(\vec{X}, \alpha) (\mathbf{F}(\vec{X}) + \gamma^K \cdot \text{NC}(\vec{X})) \in \mathbb{A}[\vec{X}].$$

Define claimed sum of  $Q$  over  $\{0,1\}^{\log m}$  as

$$T := \sum_{i=K+1}^{K+k} \sum_{\ell=1}^d \gamma^{\mathbb{I}_{\mathbb{K}}(i,\ell)} \cdot \mathbf{cf}(y_i)_\ell + \gamma^{kd} \cdot \sum_{i=K+1}^{K+k} \sum_{j=1}^t \sum_{\ell=1}^d \gamma^{\mathbb{I}_{\mathbb{A}}(i,j,\ell)} \cdot \mathbf{cf}(y_{i,j})_\ell \in \mathbb{A}.$$

Perform  $\text{SumCheck}(T; Q)$  (Definition 11) which reduces the claim that

$$T = \sum_{\vec{x} \in \{0,1\}^{\log m}} Q(\vec{x})$$

to a new evaluation claim  $v \stackrel{?}{=} Q(r') \in \mathbb{A}$  for a new evaluation point  $r' \in \mathbb{K}^{\log m}$ .

3.  $\mathcal{P}$ : Send the claimed evaluations

$$\begin{aligned} \forall i \in [K+k], \quad y'_i &\leftarrow \widetilde{h_i}(r') \in \mathbb{R}_{\mathbb{K}}, \\ \forall i \in [K+k], j \in [t], \quad y'_{i,j} &\leftarrow \widetilde{h_{i,j}}(r') \in \mathbb{R}_{\mathbb{A}}. \end{aligned}$$

4.  $\mathcal{V}$ : By Theorem 10, interpret  $\mathbf{ct}(y'_i) \in \mathbb{K}$  and  $\mathbf{ct}(y'_{i,j}) \in \mathbb{A}$  as the claimed evaluations  $\widetilde{z_i^{b,\text{pad}}}(r')$  and  $\widetilde{M_j z_i}(r')$ , respectively, and derive the claimed intermediate evaluations

$$\begin{aligned} F &:= \sum_{i=1}^K \gamma^{i-1} \cdot f(\mathbf{ct}(y'_{i,1}), \dots, \mathbf{ct}(y'_{i,t})) \in \mathbb{A}, \\ N &:= \sum_{i=1}^{K+k} \gamma^{i-1} \cdot \prod_{a=-b+1}^{b-1} (\mathbf{ct}(y'_i) - a) \in \mathbb{K}, \\ E_{\mathbb{K}} &:= \mathbf{eq}(r', r) \cdot \sum_{i=K+1}^{K+k} \sum_{\ell=1}^d \gamma^{\mathbb{I}_{\mathbb{K}}(i,\ell)} \cdot \mathbf{cf}(y'_i)_\ell \in \mathbb{K}, \\ E_{\mathbb{A}} &:= \mathbf{eq}(r', r) \cdot \sum_{i=K+1}^{K+k} \sum_{j=1}^t \sum_{\ell=1}^d \gamma^{\mathbb{I}_{\mathbb{A}}(i,j,\ell)} \cdot \mathbf{cf}(y'_{i,j})_\ell \in \mathbb{A}. \end{aligned}$$

Check the evaluation claim  $v \stackrel{?}{=} Q(r')$  as follows,

$$v \stackrel{?}{=} E_{\mathbb{K}} + \gamma^{kd} \cdot E_{\mathbb{A}} + \gamma^{kd(t+1)} \cdot \mathbf{eq}(r', \alpha) \left( F + \gamma^K \cdot N \right).$$

5. Output  $(\mathbf{s}; c_i, x_i, r', y'_i, \{y'_{i,j}\}_{j \in [t]}; z_i)_{i \in [K+k]}$

**Lemma 7 ( $\Pi_{\text{CCS}}$  is strong).** *The interactive reduction  $\Pi_{\text{CCS}} : \text{CCS}(b, \mathcal{L})^K \times \text{CE}(b, \mathcal{L})^k \rightarrow \text{CE}(b, \mathcal{L})^{K+k}$  ( $\text{CE}(q/2, \mathcal{L})^{K+k}$ ) is strong (Definition 17) for the function  $\phi$ , which projects commitments  $(c_i)_{i \in [K+k]}$  from the instance.*

*Proof.* For brevity, we defer the proof to Appendix B.2. □

## 7.4 Random linear combination reduction – $\Pi_{\text{RLC}}$

The interactive reduction  $\Pi_{\text{RLC}}$  does exactly as the name suggests. Given  $K+k$  input CCS evaluation claims whose flattened witness vectors have norm less than  $b$ , it outputs a single CCS evaluation claim of larger norm bound  $B$ , which is a random linear combination of the input claims using challenges from a strong sampling set  $\mathcal{C}$  (Definition 6). Using the same challenges,  $\Pi_{\text{RLC}}$  combines the commitments, packed inputs and witnesses, evaluations of the flattened witnesses in  $\mathbb{R}_{\mathbb{K}}$ , and relation evaluations in  $\mathbb{R}_{\mathbb{A}}$ .

### Random linear combination reduction $\Pi_{\text{RLC}}$

**Parameters:** Refer to Definition 21.

**Input**  $\in \text{CE}(b, \mathcal{L})^{K+k}$

(**s**;  $c_i \in \mathbb{C}, x_i \in \mathbb{L}^{n_{L,\text{in}}}, r \in \mathbb{K}^{\log m}, y_i \in \mathbb{R}_{\mathbb{K}}, \{y_{i,j} \in \mathbb{R}_{\mathbb{A}}\}_{j \in [t]}, z_i \in \mathbb{L}^{n_L}\}_{i \in [K+k]}$

**Output**  $\in \text{CE}(B, \mathcal{L})$

(**s**;  $c \in \mathbb{C}, x \in \mathbb{L}^{n_{L,\text{in}}}, r \in \mathbb{K}^{\log m}, y \in \mathbb{R}_{\mathbb{K}}, \{y_j \in \mathbb{R}_{\mathbb{A}}\}_{j \in [t]}, z \in \mathbb{L}^{n_L}$ )

**Setup**  $\mathcal{G}(1^\lambda, n_R) \rightarrow \text{pp}$ : Output  $\text{pp} \leftarrow \text{Setup}(1^\lambda, n_R)$ .

**Encoder**  $\mathcal{K}(\text{pp}, \mathbf{s}) \rightarrow (\text{pk}, \text{vk})$ : Output  $((\text{pp}, \mathbf{s}), \perp)$ .

**Reduction**  $\langle \mathcal{P}, \mathcal{V} \rangle((\text{pk}, \text{vk}), u_1, w_1) \rightarrow (u_2; w_2)$ : Recall from Definition 20 the matrix  $\text{Pad} \in \mathbb{F}^{m \times n_F}$ . For every  $i \in [K+k]$ , define

$$\begin{aligned} z_i^b &:= \text{Flat}_{\mathbb{L}}(z_i), \\ z_i^{b, \text{pad}} &:= \text{Pad} z_i^b, \\ \mathbf{x}_i &:= \text{Pack}_{\mathbb{L}}(x_i), \\ \mathbf{z}_i &:= \text{Pack}_{\mathbb{L}}(z_i) = \text{Pack}_{\mathbb{F}}(z_i^b), \\ h_i &:= \text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad})) \cdot \mathbf{z}_i. \end{aligned}$$

For every  $i \in [K+k]$  and  $j \in [t]$ , define

$$h_{i,j} := \text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j)) \cdot \mathbf{z}_i.$$

1.  $\mathcal{V}$ : Sample  $\rho_1, \dots, \rho_{K+k} \xleftarrow{\$} \mathcal{C}$  and compute:

$$\begin{aligned} c &\leftarrow \sum_{i \in [K+k]} \rho_i c_i, & \mathbf{x} &\leftarrow \sum_{i \in [K+k]} \rho_i \mathbf{x}_i, & x &\leftarrow \text{Pack}_{\mathbb{L}}^{-1}(\mathbf{x}), \\ y &\leftarrow \sum_{i \in [K+k]} \rho_i y_i, & \forall j \in [t], y_j &\leftarrow \sum_{i \in [K+k]} \rho_i y_{i,j}. \end{aligned}$$

Send  $\rho_1, \dots, \rho_{K+k}$  to  $\mathcal{P}$ .

2.  $\mathcal{P}$ : Compute

$$\mathbf{z} \leftarrow \sum_{i \in [K+k]} \rho_i \mathbf{z}_i, \quad z \leftarrow \text{Pack}_{\mathbb{L}}^{-1}(\mathbf{z}).$$

3. Output (**s**;  $c, x, r, y, \{y_j\}_{j \in [t]}, z$ ).

**Lemma 8 ( $\Pi_{\text{RLC}}$  is weak).** *The interactive reduction  $\Pi_{\text{RLC}} : \text{CE}(b, \mathcal{L})^{K+k} (\text{CE}(q/2, \mathcal{L})^{K+k}) \rightarrow \text{CE}(B, \mathcal{L})$  is weak (Definition 16) for the function  $\phi$ , which projects commitments  $(c_i)_{i \in [K+k]}$  from the instance.*

*Proof.* For brevity, we defer the proof to Appendix B.3.  $\square$

## 7.5 Decomposition reduction – $\Pi_{\text{DEC}}$

Inspired by folklore techniques [12, 15, 72], our final reduction aims to reduce the norm of the flattened witness vector from  $B = b^k$  to  $b$ , which will allow us to continually fold CCS claims without increasing the norms of the flattened representations  $z_i^b$  of the openings  $(z_i)_i$  to the commitments. The prover applies the signed base  $b$  decomposition (Definition 1) to  $z^b$  to obtain lower norm vectors  $z_1^b, \dots, z_k^b$ , and recovers the corresponding native vectors  $z_i := \text{Flat}_{\mathbb{L}}^{-1}(z_i^b)$ . The prover then sends commitments, evaluations of the flattened witnesses in  $\mathbb{R}_{\mathbb{K}}$ , and relation evaluations in  $\mathbb{R}_{\mathbb{A}}$ . The verifier checks that the commitments and both evaluation families recombine to the original claim.

### Decomposition reduction $\Pi_{\text{DEC}}$

**Parameters:** Refer to Definition 21.

**Input**  $\in \text{CE}(B, \mathcal{L})$

(**s**;  $c \in \mathbb{C}, x \in \mathbb{L}^{n_{L,\text{in}}}, r \in \mathbb{K}^{\log m}, y \in \mathbb{R}_{\mathbb{K}}, \{y_j \in \mathbb{R}_{\mathbb{A}}\}_{j \in [t]}; z \in \mathbb{L}^{n_L}$ )

**Output**  $\in \text{CE}(b, \mathcal{L})^k$

(**s**;  $c_i \in \mathbb{C}, x_i \in \mathbb{L}^{n_{L,\text{in}}}, r \in \mathbb{K}^{\log m}, y_i \in \mathbb{R}_{\mathbb{K}}, \{y_{i,j} \in \mathbb{R}_{\mathbb{A}}\}_{j \in [t]}; z_i \in \mathbb{L}^{n_L}\}_{i \in [k]}$

**Setup**  $\mathcal{G}(1^\lambda, n_R) \rightarrow \text{pp}$ : Output  $\text{pp} \leftarrow \text{Setup}(1^\lambda, n_R)$ .

**Encoder**  $\mathcal{K}(\text{pp}, \mathbf{s}) \rightarrow (\text{pk}, \text{vk})$ : Output  $((\text{pp}, \mathbf{s}), \perp)$ .

**Reduction**  $\langle \mathcal{P}, \mathcal{V} \rangle((\text{pk}, \text{vk}), u_1, w_1) \rightarrow (u_2; w_2)$ :

1.  $\mathcal{P}$ : Compute  $(c_i, y_i, \{y_{i,j}\}_{j \in [t]}; z_i)_{i \in [k]}$  as follows. Recall from Definition 20 the matrix  $\text{Pad} \in \mathbb{F}^{m \times n_{\mathbb{F}}}$ . First, compute

$$z^b \leftarrow \text{Flat}_{\mathbb{L}}(z), \quad (z_1^b, \dots, z_k^b) \leftarrow \text{split}_b(z^b).$$

For every  $i \in [k]$ , compute

$$\begin{aligned} z_i &\leftarrow \text{Flat}_{\mathbb{L}}^{-1}(z_i^b), \\ \mathbf{z}_i &\leftarrow \text{Pack}_{\mathbb{L}}(z_i) = \text{Pack}_{\mathbb{F}}(z_i^b), \\ h_i &\leftarrow \text{Emb}_{\mathbb{F}}(\text{Trans}_{\mathbb{F}}(\text{Pad})) \cdot \mathbf{z}_i, \\ c_i &\leftarrow \mathcal{L}(\mathbf{z}_i), \\ y_i &\leftarrow \widetilde{h}_i(r), \\ \forall j \in [t], \quad h_{i,j} &\leftarrow \text{Emb}_{\mathbb{L}}(\text{Trans}_{\mathbb{L}}(M_j)) \cdot \mathbf{z}_i, \\ \forall j \in [t], \quad y_{i,j} &\leftarrow \widetilde{h}_{i,j}(r). \end{aligned}$$

Send  $(c_i, y_i, \{y_{i,j}\}_{j \in [t]})_{i \in [k]}$  to  $\mathcal{V}$ .

2.  $\mathcal{V}$ : Compute  $x^b \leftarrow \text{Flat}_{\mathbb{L}}(x)$ . If  $\|x^b\|_{\infty} \geq B$ , output  $\perp$ . Compute

$$(x_1^b, \dots, x_k^b) \leftarrow \text{split}_b(x^b), \quad x_i \leftarrow \text{Flat}_{\mathbb{L}}^{-1}(x_i^b) \quad \text{for every } i \in [k].$$

Check the following equations,

$$c \stackrel{?}{=} \sum_{i \in [k]} b^{i-1} \cdot c_i, \quad y \stackrel{?}{=} \sum_{i \in [k]} b^{i-1} \cdot y_i, \quad \forall j \in [t], \quad y_j \stackrel{?}{=} \sum_{i \in [k]} b^{i-1} \cdot y_{i,j}.$$

where  $b$  is treated as a constant element of  $\mathbb{R}_{\mathbb{F}} \subseteq \mathbb{R}_{\mathbb{K}}, \mathbb{R}_{\mathbb{A}}$ . If any check fails, the verifier outputs  $\perp$ .

3. Output (**s**;  $c_i, x_i, r, y_i, \{y_{i,j}\}_{j \in [t]}; z_i)_{i \in [k]}$

**Theorem 13.**  $\Pi_{\text{DEC}} : \text{CE}(B, \mathcal{L}) \rightarrow \text{CE}(b, \mathcal{L})^k$  is a *reduction of knowledge* (Definition 9).

*Proof.* For brevity, we defer the proof to Appendix B.4. □
