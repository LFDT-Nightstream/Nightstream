# Comparison-decoder totalization analysis

Worker 3 (`/root/conformance_review`), 2026-09-10. This is bounded analysis
of a possible comparison verifier. It changes no actual verifier, transcript,
profile or model and asserts no CO25 applicability or approval. No build or
protocol execution was run.

## What totalization would establish

Let `D : FieldWindow -> Option Scalar` be the existing `fieldDecode`, and
fix any typed valid scalar `s0`. Define only for the comparison:

```text
T(some s) = s
T(none)   = s0
Dtotal(f) = T(D(f)).
```

For an event `E : Scalar -> Prop`, apply the existing scalar Option event
bound to `fun value => E(T(value))`. Since `T(some s)=s`, the right side is
exactly the uniform distribution on Scalar. The same error
`epsilon = 32*pairDeviation + choose(64,11)/65536^11` is retained.
No target mass is assigned to an additional failure symbol, and no
`1/(5^54+1)` term is needed.

The generic `BatchOutputLaw.independent_batch_event_error_le` can then be
applied to `Dtotal` and the identity on Scalar. For 17 independent windows,
the error is at most `17*epsilon = 544*pairDeviation + 17*u`.

There are two distinct constructions on failed inputs:

- totalize the whole `Option (List Scalar)` to one fixed complete list;
- totalize each scalar, retain the other scalar outputs, and collect them.

The existing Option-batch theorem pushes forward directly to the first.
The second follows from the scalar pushforward plus the generic product
theorem. They agree on all-success inputs but have different failed-output
fibers. A proof must name one construction consistently.

The exact existing inputs are `SamplerOutputLaw.fieldDecode`,
`field_output_event_error_le`, and the generic/selected batch laws reviewed
in `/tmp/nightstream-nifs-batch-consumer-review.md`. The pushforward lemmas
and totalized comparison verifier are not yet implemented or proved.

## Acceptance and knowledge inclusion

The needed deterministic statement is:

```text
forall statement proof permutation,
  AcceptActual(statement, proof, permutation) ->
  AcceptComparison(statement, proof, permutation).
```

It must retain the same statement, proof parser, public messages, challenge
values on successful samples, full transcript states, and remaining verifier
gates. Actual acceptance must first imply that every relevant bounded sample
succeeded. The existing `sampleBatch_output_state_eq_fieldDecodeBatch`
provides the ordered output and successful-state link for this step.

An early actual abort is not an obstacle to one-way acceptance inclusion:
that run is not in the antecedent. It is an obstacle to asserting complete
trace or query-count equality. An eager totalized comparison must continue
through the exact fixed block schedule, including scalar domain separators,
and must count its additional work on failed inputs. It must not skip unread
blocks or reuse a stale state after inserting the default scalar.

Once knowledge soundness is established for that exact comparison verifier
on the same relation and oracle experiment, using its extractor gives the
event inclusion
`ActualAccept and invalidExtractedWitness` contained in
`ComparisonAccept and invalidExtractedWitness`, on paired extractor tapes.
This is an unconditional bad-event inclusion, not a statement about
extraction probabilities conditioned on the two different acceptance events.
CO25 Definition 3.7 uses an upper bound on prover failure probability. Since
comparison acceptance includes actual acceptance, the actual failure bound
also serves as a comparison failure bound; a new monotonicity assumption is
not needed for this use of Definitions 3.7–3.8.

## Requirements that remain

The primary paper is the 2026-03-27 revision retained at
[/tmp/nightstream-chiesa-orru-2025-536.txt](/tmp/nightstream-chiesa-orru-2025-536.txt).
Its SHA-256 is `66d1cdd23bf6f18f5f93b08aabe6d0339ef79c0f3b58cfddc980966bd57903e7`.

1. Definition 4.1 (line 1561) requires fixed maps
   `psi_i : Sigma^(ellV(i)) -> MV_i`, compared with uniform `MV_i`.
   Totalization can supply this output type, but not the missing match of
   the actual call schedule to one such fixed squeeze/decoder. The decoder
   must not invoke a hidden permutation or depend on an unrepresented state.
   The 17 scalar sources contain intervening `[4,index]` absorbs. They cannot
   be replaced by one uninterrupted squeeze without a schedule proof.
   Splitting a batch into additional fixed-message IP rounds would also
   require an explicit protocol/game equivalence, not just a codec assertion.
2. Construction 4.3 (line 1578), the additive-to-overwrite translation,
   cursor timing and shared-hash initialization remain unmatched. Default
   decoding does not repair the prefix/permutation-dependent encoder issue
   or Claim 5.23's fixed injective relabeling requirement (line 3082).
3. D2SAlgo samples `psi_i^-1` in line 2077. Surjectivity and an efficient
   uniform conditional-preimage sampler must be proved. A constructive
   successful input for each Scalar appears possible by using its symbols
   as accepted low/high chunks, but that is not a uniform-fiber sampler.
   At `s0`, the totalized fiber is the disjoint union of its successful fiber
   and all shortfall inputs. The sampler must use their correct relative
   cardinalities. Sampling only the old successful fiber is wrong. Ignored
   raw lanes and full successor states must also be retained in the coupling.
4. The existing Claim 5.22 issue remains (lines 2990–3066). Uniform output
   followed by uniform fiber sampling is not uniform raw input for unequal
   fibers. Totalization enlarges the default fiber and does not make them
   equal. The correct identity is that this raw-input statistical distance
   equals the decoder's output bias; the claimed zero requires balanced
   fibers. A joint raw-output/decoded-output coupling can avoid counting two
   independent errors, but that repair and its cache consistency need proof.
5. Theorem 6.2 (line 3389) still needs state-restoration knowledge for the
   exact underlying IP, plus actual query, preimage-sampling and simulation
   work bounds. Acceptance inclusion does not provide that premise or the
   witness-bearing NIFS event map. The prior state-restoration analysis and
   all encoder/cache/initialization obligations remain in force.

The paper's scope is classical; Section 1.3 (line 303) leaves superposition
queries open. The finite totalization argument provides no QROM or concrete
Poseidon2 security transfer. The proposal is mathematically compatible with
the existing event bounds, but it closes only the challenge-output-domain
issue until these other requirements are proved.

## Later source review: finite totalized laws

Worker 3 independently reviewed the complete frozen
`Lifecycle/PiRLC/v1_1/SamplerTotalizedOutputLaw.lean` (144 lines), SHA-256
`34bc2b7861aa8a09867185d3a08aefcc03f2927d06c01c6a9351caee797dfdc9`.
No defect was found in its three exported claims. This update supersedes
the earlier absence of the scalar/batch pushforward lemmas and successful
list agreement. It does not supply a totalized FS verifier or the remaining
requirements listed above.

`totalizedFieldDecode` at line 17 is exactly the existing scalar Option
decoder followed by `getD fallback`. The fallback is a typed `Scalar`,
fixed outside each finite experiment. `totalizedFieldBatch` at line 21
applies that function separately at each coordinate. It retains successful
coordinates even when another coordinate fails. It is not whole-batch
replacement, and the theorems do not cover a fallback that changes with the
sampled field input.

`scalar_event_error_le` at line 27 precomposes an event with this Option
map. Its target is uniform Scalar with denominator `5^54`, and its field
source has denominator `q^32`. All failures remain in the left input count
and now contribute to the fallback's output event.

`batch_event_error_le` at line 39 applies the generic independent product
law to the scalarwise decoder and the identity on Scalar. It proves both
positive normalizations and retains the exact denominators `(q^32)^17`
and `(5^54)^17`. Algebraic expansion gives `544*pairDeviation + 17*u`.
The target is the uniform ordered function `Fin 17 -> Scalar`; no failure
symbol or new cardinality term is added.

`sampleBatch_success_ring_list_eq` at line 124 requires the actual
`sampleBatch initial count = some batch`. The list traversal proof excludes
a failed head or tail under that premise and preserves each source index.
It concludes equality of the actual ordered ring list with the embedded
totalized field-decoder list. This theorem proves no new final-state
equality, failed-trace equality or complete verifier acceptance inclusion.
The earlier successful-state theorem remains a separate available input.

The retained `/tmp/nightstream-nifs-totalized-sampler-output-1.log` was read
in full: focused build passed, module 1.4s, bounded command 2s, terminal exit
zero; only replayed linter warnings. Its SHA-256 is
`4fd33851f8c55d6c4bdb555eb21625114c48a92428fe8347972f5dc154a9a3e7`.
No build or active edit was performed by this reviewer. A final combined
audit for these additions was not yet supplied. Actual abort rejection,
the transcript and the selected profile are unchanged.
