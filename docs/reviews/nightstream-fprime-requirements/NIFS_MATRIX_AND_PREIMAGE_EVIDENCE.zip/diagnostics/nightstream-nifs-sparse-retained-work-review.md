# Sparse and retained work: scoped source review

Reviewer: Worker 2, `/root/fiat_shamir_model`, 2026-09-10.
No Lean, Rust, generator, or backend command ran. The reviewer did not edit
either owner. The coordinator applied the corrections below.

Reviewed corrected sources in `/home/nicoarq/develop/Nightstream-nifs-proof-links`:

| Owner below `formal/nightstream-fprime/NightstreamFPrime/Export/MatrixProgram/` | SHA-256 |
|---|---|
| `SparseWork.lean` | `f0fb6484581a5844c45c8d0db1b4b4519691661cdf8433c4db8dcedf3be8ed09` |
| `RetainedWork.lean` | `f0e0f0835f0c782d4509b152f40b2c3af776f9d35cedbea273697956712c0d9d` |

These hashes identify reviewed bytes. They are not protocol authority.
The corrected sources are frozen for the coordinator's build queue. This
note does not claim a successful build or combined axiom audit.

## Accepted work convention

These are named source-operation clocks. Value reads, calls, arithmetic,
dispatch, branches, and value constructors have the charges listed below.
Clock arithmetic and clock-field reads are instrumentation and are excluded.
Local variable references and erased proof terms have no separate charge.
The field operations act on fixed Goldilocks values. These clocks do not
prove bit complexity, generated machine instructions, allocation behavior,
or machine runtime.

Unit construction is charged at the `SparseWork.empty ()` call. Nat successor
destruction charges dispatch and predecessor extraction separately. The
retained scale constant is now the explicit canonical field value
`(⟨3, by decide⟩ : F)`, so its charge is a field constructor; no uncharged
`fieldOfNat` call or modulo operation remains. Width evaluation charges both
the `Kind.width` call and its dispatch.

## Sparse forms

No value, order, or duplicate-handling defect was found. Empty and singleton
return the existing forms. Add copies the left list through two reverse
passes and supplies the right list as the suffix. Scale maps all stored
entries and restores their order with a final reverse. Coefficient lookup
visits every stored entry and adds every matching coefficient in list order,
including repeated columns. Zero coefficients are retained. The size axis
is entry-list length, not distinct-column count.

| Operation | Named charge and resulting clock |
|---|---|
| `reverseOnto` step | dispatch, head read, tail read, cons, recursive call: 5 |
| `reverseOnto` base | dispatch and Result constructor: 2 |
| empty | nil, SparseForm, Result constructors: 3 |
| singleton | SparseEntry, nil, cons, SparseForm, Result constructors: 5 |
| add wrapper | two form-entry reads, nil, two calls, two result-value reads, SparseForm and Result: 9 |
| add total | `10*left.entries.length+13` |
| scale step | dispatch, head/tail reads, two entry-field reads, multiplication, entry/cons constructors, call: 9 |
| scale base outside reverse | dispatch, nil, reverse call, value read, Result: 5 |
| scale wrapper | form-entry read, nil, call, value read, SparseForm and Result: 6 |
| scale total | `14*form.entries.length+13` |
| coefficient miss | dispatch, head/tail reads, entry-column and Fin-value reads, comparison, branch, call: 8 |
| coefficient hit | miss charge plus coefficient read and field addition: 10 |
| coefficient base | dispatch and Result: 2 |
| coefficient wrapper | wanted-value read, form-entry read, field-zero constructor, call, value read, Result: 6 |
| coefficient total | at most `10*form.entries.length+8` |

The necessary correction was the scale constant: its base overhead changed
from 2 to 5 and its wrapper from 5 to 6. This changes `14*n+9` to `14*n+13`.
The per-entry charge and value semantics stay the same.

## Retained coordinates and wrapper

The coordinate loop emits exactly the existing reconstruction form with
entries in ascending coordinate order and weights `1,3,3^2,...`. It does not
generate the whole retained block. Each recursive step scales the already
constructed tail and adds a singleton head. The quadratic work bound counts
those actual tail traversals.

The coordinate base has five operations outside `SparseWork.empty`:
dispatch, Unit construction, call, result-value read, and Result construction.
Together with empty's three operations, `T(0)=8`.

The coordinate step has fifteen operations outside the called clocks:
dispatch and predecessor extraction (2), start increment (1), four calls
(coordinates, singleton, scale, add), bounded-column and field-one/three
constructors (3), four result-value reads (tail, head, scaled, joined), and
Result construction (1). There is no charge for a clock-field read.

The head has one entry. With a tail of length `n`, its callees contribute
`T(n)+5+(14*n+13)+23`. Therefore

```text
T(n+1) = T(n) + 14*n + 56
T(n)   = 7*n^2 + 49*n + 8.
```

The wrapper caches slot count, width, and start. It checks the complete block
geometry before constructing the requested slot, as the existing form does.
Its branch costs are:

| Executed portion | Charge |
|---|---:|
| slot-count read, comparison, branch | 3 |
| kind read, width call, kind dispatch | 3 |
| start read | 1 |
| geometry multiplication, addition, comparison, branch | 4 |
| successful slot multiplication and addition | 2 |
| coordinate call and result-value read | 2 |
| Some/Result or None/Result constructors | 2 |

Thus success adds 17 to `T(width)`, geometry failure costs 13, and slot failure
costs 5. The complete bound is `7*width^2+49*width+25`. The original proposed
17/12/5 mixed separate width-call/dispatch counting with a grouped charge;
the accepted 17/13/5 uses the same rule in all branches.

## Acceptance limits

The exact value theorems relate these counted implementations to existing
`SparseForm` and `RetainedBlock.form?` semantics. They do not, by themselves,
give work bounds to existing interpreters that still call the original
uncounted definitions. A consumer must call these operations or prove a
separate cost refinement. Source generation, block selection, substitutions,
wire decoding, full matrix construction, and backend work are outside this
review. No additional gap was found within the corrected local contract.

The September 4 PiCCS external review and August 28 v2 review concern older
cuts and broader authority/conformance claims. They supply no current local
defect in these list operations; their production and security obligations
remain with the coordinator. The named Fable review is absent.
