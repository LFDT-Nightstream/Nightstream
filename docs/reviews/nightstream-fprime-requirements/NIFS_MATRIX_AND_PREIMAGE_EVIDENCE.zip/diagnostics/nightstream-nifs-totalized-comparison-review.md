# Totalized comparison verifier source review

Root review, 2026-09-10. Source SHA-256 383a1ac3cedcc4bb99940b318689b491049b17e90846c75d0f9f7a4349522c54. Round3 is pending.

The complete Batch contains all ordered ring challenges and the final sampler state. Its construction applies the existing fallback separately to each scalar and uses stateAt for the complete schedule. The success lemma combines the existing complete ring-list equality with the exact successful final-state theorem, without assuming anything about the initial state.

The private symbolic record update changes only piRlcResponse and its membership proof. Other key fields remain identical. The C execution/check, parent combination function, and PiDEC attempt function use unchanged owners. Once responses agree at the C outgoing state, Option.map congruence gives the same parent, PiDEC attempt, decision, and full output. The selected theorem uses actual sampleBatch success for that response equality. The final theorem splits on the actual complete sampleBatch. Shortfall contradicts acceptance through the existing verify_eq_none_of_piRlcFailure theorem. On success it returns the identical Running output and the complete batch equality. No child-message honesty hypothesis is introduced.

No mathematical scope defect found. This comparison-only noncomputable key is not installed in production. It is not Rust conformance, a probability distribution for actual Poseidon2, a failed-trace equivalence, a cost law, or an adaptive/state-restoration Fiat-Shamir theorem. It establishes the needed deterministic acceptance inclusion only after the full Lean check and axiom audit pass.
