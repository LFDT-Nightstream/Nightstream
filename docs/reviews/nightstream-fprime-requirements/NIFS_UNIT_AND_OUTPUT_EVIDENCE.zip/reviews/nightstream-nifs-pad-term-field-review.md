# Independent stored-primitive and finite-law review

Reviewer: Worker 3 (`/root/conformance_review`), independent of the authors
of the new Pad, term-storage, FieldOutputLaw, RingFPolynomial and
StoredRingInverseUnit changes. Date: 2026-09-10.

This record retains the completed source reviews from this continuation.
It adds no checks. Review used the frozen source contents identified below,
existing source definitions and the build logs explicitly named here.
No active source was edited, and this reviewer ran no build, test, prover,
backend or PaperExact execution. The review does not extend the original
immutable-cut conformance finding for `773f3d0f` to these later files.

## Reviewed source identities

Paths in this table are relative to
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/`.

| Source | SHA256 |
|---|---|
| `Spec/Folding/PiCCS/PaperJoint/StoredWitnessCheckEntries.lean` | `b314be8e9a80db5db9ae8eb62f7a9f098eaa76ba3eb74af80d0779c305791f02` |
| `Export/Stage1/PiCCSStoredWitnessCheck.lean` | `9b1faca717b3d9d0d61c46d88656ca60068298f94f54ae0fb82ea79804d89430` |
| `Spec/ProductionRelation/SelectivePolynomial.lean` | `c559ef308489964f477093c32711f1ce372d82c5636c75202b9ea22ef6122c03` |
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldOutputLaw.lean` | `554ee35b6e4acefc2b6706c35c98fa1a30eaff5cba81645145e3ff06a8127bbf` |
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldBatchShortfall.lean` | `861adca1519c469fd45cb49288729d46c94f34dedfd7afaf3116d43c0021f84d` |
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldShortfall.lean` | `56ec23f6f5e552a52e85efd9a0ad693fa527f8561b6c0ebd1cccb6da5cc6a07e` |
| `Spec/Phi81Relation/EvaluationHomomorphism/RingFPolynomial.lean` | `abe9f33d40b210a06a7fb5972470b20d727b1bc29c86c8a3ac98075cc5b57549` |
| `Spec/Phi81Relation/EvaluationHomomorphism/StoredRingInverseUnit.lean` | `1a27072f06cab1cf79d939ec2e3d95fe7a391f20db0510994a376d508c8bc622` |
| `Spec/Phi81Relation/EvaluationHomomorphism/StoredRingInverse.lean` — unchanged algorithm boundary | `9da9fca9ed9388cbd9be6b5991e8c4f5932c66a1ea46bbadd034d7f394cb4f62` |
| `Spec/Phi81Relation/EvaluationHomomorphism/StoredRingInverseCorrect.lean` — unchanged proof dependency; authorship limit below | `33c1ae55b640e408227ac813bf3f2f8ac7552e12de815fcb03a0942dc4d8ba15` |

No defect was found in the stated source claims. This finding has the
specific limits below; it is not final acceptance of the whole extractor.

## Canonical Pad execution and selected checker

[StoredWitnessCheckEntries](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Folding/PiCCS/PaperJoint/StoredWitnessCheckEntries.lean)
computes the selected native-bar branches, fixed Phi81 convolution weights,
Boolean vertex index and canonical Pad entries. It does not call a supplied
matrix or kernel function to compute Pad. Its value lemmas reach the
existing `Phi81CoefficientKernel.phi81Kernel.weight` and
`Phi81MatrixSource.source.coefficientMatrixOf` definitions.

The operation counts were checked against the executed branches:

- `nativeBarEntry` charges both index reads, each comparison and branch,
  subtraction or negation on its path, and its return. Its bound is 14.
- Each raw convolution sum uses direct numeric term indices. The recursion
  is over the fixed 54 coefficients. The raw-term bound includes the native
  bar call and monomial call; it does not assign constant cost to an
  arbitrary semantic function.
- `kernelWeight` charges the same low, folded and possible second-fold
  contributions as `ringFMul`, plus its degree arithmetic and branches.
- `vertexIndex` charges the traversal of the supplied Boolean vertex.
  `padEntry` charges the column read, quotient/remainder, index constructor,
  54-lane traversal and return. Only a matching live Pad position invokes
  the kernel; the upper bound conservatively permits it at every lane.

[padEntry_value](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Folding/PiCCS/PaperJoint/StoredWitnessCheckEntries.lean:277)
uses the canonical padded identity at every typed vertex and column. Its
coverage premise is the actual carrier/cube coverage. The semantic matrix
family remains present in the theorem, but the Pad computation does not
read it. Pad remains separate from the 14 CCS matrix families.

The selected
[checker adapter](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PiCCSStoredWitnessCheck.lean:227)
connects that value to the statement selected by the existing production
key. `scalarProgram` installs the computed Pad entry and its proved bound.
`scalar_finish_source_iff` and `scalar_check_work_le` quantify over all typed
probes, stored witnesses and outcomes, including rejected candidates. They
do not require an honest probe or assume opening validity.

Three universal value/work contracts remain explicit: the public check,
commitment check (including the selected key work), and CCS matrix entry.
The new Pad implementation removes only its own former premise. These are
counts of named operations, not measured wall time or a compiler-runtime
theorem. Full witness checking and source extraction remain conditional on
the other stated contracts.

## Stored selective polynomial terms

[SelectivePolynomial](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/ProductionRelation/SelectivePolynomial.lean:100)
now retains each coefficient with its named `PortExponents` record before
erasing it to the existing function-valued monomial. The fixed table has
74 terms. The matrix order still has 13 meaningful ports and a final zero
port; Pad is separate. The polynomial degree bound remains nine.

The review compared the six former literal term lists at `HEAD=4b4a8ddf`
with the new data lists after normalizing only constructor names and
whitespace. All six comparisons matched. Thus all 74 coefficients,
exponent arguments and term positions are preserved, not merely the count.
[termData_toMonomial](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/ProductionRelation/SelectivePolynomial.lean:317)
also proves that erasing the new table gives the current semantic terms.

The observed `RowSemantics` and `CcsTerminal` diffs add unfolding names for
this representation change; they do not add a new relation predicate.
This review did not generate a package or compare emitted relation bytes.
The term-storage change alone supplies no work theorem for a public gate.

## Field output law and its finite domains

[FieldOutputLaw](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldOutputLaw.lean:219)
compares two explicit uniform spaces:

- `FieldWindow = Fin 32 -> F`, with cardinality and denominator `q^32`;
- `ShortfallBound.Window = Fin 64 -> Chunk`, with cardinality and denominator
  `65536^64`.

The proof uses `PairWindow = Fin 32 -> Fin (2^32)` as an equivalent encoding
of the second space. It preserves low/high order and the dependence between
the two 16-bit candidates obtained from one uniform field lane.

The existing lane bijection swaps a complete residue block with an auxiliary
pair. The new `FieldShortfall.lane_coupling_disagrees_iff` identifies the exact
exception: the field value is `q-1` and the auxiliary residue is nonzero.
There are `2^32-1` such joint inputs in one lane. The 32-coordinate finite
union bound therefore gives

```
32 * pairDeviation = 32 * (2^32-1) / (q * 2^32).
```

The general event proof uses both containment directions to bound the
absolute frequency difference. `decoded_event_frequency_error_le` permits
any deterministic decoder and any event on its output. The specialization
`boundedSample_event_frequency_error_le` uses the actual bounded 54-of-64
coefficient decoder and retains `Option.none`. It does not condition away
abort or assume independent candidates within a field lane.

The new `FieldBatchShortfall` dependency was also reviewed. It counts the
union of scalar abort events in the explicit product space of 17 field
windows, hence 544 field coordinates. Its bound follows from a finite
injection and the scalar bound. It does not require an exact formula for
successful batches. No field-sized enumeration or probability axiom is used.

These are finite comparison laws. They neither prove uniform successful
field-decoded scalars nor assign a distribution to actual Poseidon2 replay,
adaptive oracle queries or rewound calls. They supply no Fiat–Shamir model
or query/work bound. `BitOutputLaw` and the final public gate are expressly
outside this retained review and await a later frozen-source review.

## RingF polynomial and stored inverse value bridges

[RingFPolynomial](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Phi81Relation/EvaluationHomomorphism/RingFPolynomial.lean)
maps all 54 coefficients to a polynomial and proves both the coefficient
identity and injection. Coefficients outside that range are zero. Its
quotient is exactly by `X^54+(X^27+1)`. The relation `root^81=1` follows from
the polynomial factor identity; no irreducibility or field assumption is
made about the quotient.

The two finite linear lifts use the existing basis-multiplication and
scale/add laws for the executed `ringFMul`. Applying `modByMonicHom`, with
monicity and degree below 54, proves `toPolynomial_ringFMul_mod`. The
quotient and polynomial views are proof-only. This file defines no new
protocol operation or executable inverse. The reviewed file has six public
theorems. The focused pass was read in
[/tmp/nightstream-nifs-ring-multiplication-2.log](/tmp/nightstream-nifs-ring-multiplication-2.log):
1.9 seconds for the module, two seconds for the command.

[StoredRingInverseUnit](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Phi81Relation/EvaluationHomomorphism/StoredRingInverseUnit.lean:63)
uses the existing selected scalar ring's `UnitWitness` only in theorem
arguments. `coprime_of_unit` derives polynomial coprimality from its inverse
equation. `candidate_view` uses every coefficient and the candidate degree
bound, so vector extraction discards no nonzero high coefficient.
`candidate_mul_value` applies the exact RingF multiplication bridge and the
same normalized-GCD candidate. `candidate_eq_unitInverse` then proves inverse
uniqueness with the existing `ringFMul` associativity and unit laws.

The executable `StoredRingInverse` source remains byte-identical at the hash
above. It computes normalized CompPoly xgcd, takes the first cofactor,
reduces it by the monic Phi81 polynomial, and copies its coefficients after
an explicit candidate-polynomial hoist. A supplied inverse never enters
that program. CompPoly remains pinned to
`050f0bc7e9780703beb8d178ec533e52bd87d649`; no upstream change is part of this review.

Authorship limit: this reviewer wrote `StoredRingInverseCorrect` in an
earlier proof task. It is an unchanged dependency here, not a new independent
review by its own author. Worker 1's earlier independent review of that
module is recorded separately in the existing conformance artifact. The
new independently reviewed claim here is the root-authored RingF/unit
bridge and its use of that dependency.

The focused unit build pass was read in
[/tmp/nightstream-nifs-stored-inverse-unit-3.log](/tmp/nightstream-nifs-stored-inverse-unit-3.log):
4.3 seconds for the module, seven seconds for the command. The log records
a coordinator queue error: this command briefly overlapped the first
FieldBatchShortfall check. Its timing is not serial performance evidence.
The final combined validation must run alone.

The stored candidate's value on unit inputs is established by these source
theorems. A costed B.3 primitive, conversion between semantic RingF functions
and stored arrays, and the complete inverse work bound remain open. The
derived CompPoly cost plan remains a separate handoff; outer fuel at most
54 alone is not a runtime proof.

## Validation and acceptance limits

The new audit entries were present when inspected. This record does not
claim that the final combined gate passed. It does not approve a changed
security model, protocol, hash, profile, backend or publication. It also does
not establish whole-extractor runtime, emitted-byte identity, concrete
Fiat–Shamir security or final Stage 1 closure.

The separate bounded FS analysis is retained in
[/tmp/nightstream-nifs-co25-additive-review.md](/tmp/nightstream-nifs-co25-additive-review.md).
