import NightstreamFPrime.Spec.ProductionRelation.SelectivePolynomial
import Lean.Data.Json

private def dump (_ : Unit) : IO Unit := do
  let values := NightstreamFPrime.Spec.ProductionRelation.SelectivePolynomial.terms.map
    fun term => (term.coefficient.val, List.ofFn term.exponents)
  IO.println ("SELECTIVE_TERMS=" ++ (Lean.toJson values).compress)

#eval dump ()
