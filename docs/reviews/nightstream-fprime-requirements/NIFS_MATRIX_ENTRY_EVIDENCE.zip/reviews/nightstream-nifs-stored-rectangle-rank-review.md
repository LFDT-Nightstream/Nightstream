# Independent local rectangle rank counter review

Reviewer: Worker 3, `/root/conformance_review`.
Reviewed draft: `/tmp/nightstream-nifs-global-inverse/StoredRectangleRank.lean`.
323 lines, 14450 bytes, SHA-256
`d48ba45582eec9cfe5c4a49b26754a9d3915467ba775c52c8cefa47f195d412f`.
The author requested this bounded review while preparing the complete global
inverse criterion. No active file was changed and no separate build was run.

Result: no defect found in the stated local value domain or named-operation
counts. This is a pre-build source review, not a passing full criterion.

classSize costs three: tag dispatch, returned literal/constant, and Result.
classUnrank's residue branch costs nine: dispatch, residue payload read,
index.val and digit.val, alphabet literal, multiply/add, Chunk/Result.
Reject costs four (dispatch, rejection literal, Chunk/Result); accepted costs
four (dispatch, index.val, Chunk/Result); all costs two (dispatch, Result).
classRank costs at most five; its residue payload is ignored and requires no
payload read. The residue branch has dispatch, chunk.val, alphabet literal,
division, and Result. The other branch counts are three.

unrank has twelve local operations before its common/extra branch: two
classSize calls, two value projections, area multiplication, pairModulus and
one literals/subtraction, common multiplication, rank.val, comparison, branch.
The common branch adds four divisions/remainders; two Fin constructors and
two classUnrank calls; two value projections; five word-packing operations
(two Fin reads, chunkModulus literal, multiply/add); three block-combination
operations (pairModulus literal, multiply/add); and F/Result construction.
That gives32 local operations. Including its four callees gives
32+3+3+9+9=56. The extra branch has17 local operations, including q/one
literals, subtraction and F/Result, and two size callees:23 total.

rawRank's common branch has34 local operations: the size-call/value and
area/common prefix; field.val and the q-1 comparison; low/high chunk
division/remainders and constructors; block division; two classRank calls
and two value projections; pair/rank multiply/add operations; and Result.
Including the four callees gives34+3+3+5+5=50. The extra branch has16 local
operations plus the two size callees:22. The public rank wrapper has call,
value projection, Fin constructor and Result, so its bound is54.

All executed literals and fixed-class dispatches are included. Proof terms,
local variable references, and clock arithmetic/fields are excluded. There
are no vector/list scans, hidden arbitrary functions, or unpriced random
operations in these value bodies. A named Nat operation is not a machine
instruction or a new constant-time guarantee.

The value route matches FieldPreimageRectangle's low-fast, then high, then
field-block ordering. The extra field q-1 occurs only when both classes
contain raw zero. The unrank input is the exact finite rectangle rank; rank
requires the exact rectangle Member proof. Those are its legitimate inverse
domains, not claims of a total validated parser for arbitrary unclassified
fields. The rank/unrank inverse statements use the existing rectangle
equivalence; no exhaustive search or new arithmetic inverse is executed.

This review supplies no full global-window inverse, stored-DP transport,
uniform rank law, expected random-sampling work, cached-query coupling,
Poseidon2 distribution, or Fiat–Shamir approval. Those remain with the
author's complete criterion and the coordinator's single build queue.
