# Partial additive/overwrite proof route

Worker 3, `/root/conformance_review`, continuation at `225b271f`.
Analysis paused for the requested selected-commitment count review. No code,
assumption, model approval, build, or claimed security transfer is added.

Primary source: `/tmp/nightstream-chiesa-orru-2025-536.txt`, revision
2026-03-27, SHA-256
`66d1cdd23bf6f18f5f93b08aabe6d0339ef79c0f3b58cfddc980966bd57903e7`.
This builds on `/tmp/nightstream-nifs-co25-additive-review.md`; the current
MODEL_DECISION note and the relevant primary definitions/proof algorithms
were reread. No online search was needed for the facts recorded here.

The exact fixed codec of Definition4.1 (line1561) still excludes a prefix or
permutation argument. Construction4.3 invokes that fixed map on the current
prover message. Thus the unchanged printed theorem cannot directly take
E_S(b)=S_R+b as its encoder. The necessary next route is a new proof of its
simulator/trace interface for this causal encoding, not an assertion that
pointwise invertibility supplies the printed hypothesis.

There is a concrete place to do that. Definitions5.3/5.4 and BackTrack
(lines1755-1886) reconstruct full permutation edges using capacity links.
The capacity links are unchanged by additive absorption. For each absorption
edge with input U and preceding full state S, recover b=U_R-S_R and check
the actual fixed framing and zero padding. For squeeze edges require U=S.
This uses states already in the reconstructed trace, not fresh oracle calls.
It replaces the extraction of overwrite input-rate words in BackTrack item4.
The previously identified cursor/flush/initialization refinement is still
required before assigning edge positions to the actual schedule.

D2SQuery items4(d/e), lines1970-2040, must use that recovered typed prefix
instead of independent per-message membership tests in Im(phi_i).
D2SAlgo and D2STrace (lines2196-2246) must use the same recovery/cache map.
Claim5.23 (line3085) then needs the following online relabeling lemma:

For each new valid semantic prefix u, assign an unused physical label v
measurably from the current simulation history before querying the fresh
raw/decoded oracle answer. The label assignment and inverse must extend
monotonically, be injective, and be identical on every retry. Cache the full
raw decoder preimage and successor state as well as the decoded coin.
Under these conditions, lazy independent random-oracle answers indexed by v
can be coupled exactly to answers indexed by u by induction on fresh queries.
Retries produce no new random draw. The coupling must be on stopped traces;
conditioning on no bad event is not a reason to assume fresh uniformity.

A pointwise permutation-dependent bijection without the freshness condition
is insufficient: for a uniform permutation p on {0,1}, E_p=p^{-1} is a
bijection for every p, but p(E_p(0))=0 always. The example does not refute the
actual causal additive encoding. It pinpoints why a non-anticipation proof
is needed and why querying inverses cannot be ignored.

The missing concrete lemma is that the actual trace-derived label map has
those online properties through arbitrary forward/inverse queries. CO25's
bad events E_h, E_p, E_p^{-1}, E_func (Definition5.7, lines2258-2330) and its
capacity backtracking lemmas are candidate tools. An inverse edge built
before it connects to a valid prefix must not silently become a fresh
independent forward challenge. It must reuse its answer or hit the relevant
capacity/inconsistency event. Pending Cache_p squeeze edges must also be
covered. This has not yet been proved to use precisely the same bad-event
predicate or probability bound.

The challenge lifting must memoize one pair (decoded coin, raw preimage)
per fresh prefix. The exact joint variation cost is the decoder's bias;
uniform decoded coins followed by uniform fiber resampling are not uniform
raw outputs for unbalanced fibers. Existing scalarwise totalization,
acceptance inclusion, exact fibers, and stored counts supply local pieces.
Global inverse sampling, joint cache law, and work are still being developed.

Work still needs explicit trace lookups, four field subtractions per
translated block, fixed-frame parsing, full-state/raw-preimage copies,
cache insertions/lookups, conditional inverse sampling, and rewinds. The
already-proposed squeeze comparisons (12 fields retaining positions0/4
for K;36 fields retaining first32 for R) retain the eager final sampler
state, but require a complete schedule proof and derived L_P/L_V before
using any CO25 loss. The actual shared-Poseidon2 initialization is separate
from the independent h oracle in Definition4.2. No concrete Poseidon2,
state-restoration knowledge, or quantum security conclusion is established.
