# Exact field-decoder fibers: checked source result

Worker 2, `/root/fiat_shamir_model`, 2026-09-10.
The coordinator ran all validation. This worker ran no Lean, Rust, generator,
or backend command. The two source owners are frozen.

## Source and validation

Paths are below
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/`.

| Owner | Lines | SHA-256 |
|---|---:|---|
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldDecoderFiberCount.lean` | 439 | `460f2fb881f174eccbf24a904535fc442675a71f68777fda9f94eddfcf8a87d5` |
| `Lifecycle/PiRLC/v1_1/SamplerFiberCount.lean` | 115 | `16d07b7a165590720b130e63d430cdb887ab76b3c6d4aa17d04b4cbd501c80cf` |

Hashes identify reviewed bytes; they are not protocol authority.

The full consumer target also builds the Spec dependency:

```text
timeout --signal=KILL 1500s bash scripts/validate.sh build \
  NightstreamFPrime.Lifecycle.PiRLC.v1_1.SamplerFiberCount
```

Combined round 1 failed in the Spec owner. Its full record is
`/tmp/nightstream-nifs-sampler-fiber-count-1.log`. The corrections renamed a
reserved local name, normalized only the verifier's symbol projection, and
gave the generic flattening lemma its explicit function argument. No decoder,
count recurrence, field class, or target changed.

Combined round 2 passed with exit 0 in 3 seconds. Spec took 1.2 seconds and
Lifecycle took 1.3 seconds. The full record is
`/tmp/nightstream-nifs-sampler-fiber-count-2.log`. All 14 exports are registered
for the coordinator's next combined axiom audit; that audit is pending at
the time of this note. No third invocation was needed.

Worker 3 independently reviewed the complete mathematics and reported no
necessary gap in the prefix, order, saturation, abort, raw-zero bonus, or
scalar-conversion arguments. The frozen hashes were sent for that review's
record.

## Exact result

The Spec owner uses the existing `FirstAccepted.boundedSample` and
`FieldPairLaw.candidates`. It introduces a list view that preserves each
field's low chunk before its high chunk and preserves lane order. The
selected equality identifies that view with the existing complete 32-field,
64-candidate `FieldShortfall.fieldCandidates` window.

For every symbolic lane count and every complete raw target list, the owner
proves that the corresponding successful fiber has cardinality
`successCount lanes target`. It also proves that all windows for which the
same bounded decoder returns `none` have cardinality `abortCount lanes need`.
These are finite cardinality theorems, with no input distribution premise.

Success is a requested prefix of accepted symbols. The zero-length target
allows every remaining field, with count `q^lanes`. With one digit left, the
`(T_d,H)` rectangle retains an unrestricted high chunk after low succeeds.
The abort recurrence has no target-digit condition: it counts every failed
window, including prefixes that disagree with the eventual fallback.

The rectangle's extra `q-1` field belongs to raw candidate pair `(0,0)`.
The recurrence tests raw alphabet indices equal to zero. Raw index zero
represents centered coefficient -2; centered zero has raw index 2. The proof
does not replace one zero test with the other.

The Lifecycle owner proves the missing inverse direction for every list of
length 54: `List.ofFn (scalarOfList values) = values`. Together with the
existing opposite direction and successful-output length, this identifies
the exact scalar success fiber. For arbitrary supplied fallback `f` and
target scalar `s`, it proves

```text
Nat.card {fields : F^32 // totalizedFieldDecode f fields = s}
  = successCount 32 (List.ofFn s)
    + if s=f then abortCount 32 54 else 0.
```

The successful and aborting alternatives are disjoint. This is scalarwise
comparison totalization. The actual protocol still aborts; there is no
whole-batch fallback substitution or failed-successor-state equality.

The nine Spec exports are `disjoint_event_card`, `successCount_nil`,
`success_fiber_card`, `abortCount_zero`, `abort_fiber_card`,
`successCount_one`, `successCount_two`, `abortCount_step`, and
`candidateList_eq_fieldCandidates`. The five Lifecycle exports are
`ofFn_scalarOfList`, `fieldDecode_eq_some_iff`, `field_success_fiber_card`,
`field_abort_fiber_card`, and `totalized_fiber_card`.

## Remaining inverse-codec work

1. Prove explicit positive-fiber witnesses. For success, the intended witness
   places the 54 requested raw digits in the first 27 low/high pairs with
   common block index zero, then retains five unrestricted tail lanes. The
   all-rejection window separately witnesses abort. These witnesses must be
   connected to the existing decoder, not supplied as a positivity premise.
2. Implement the stored success and abort tables and prove their agreement
   with these recurrences. Charge all raw-target reads, fallback comparison,
   array access, storage, control, and integer arithmetic. The current
   recursive arithmetic definitions are not an efficient memoized runner
   and carry no polynomial execution-time theorem.
3. Implement the global finite rank/unrank maps. At each state, preserve the
   ordered disjoint rectangle branches and interval sizes
   `rectangleWeight * suffixCount`. Use the checked local rectangle map for
   each selected field. Prove branch coverage, disjointness, positive selected
   divisors, complete tail retention, and both global inverse equations. A
   cardinality equality alone does not supply this executable inverse.
4. Specify and prove an exact uniform-rank primitive and its cost contract.
   Uniform sampling from `Fin N`, followed by the proved unrank map, must give
   the exact uniform fiber law. If fair-bit rejection supplies that primitive,
   prove independence, almost-sure termination, and expected work. It has no
   finite worst-case retry bound without a separate interface change. No
   retry budget or truncation is selected here.
5. Prove the joint resampling identity for the chosen conditional kernel:
   inverse sampling after the actual forward image of uniform raw fields
   recovers uniform raw fields, including the paired decoded value. Inverse
   sampling after a uniform scalar is generally a different raw law when
   fibers differ; a zero-distance replacement is not available. Any error
   transfer must use the proved forward comparison law.
6. Prove the 17-coordinate product-fiber identity and independent inverse-call
   law, with work summed over the selected coordinates. Preserve scalarwise
   fallback behavior and actual batch source order; do not replace a failed
   batch by one fallback list.

Exact oracle-query cache consistency and successor-state coupling remain
separate from these finite counts. The complete-query cache must not be
replaced by a cache keyed only by the decoded scalar. Codec scheduling,
additive field absorption, the classical state-restoration extractor, its
symbolic query/rewinding work, and transfer to fixed Poseidon2 remain open.
No FS model is approved by this result. The newer CFRG draft remains a
nonclosing reference and supplies no Nightstream quantum-security claim.

The stopped comparison and commitment criteria were not resumed. This worker
changed no active source, map, shared review document, or evidence archive
after the pass.
