# Complete scalar inverse: stopped interface check and retained drafts

Worker 2, 2026-09-10. Continuation began at
`225b271fb2bd5a0a0b979beafacfab8761af0878`.

The global inverse is incomplete and unvalidated. No global-inverse build
has run. The coordinator stopped the separate three-fact interface criterion
after its third full audit attempt. No fourth check, repair, or narrower
interface check is permitted in this continuation. The coordinator owns
restoring the previous active owners and removing the three new audit lines.
All new inverse source is outside the active package in this directory.

## Stopped interface criterion

The approved facts were `FieldPreimageRectangle.rank_cases`,
`FieldDecoderFiberCount.success_step_iff`, and
`FieldDecoderFiberCount.abort_step_iff`. They change no runtime definition.

| Full audit | Result | Exact remaining issue |
| --- | --- | --- |
| `/tmp/nightstream-nifs-matrix-entry-interfaces-axioms-1.log` | exit 1 | `rank_cases`: zeroBonus stayed as an if on `True ∧ True`, and the Fin-zero goal needed explicit projection normalization |
| `/tmp/nightstream-nifs-matrix-entry-interfaces-axioms-2.log` | exit 1 | `rank_cases`: rewriting zeroBonus in a bound changed the hidden dependent type of `last : Fin zeroBonus` |
| `/tmp/nightstream-nifs-matrix-entry-interfaces-axioms-3.log` | exit 1 | `success_step_iff`, singleton branch at line 178: its numeric need-1/need-0 expressions did not rewrite to private Matches predicates |

The final `rank_cases` body compiled in round 3. The whole three-fact
criterion did not pass, so this is not a request to retain only that fact.
The final decoder error is a local rewrite gap; it does not identify a
mathematical counterexample to the head partition.

For the next goal continuation only, the expected repair is to instantiate
`success_iff_matches [first] (candidateList tail)` and
`success_iff_matches [] (candidateList tail)` explicitly as local iff lemmas,
then use those exact lemmas for the displayed need-1/need-0 terms. This repair
has not been made or checked. The complete three-fact audit remains the target.

Full failed owner snapshots are retained here. The final rectangle snapshot
is byte-identical to its frozen source hash; it was reconstructed from the
retained round 2 bytes with the exact one-line round 3 change and hash checked.

| Snapshot | SHA-256 |
| --- | --- |
| `FieldPreimageRectangle-interface-round-1.lean` | `2e398d52363ac75e8965c59a3ba86f1d6ee3ad04bf0334bbfdd69b1b1e028306` |
| `FieldPreimageRectangle-interface-round-2.lean` | `7f551fe153d8e46d11d90170af3ee4a4bd293ff32400fe9ffbc9cd06940bdc87` |
| `FieldPreimageRectangle-interface-round-3.lean` | `9c91bddbdeec511af98d1423ec5b906a364bdd7e63e6a28a5277b8587d3895a0` |
| `FieldDecoderFiberCount-interface-round-1.lean` and `-round-3.lean` | `0a84e30e9089382adaa130d3d27e224adeb1725070af9a80f2f66b62f0943281` |

## Current inverse drafts

None of these files has been built. A drafted theorem body is not a checked
result. Only the local rectangle clock has received an independent source
review. No active package import or audit registration for these files is
requested until the complete criterion is ready.

| Draft | Lines | SHA-256 | Scope |
| --- | ---: | --- | --- |
| `StoredRectangleRank.lean` | 323 | `d48ba45582eec9cfe5c4a49b26754a9d3915467ba775c52c8cefa47f195d412f` | Direct arithmetic local rank/unrank, refinement to rectangleEquiv, both inverses, proposed work 56/54 |
| `StoredFiberIntervals.lean` | 131 | `72fcefb4b22b410ed2c0d5b2669fa6903b1d39ea2bb07f1049b4b2e4f295a98a` | Ordered stored-list interval selection/join, inverse equations and work bounds; zero intervals are skipped |
| `StoredFiberCopies.lean` | 117 | `e0ca3f4cd0317e33f47eb769ec7364b6995b99da475e4bff065e50c28fae0e41` | Actual Vector-to-list reads and list-to-Vector construction, with possible prefix copies |
| `StoredInverseInput.lean` | 220 | `0e6ff2236c1444c7ca19d35ce687c3763709a031693f7d8e42ada1f70fbb3aba` | Stored equality, cached small weights, Prepared correctness, normalizer, positivity/width and preparation clock |
| `StoredDecoderBranches.lean` | 388 | `86a6ab93dce136566848826e4142ec4dd9b86c6e996b2783a04b634efdc8d11b` | Cursor, stored branch counts, ordered transitions, sum/cover draft proofs, and stored list head/tail operations; still incomplete |

The local rectangle source review is
`/tmp/nightstream-nifs-stored-rectangle-rank-review.md`, SHA-256
`bb4f874d85cdc7ed3e38423e2f3c221bfc79a86c68bf981a6803fc81d49cc303`.
It found no count defect in the exact frozen local source. It covers class
size 3, class unrank max 9, class rank max 5, rectangle unrank 56, raw rank 50,
and typed rank 54. It is explicitly pre-build evidence.

The other clocks need full source review and validation. Current formulas
are selection <=18*countLength, join <=13*countLength,
Vector-to-list =9*n+8, and list-to-Vector <=3*n^2+10*n+7 under the established
allocation/copy convention. Prepared's displayed formula evaluates to 426553:
425407 table +494 target copy +603 stored equality +19 weights +7 initial
read +23 wrapper. These are unvalidated draft bounds, not a completed work
claim. The branch factory draft has bound 147 with its level supplied;
constructing that level remains caller work.

## Approved complete contract and implementation direction

The coordinator approved new owners split by semantic responsibility, all
below 1500 lines, with one complete Lifecycle consumer build as the inverse
criterion. The public shape is `prepare target fallback`, a proved positive
normalizer, `unrank prepared : Fin normalizer -> Result (Vector F 32)`, and
`rank prepared : completeFiber -> Result (Fin normalizer)`, with both inverse
equations and full derived named-work bounds. Runtime callbacks, if needed,
must be private and have their costs discharged for their actual callees.

Inputs are stored 54-coefficient Vectors. `Prepared target fallback` now
stores the target list, table, six small weights, equality flag and count.
The input Vectors are type/proof parameters after preparation and are not
retained as duplicate runtime data. Proof fields certify the copied list,
the exact built table, weights, equality flag and normalizer. A forged cache
cannot acquire authority without these equations.

The coordinator explicitly approved copying the target once and traversing
its stored list tails. The same rule applies to a one-time input copy for
rank and a one-time output conversion for unrank. Every head, tail, index,
allocation and copy must be charged. Semantic `.get` function views are for
proofs only. The current branch owner uses `List.Vector F n` for the stored
intermediate field list, and retains the existing bounded sampler as its
sole decoder predicate.

The branch order is RR, high-only, low-only, both. Success with one digit
left uses RR, R/T, T/H; saturation uses H/H and retains all unused fields.
Abort uses RR, R/V, V/R, V/V without a residue restriction. Cursor digits
describe the requested target suffix; they are not a premise that an
aborting input prefix matched that target. All zero bonuses test raw index 0,
which denotes balanced coefficient -2.

At each step, branch mass is rectangleWeight * storedSuffixCount. Select
the interval, subtract the earlier intervals, then use quotient/remainder
by the suffix count to obtain local field rank and suffix rank. The selected
Fin interval proves the divisor positive, including when other masses are
zero. Only the selected recursive continuation may run; do not eagerly
construct a tree of all continuations. Local rank order remains low-fastest,
high-next, block-last, with q-1 as the permitted final rank.

## Work still needed before the complete inverse check

- Finish and validate the three interface facts in a new continuation.
- Finish branch uniqueness by head-class disjointness. Complete the stored
  branch lookup/classification and their clocks. Ranking must classify the
  head rectangle, not run the complete bounded decoder as an uncharged test.
- Add the positive-product quotient/remainder helper, and its inverse/work
  proofs, for local field rank times suffix rank. No divisor positivity
  premise may be assumed.
- Implement the complete structural success/abort rank and unrank drivers
  over all 32 lanes and the stored cursor; prove membership and both inverses.
  Only n decreases. No arbitrary fuel or retry limit is authorized.
- For target=fallback, put successful target windows first and every aborting
  window second as a disjoint rank interval. For other targets, use only the
  success interval. Preserve all field/candidate order and unused suffixes.
- Complete public stored Vector wrappers, their conversions and normalizer
  costs, and the Lifecycle equivalence to `totalizedFieldDecode` on its own
  fields. No global driver or Lifecycle inverse consumer file exists yet.
- Source-review the complete clocks, freeze exact exports and sources, then
  request the one full consumer build from the coordinator. The global
  inverse criterion has used zero build attempts so far.

The coordinator separately owns UniformBelow finite-law work. This worker
adds no random generator, bit-source premise, PMF implementation, expected
time theorem or production randomness slot. A finite rank bijection will
support a conditional uniform-fiber law, but the randomness and time contract
remains separate. No Poseidon2 IID law, global cache/resampling theorem,
overwrite/additive absorption theorem, state-restoration transfer, query
budget or Fiat-Shamir model is selected here.

Corrected SuperNeo §7.4/B.3 and CO25 Lemma 3.2, Definition 4.1–4.2,
Construction 4.3 and the D2S inverse/time interface were reread for this
continuation. The external PiCCS report was unchanged at the 18:20 checkpoint
read; it supplied no inverse-specific finding. The Fable review and named
worktree review files were absent.
