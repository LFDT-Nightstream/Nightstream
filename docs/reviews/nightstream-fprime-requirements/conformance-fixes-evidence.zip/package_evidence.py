"""Package this task's original diagnostic records without granting closure."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

store = Path(__file__).resolve().parent
repo = Path('/Users/nijaar/starstream/Nightstream-fprime-conformance-fixes')
destination = repo / 'docs/reviews/nightstream-fprime-requirements/conformance-fixes-evidence.zip'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

inputs = json.loads((store / 'inputs.json').read_text())
input_records = {}
for name, value in inputs.items():
    root = Path(value)
    files = [root] if root.is_file() else sorted(p for p in root.rglob('*') if p.is_file())
    input_records[name] = {
        'original_path': str(root),
        'files': [{
            'path': p.name if root.is_file() else str(p.relative_to(root)),
            'bytes': p.stat().st_size,
            'sha256': digest(p),
        } for p in files],
    }

(store / 'final-source.patch').write_bytes(subprocess.check_output([
    'git', 'diff', '9e49e7fbe03d61b0e16eec1d6f839d33d57af9bb', 'HEAD',
    '--', '.', ':(exclude)formal/nightstream-fprime/artifacts/**',
], cwd=repo))
files = []
for pattern in ('*.log', '*.stderr', '*.json', '*.py'):
    files.extend(store.glob(pattern))
files += [store / 'reviewed-source.patch', store / 'final-source.patch']
files += [p for sub in ('diagnostics', 'new-source') for p in (store / sub).rglob('*') if p.is_file()]
files += [p for p in (store / 'graph/review-requests').glob('*.json')]
for run in (store / 'graph/runs').glob('*'):
    files += [p for p in run.iterdir() if p.is_file() and (p.name == 'result.json' or p.name.startswith('command-') and p.suffix == '.log')]
files = sorted(set(files))
manifest = {
    'schema': 1,
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'scope': 'Local diagnostics, original failures and pending independent review requests. No accepted-checker authority or phase closure.',
    'inputs': input_records,
    'records': [{
        'path': str(p.relative_to(store)),
        'bytes': p.stat().st_size,
        'sha256': digest(p),
    } for p in files],
}
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    archive.writestr('manifest.json', json.dumps(manifest, indent=2) + '\n')
    archive.writestr('README.md', '''# Conformance fix evidence

These are this task's local command records, including failures. They do not
come from an approved checker and do not grant independent review approval.
The 91 candidate checks use the exact pre-pin patch and new files recorded in
reviewed-source.json. Later commands use the stored package and corrected pins;
see executions.json and the repository's CONFORMANCE_FIXES.md.

manifest.json identifies the final code commit, every included original record,
and the selected input bytes. Full opening carriers, third-party libraries, build products and derived
dependency-graph data are not duplicated here. Their original records and
input identities remain available in the external evidence store. The original inputs remain in the
external evidence store. Input identities describe bytes, not proof authority.
The selected serialized phase inputs and results are included. Fixture-generation
commands and the final source patch are included for reproduction.
''')
    for path in files:
        archive.write(path, str(path.relative_to(store)))
    for name, value in inputs.items():
        path = Path(value)
        if path.is_file() and name not in ('package', 'expanded'):
            archive.write(path, 'selected-inputs/' + name + path.suffix)

print(json.dumps({'path': str(destination), 'bytes': destination.stat().st_size,
                  'sha256': digest(destination), 'files': len(files)}))
