# Field preimage rectangle review

Root source review, 2026-09-10. Reviewed SHA-256 cb7c539cb13b21e0a3acd82e2b6d5945a4f1be50b8f10eb45f5b63116c3c89d6. Full round-3 build remains pending.

The four classes have the required exact meanings: reject 65535, one accepted residue modulo 5, all accepted candidates, and unrestricted candidates. The field decomposition has (2^32-1) common blocks of 2^32 words and one final field q-1. Every common block maps its word to the low/high 16-bit pair; the extra field maps to pair (0,0). The subtype equivalences preserve both restrictions. Common ranks put the low class index first, the high index second, and block last. The extra rank follows all common ranks and exists only if both classes contain zero. No enumeration or Choice-backed sampling implementation is introduced.

The ten statements concern arithmetic bijections and exact cardinalities. They do not prove whole-window decoder preimages, a random sampler, its execution cost, independence, an adaptive oracle simulation, or a Poseidon2/Fiat-Shamir security claim. HasZero for a residue is raw alphabet index zero, not the zero of the later balanced field embedding. No necessary source defect found. Lean validation and the final axiom audit remain required.
