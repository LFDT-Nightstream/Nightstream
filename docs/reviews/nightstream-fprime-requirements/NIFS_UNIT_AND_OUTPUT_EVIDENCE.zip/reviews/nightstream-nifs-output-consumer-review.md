# Output-law review and external finding applicability

Independent reviewer: Worker 3 (`/root/conformance_review`), 2026-09-10.
Worktree: `/home/nicoarq/develop/Nightstream-nifs-proof-links`.
Git HEAD during inspection: `4b4a8ddfb0f19de82b3437d7bee2f851620c99ed`.
New Lean files are identified by content hashes below. This was a read-only
source review; no build, old review suite, proof backend or protocol test
was run. Only this temporary review record was written.

## Current applicability of the external PiCCS finding

The external review was absent from the worktree but present at
[/home/nicoarq/develop/Nightstream/FPRIME_STAGE1_EXTERNAL_REVIEW.md](/home/nicoarq/develop/Nightstream/FPRIME_STAGE1_EXTERNAL_REVIEW.md).
It is the 2026-09-04 review of `d4d1b39a543025408b79e9e7c818f78b639895e9`,
with SHA256 `20dc5aaceef7e9ea712cfa71eee65339b31b8fe4f0be6a0167a4cf464db7d11c`.
The coordinator retained its checkpoint read in
[/tmp/nightstream-nifs-external-review-0720.log](/tmp/nightstream-nifs-external-review-0720.log).
Its historical build/test results were not treated as current validation.

The public route to the compressed relation remains present in the current
source. This finding is not merely historical and the route was not removed.
Making `frontends::nebula::f_prime` crate-private does not remove public
constructors and methods on its publicly reexported types.

| Current source anchor | Relevant fact |
|---|---|
| [lib.rs:95](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/lib.rs:95) and [frontends/mod.rs:33](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/frontends/mod.rs:33) | The crate exposes the frontend module tree and `nebula`. |
| [nebula/mod.rs:32](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/frontends/nebula/mod.rs:32) | The `f_prime` module is crate-private, but `NebulaFPrimePreparedProfile`, `NebulaFPrimePreprocessing` and `NebulaFPrimeChainBuilder` are publicly reexported. |
| [chain.rs:153](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/frontends/nebula/f_prime/chain.rs:153), [chain.rs:332](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/frontends/nebula/f_prime/chain.rs:332), [chain.rs:396](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/frontends/nebula/f_prime/chain.rs:396) | The reexported types have public constructors. `append_segment` and the other public append/finish methods enter the chain implementation. |
| [chain.rs:897](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/frontends/nebula/f_prime/chain.rs:897) | `synthesize_instance` obtains `nifs_v_circuit_config`. |
| [chain.rs:997](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/frontends/nebula/f_prime/chain.rs:997) | Recursive synthesis calls either application or memory-only Nebula F-prime enforcement. |
| [f_prime.rs:1060](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/frontends/nebula/f_prime.rs:1060) and [f_prime.rs:1127](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/frontends/nebula/f_prime.rs:1127) | Those wrappers call `enforce_f_prime_recursive_step_circuit`. Its crate-private visibility does not remove its public caller. |
| [paper/f_prime/r1cs.rs:1086](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/paper/f_prime/r1cs.rs:1086) and [paper/nifs/circuit/mod.rs:143](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/paper/nifs/circuit/mod.rs:143) | The recursive circuit calls native NIFS enforcement, which calls the native PiCCS circuit. |
| [verifier_claims.rs:121](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/paper/reductions/pi_ccs_circuit/verifier_claims.rs:121) | `evaluation_families()` is allocated as a combined `y_ring`. |
| [padded_row.rs:293](/home/nicoarq/develop/Nightstream-nifs-proof-links/crates/neo-fold-clean/src/paper/reductions/pi_ccs_circuit/verifier/padded_row.rs:293) | The check rejects unless `eval_a.len()+1 == matrix_count`. A 14-matrix relation therefore requires only 13 Eval_A families beside Eval_K. |

These calls have no `cfg(test)` gate on the inspected route. The present
claim is source reachability; no new Cargo result or accepted attack input
was produced. The selected Lean relation and this milestone's stored
checker remain a separate path. The native public `pi_ccs::verify` also
calls the ordinary engine after `validate_verifier_shape`; it is not this
compressed circuit routine. The finding does not invalidate the new local
Pad or sampling theorems.

Current [CONSTRAINT_TREE.md:237](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/CONSTRAINT_TREE.md:237)
says that no normal-build public F-prime path contains this encoding and
that the Stage 2 caller is crate-private. That statement is too broad in
view of the public type reexports and methods above.

`N.conformance.owners` requires closure at the selected relation,
transcript, state digest, input schema and compiler owners, and says native
support must not create a conflicting standalone protocol authority. See
[MAP.md:569](/home/nicoarq/develop/Nightstream-nifs-proof-links/docs/reviews/nightstream-fprime-requirements/MAP.md:569).
The current progress report correctly leaves this owner partial. The live
route is an unresolved authority restriction for that owner and broader
Stage 1 closure. It must remain in the milestone record; there is no claim
of complete public-authority exclusivity.

For this milestone, retaining that restriction is necessary. Changing
Stage 2/backend code or rerunning the September 4 suite is not needed to
validate the frozen local proof changes. The goal excludes Stage 2 work;
the coordinator has explicitly left ownership partial. No remediation or
broader closure was approved by this review.

### Current Rust identities

Paths below are relative to the worktree root.

| File | SHA256 |
|---|---|
| `crates/neo-fold-clean/src/lib.rs` | `afa69614f62f3b920941e98ce08368524916e7dd05e6dce15c4db3b1a3823beb` |
| `crates/neo-fold-clean/src/frontends/mod.rs` | `0dbc3c55d402e4a60f0ce7494a438586db5c43c6a2838eb5bbdbecefb50c467a` |
| `crates/neo-fold-clean/src/frontends/nebula/mod.rs` | `dbe388d1f8fc063ff70a04ad311b8b99350c25c97d182261439eff6e9ff9ea73` |
| `crates/neo-fold-clean/src/frontends/nebula/f_prime/chain.rs` | `496f25f094e2276926473305ef04a3e575f68533f4b5b0fb84848654cc4c2a38` |
| `crates/neo-fold-clean/src/frontends/nebula/f_prime.rs` | `0aee18313773f0d232a9613b8759bd9a3a0a03500f9236b740a7f684815233ab` |
| `crates/neo-fold-clean/src/paper/f_prime/r1cs.rs` | `eb6b5e7eff2ca0efa3985e5cf3700153460f19e4e11de3afb2337b85395ec2fe` |
| `crates/neo-fold-clean/src/paper/nifs/circuit/mod.rs` | `67e17736c5c5cefe1b36eadc8d6969e965109a74718f4e64ac394bcdd3ecb8ef` |
| `crates/neo-fold-clean/src/paper/reductions/pi_ccs_circuit/verifier_claims.rs` | `dde89c022b4dea8889c1b577c3f262d8de04650a84e4dfd2255b8ab1c2d128d0` |
| `crates/neo-fold-clean/src/paper/reductions/pi_ccs_circuit/verifier/padded_row.rs` | `bfcc122a04883f8706ad3c40be5e09fe5cbd87aa92c854a50e5fc487c65b8079` |

## Frozen bit and scalar output-law review

No defect was found in the stated value and finite-law claims at these
hashes. Paths are relative to `formal/nightstream-fprime/NightstreamFPrime/`.

| File | SHA256 |
|---|---|
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/BitOutputLaw.lean` | `e3c980e4197a65c9bd838092c8a0e98bf618bb723d5add75e8bab18162ddc699` |
| `Lifecycle/PiRLC/v1_1/SamplerOutputLaw.lean` | `ffca33b3cb9bf4c50318992249d944f2f8325163f893769e6abcc86a0e58b1b2` |
| `Lifecycle/PiRLC/v1_1/SamplerFieldShortfall.lean` — inspected deterministic dependency | `037ced259569c69670ba5a2f530c96f588ea9c70757ebf258f4ba042d700d1b2` |

### BitOutputLaw

The new bijection permutes each accepted chunk's residue while preserving
its quotient. Rejected chunks are fixed. Its scan indexes permutations by
accepted rank, so it preserves all input positions and rejection flags.
The inverse follows the same ranks because acceptance is preserved. For
the first 54 accepted ranks, the per-coordinate swaps map any selected
scalar to any other; later accepted values need no change.

[successful_fiber_card_eq](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Spec/Folding/Nifs/NonInteractive/PiRlcSampler/BitOutputLaw.lean:255)
therefore gives equal successful fibers over the full 64-candidate input
space. The support lemma uses `bounded_success_length`; it does not assume
that a success has the right length or discard malformed lists by fiat.

The finite cardinal decomposition partitions an arbitrary output event
into its abort part and its successful scalar fibers. With `a_bits` the
existing exact bit-shortfall frequency, the four remaining exports prove:

```
P_bits(E) = (1-a_bits) * U_some(E) + 1[E(none)] * a_bits
abs(P_bits(E)-U_some(E)) <= a_bits
abs(P_fields(E)-U_some(E)) <= 32*pairDeviation + a_bits
abs(P_fields(E)-U_some(E)) <=
  32*pairDeviation + choose(64,11)/65536^11.
```

The bit input space has cardinality `65536^64`. `U_some` is uniform over
the `5^54` scalar encodings and has zero mass at `none`. The field space
has cardinality `q^32`. The field result uses the previously reviewed
FieldOutputLaw bound and the triangle inequality. It does not claim that
successful field-decoded scalars are exactly uniform.

All five exports are finite mathematical statements. The use of finite
cardinality and classical proposition decisions is proof-only; the proof
does not enumerate either input space or define an executable random
sampler with assumed cost.

### SamplerOutputLaw and actual event link

[sampleScalar_eq_fieldDecode](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/PiRLC/v1_1/SamplerOutputLaw.lean:27)
holds for every initial state and coordinate. Its dependency reads exactly
four rate lanes from each of the eight pre-permutation digest states after
the actual coordinate label. `candidateWindow_eq_fieldCandidates` preserves
the order of both candidates per lane and all 64 positions.

`fieldDecode` and `bitDecode` use the actual `scalarOfList` conversion.
`scalarOfList_ofFn` proves its exact action on a 54-value scalar list;
the successful support and length facts ensure its default is unreachable
on successful bounded decoding. `field_bit_event_error_le` applies the
existing bound to every event on `Option Scalar`.

[field_output_event_error_le](/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Lifecycle/PiRLC/v1_1/SamplerOutputLaw.lean:54)
transports the complete field-to-uniform-scalar bound, with `none` retained
on the field side. Its target denominator is exactly `5^54`; the target
law never produces `none`. This is the stated comparison, not conditioning
the field input on success.

The pointwise actual-source equality and the uniform-input frequency law
are separate. Their combination does not assign independent uniform fields
to deterministic Poseidon2 replay. It also supplies no joint output law
for the entire 17-scalar transcript, no adaptive-oracle/cache law, no
Fiat–Shamir transfer, no retry rule and no extractor runtime theorem.

## Validation scope

The reviewer read these existing successful logs:

- [/tmp/nightstream-nifs-bit-output-law-2.log](/tmp/nightstream-nifs-bit-output-law-2.log):
  full BitOutputLaw target passed; module 1.8 seconds, command three seconds.
- [/tmp/nightstream-nifs-sampler-output-consumer-1.log](/tmp/nightstream-nifs-sampler-output-consumer-1.log):
  SamplerOutputLaw target passed; module 1.3 seconds, command three seconds.

The final combined audit was pending when this record was written. The
coordinator reported that the public-gate criterion stopped after its third
failed check and that its draft would be preserved outside active source.
No public-gate implementation or reduction of its remaining premise is
approved by this review. The earlier selected Pad review retains its three
explicit remaining leaves. No model, backend or broad conformance closure
is approved here.

## Final validation update — committed source dce69b69

The final source is committed at
`dce69b693fc52ff7e7c138198756f9c1400878d6`. The coordinator reports no
source changes since the content-hash reviews above. This update replaces
the earlier pending audit status only; it does not extend the source scope.

The reviewer read the complete audit output through a parser that required
each declaration's complete axiom list. It found 302 record headers, 302
complete records and 302 distinct declaration names. All 39 new exports
listed in the retained summary occur in those records. There are no error
lines or axioms outside `propext`, `Classical.choice` and `Quot.sound`.

[The final combined audit](/tmp/nightstream-nifs-unit-output-axioms-1.log)
ends with `Build completed successfully (3713 jobs)` and
`[bounded] exit=0 elapsed=26s`. It covers the retained NIFS audit target,
including the new Pad, term-storage, field/bit sampler and RingF/unit
exports. The coordinator and
[audit summary](/tmp/nightstream-nifs-unit-output-audit-summary.json)
record that this final build ran alone. Its timing is separate from the
previously recorded overlapping focused unit check.

[The final static record](/tmp/nightstream-nifs-unit-output-static-1.log)
reports `[boundary] all checks passed`.

| Retained record | SHA256 |
|---|---|
| `/tmp/nightstream-nifs-unit-output-axioms-1.log` | `538258fcbef0c32d51128c48f2fd9834a29b7327e6283cc70aad01abf7ab3eca` |
| `/tmp/nightstream-nifs-unit-output-audit-summary.json` | `b4bbd864c0c1cfbc875f000f6eca0fff4ce24d78b0828509d372aa34ba0e4a49` |
| `/tmp/nightstream-nifs-unit-output-static-1.log` | `ad9e1e52d1607f377312108c20dbf84566406a2fdee0bfc46b65be21824f33e0` |

The stopped public-gate draft remains outside approved active scope. The
three remaining selected checker leaves, full runtime and Fiat–Shamir
transfer are not closed by this audit. The current public Nebula route to
compressed PiCCS remains the live authority restriction stated above;
`N.conformance.owners` and broader Stage 1 closure remain partial. No build
was rerun and no active source was changed for this validation update.
