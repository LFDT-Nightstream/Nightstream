# Stored power inverse: scoped review and final-attempt record

Date: 2026-09-10. Worker 2, `/root/fiat_shamir_model`.

The initial source was authored by the coordinator. Worker 2 reviewed the
value and work structure, then took ownership of the third proof attempt
after two resource stops. This is a self-review of that final attempt, not
an independent review of its final proof implementation. The coordinator
will obtain an independent review after a passing focused check.

The reviewed round-2 source had SHA-256
`8e48d8019350eeeff84c7334134872c54f28d0b904b308c9c782184b092e09c4`.
The frozen round-3 source is
`formal/nightstream-fprime/NightstreamFPrime/Spec/Phi81Relation/EvaluationHomomorphism/StoredRingPowerInverse.lean`,
SHA-256 `0bd2a8a5bd0c7900ec69d4e9dcee61f6ca3c386e8e4ae3732f4253670701447f`.
Hashes identify source bytes only.

## Value and execution route

The candidate computes `q^27 - 2` from the fixed Goldilocks modulus. It
does not receive an inverse. The bound `q < 2^64` derives
`q^27 - 2 < 2^(64*27)`. The power routine receives depth `64*27 + 1`.
This is a sufficient depth derived from the fixed exponent; it is not a
retry limit or a selected security budget.

On each nonzero-exponent step, the program materializes the square of the
current stored base, recurses on that stored square and half the exponent,
then materializes one additional product exactly when the exponent is odd.
It also squares when the exponent is one. Zero exponent returns a newly
materialized identity. The depth-zero fallback exists in the private
routine; the exponent bound excludes reaching it with a positive exponent
in the public candidate's value proof.

Every ring intermediate is a `Vector F 54`. The multiplication and identity
calls use `StoredRingArithmetic` and its direct array builder. No semantic
coefficient function or supplied unit inverse is executed as a primitive.
The quotient `image` and algebraic powers occur only in the proofs.

The value argument uses the existing Phi81 quotient. The 27th Goldilocks
Frobenius fixes both the base-field coefficients and the quotient root,
so it fixes every quotient element. This does not require treating the
quotient as a field or assuming irreducibility. On a unit, cancellation
gives the product of the computed power and input equal to one. Ring
associativity and the other side of the supplied unit identity then give
equality with that unit witness's inverse. The witness is used only in
these proof statements. No inverse correctness is claimed on nonunits.

## Work scope

The work theorem bounds the same returned clock as the executed candidate.
Each nonzero step pays for its square, its recursive call, and the odd
product when selected. The work bound conservatively permits two products
per depth step, plus the stated control envelope. Exponent construction
has its own returned clock; the wrapper includes that clock and its eight
named operations. All branch counts and public `inverseWork` expressions
are unchanged in the third attempt.

The natural-number operations act on at most 1728-bit values on the public
route. They are named arithmetic operations in the fixed-profile model,
not single machine instructions or a proved bit-operation count. The ring
primitives retain the grouped array-builder convention recorded in
`/tmp/nightstream-nifs-stored-ring-arithmetic-review.md`. Result-clock
instrumentation, compiled call overhead, allocator behavior, and peak
memory do not acquire new guarantees from these counters. The wrapper
refactor preserves value and returned-clock expressions; it does not claim
compiled instruction equality.

## Proof-cost repair and validation status

The first check was stopped after 112 seconds with about 24 GB of Lean
memory and no source diagnostic. The second reproduced the growth. Its
retained resource record reports 23,600,536 KB RSS; the build log reports
an 88-second module job and exit code 143 from the terminated Lean child.
The records are:

- `/tmp/nightstream-nifs-stored-ring-power-inverse-1.log`
- `/tmp/nightstream-nifs-stored-ring-power-inverse-1-resource-stop.json`
- `/tmp/nightstream-nifs-stored-ring-power-inverse-2.log`
- `/tmp/nightstream-nifs-stored-ring-power-inverse-2-resource-stop.json`

The third attempt removes direct selected-loop rewrites from the public
proofs. The generic power proof names its returned square and half-result
arrays before quotient algebra. Generic wrapper image/work lemmas use
symbolic fuel and an exponent result. Generic product and inverse-uniqueness
lemmas use opaque returned arrays. The selected wrapper uses only explicit
theorem applications. No heartbeat, recursion, or timeout setting was
raised. This is the last permitted check for this criterion in the current
goal turn; its result is pending at the time of this record.

The candidate remains unselected. A focused proof pass, independent review,
combined audit, and runtime comparison with the existing normalized xgcd
candidate are separate evidence. Neither candidate's value theorem selects
it for production or closes Fiat-Shamir inverse-codec work.
