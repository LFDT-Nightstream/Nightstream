# Independent PiDEC row and complete fiber review

Reviewer: Worker 3, `/root/conformance_review`.
Worktree: `/home/nicoarq/develop/Nightstream-nifs-proof-links`.
Baseline at review: `ab93bd99394c2fd0b03f4239980ed273ee1ea8bd`.
The exact new sources are the four files in the manifest below; no new code
commit was assumed when this review began.

Result: **the three new modules' stated local claims and their 17 audit
exports are substantiated by the final sources and retained checks**.
The reviewer read both complete fiber files, the PiDEC row source and its
count corrections, and independently parsed the full final audit. No active
edit, build, test, generator, or backend command was run by this reviewer.
Map changes and evidence packaging are separate coordinator work.

## PiDEC row: exact value and named work

`PiDECOrdinarySourceWork` retains the frozen source previously reviewed in
`nightstream-nifs-pidec-ordinary-source-work-review.md`. The complete third
check now passed on those same bytes, with terminal exit zero, 1.9s module
time and 2s wrapper time. Its three exports are `commitmentRow_value`,
`commitmentRow_lengths`, and `commitmentRow_work_le`.

For each `Fin 1188` coordinate, it constructs the exact selected, remapped
commitment-recomposition row. A has 16 ordered binary-weight child terms,
B has constant one and no terms, and C has the single parent term. The
constructor computes indices and weights directly. It does not call the
whole packet/list getter or execute the proof's semantic source function.
The lowering/column-map value theorem targets the existing selected owner.

The corrected named clock is at most 2,218. Parent/child columns cost four
and seven; power costs `3+7*k`; weight and child-term wrappers add six each;
the child list has base three and step ten; the final direct row construction
adds nineteen. The child bound `k<16` follows from the actual loop. The
three public theorems add no source/value/work premise. The count is not a
machine-runtime, allocator, bit-complexity or gas theorem. It also does not
complete all selected row dispatch, sparse conversion, substitution, or the
final matrix-entry consumer.

## Complete field-window fiber claims

The 439-line `FieldDecoderFiberCount` and 115-line `SamplerFiberCount` were
reviewed for their complete declared mathematical scope, not just the lines
that initially failed elaboration. No mathematical gap was found. The final
round-2 proof repairs rename the reserved local prefix name, identify the
existing verifier symbol, and repair the finite-list equality proof; they
do not alter the success/abort recurrences or decoder.

`candidateList` reads fields in increasing lane order, placing the low
16-bit chunk before the high chunk of each field. Its final equality theorem
matches the existing 32-field/64-candidate view, including the quotient and
remainder indexing. It does not replace that view with independent chunks.
Each field pair uses the exact `FieldPreimageRectangle.size` weight, so the
extra field `q-1` is included precisely when both raw classes contain zero.
Raw symbol zero still means centered coefficient -2, not centered zero.

The successful fiber asks that the requested target list be the prefix of
the accepted-symbol list. With no fields, only the empty target has one
input. Once the requested suffix is empty, every remaining field is free,
giving `q^lanes` possible windows. This is necessary because the bounded
decoder returns the first requested accepts and ignores later candidate
values; it does not require the total number of accepts to be exactly the
target length.

With one requested digit left, the three branches are disjoint:

- both chunks reject, and the same digit is still needed;
- low rejects and high matches that digit, completing the target;
- low matches that digit and high is unrestricted, completing the target.

The final branch correctly includes every high chunk after completion,
including rejected chunks and accepted chunks with other digits. With at
least two requested digits, the four branches are reject/reject,
reject/first digit, first digit/reject, and first digit/second digit. They
leave the same suffix, remove one digit, remove one digit, or remove two,
respectively. Accepted wrong digits are excluded from successful prefixes.
The one- and two-digit formulas have exactly the corresponding rectangle
weights and raw-zero bonus. Their middle equal-weight branches are combined
arithmetically without changing the pair order.

The abort recurrence restricts only the number of accepts still needed.
Its accepted class permits every accepted digit, with no target-prefix or
fallback-digit restriction. For a positive need, the four branches remove
zero, one, one, or two accepts, using natural subtraction. `abortCount lanes
0 = 0`, so reaching or exceeding the required number cannot later become
an abort. With no fields, every positive remaining need has the one empty
window. This covers all shortfall windows, including windows whose earlier
accepted values do not match any chosen fallback.

The cardinality proof decomposes the field window into its first field and
remaining window. Rectangle restriction and remaining-window restriction
form a product. The branch sums are justified by disjointness, obtained from
reject-versus-accepted incompatibility. There is no assumption of fresh
independent transcript states: these are exact finite cardinalities over
all typed field windows.

The scalar consumer uses the existing `fieldDecode`. Every successful
coefficient list has length 54. `ofFn_scalarOfList` recovers that whole list,
so the scalar conversion's default is unused and no output coefficient is
discarded. The successful scalar fiber is exactly
`successCount 32 (List.ofFn scalar)`. The abort fiber is exactly
`abortCount 32 54`.

For comparison-only scalarwise totalization, a target different from the
fallback has only its successful fiber. At the fallback, the fiber is the
disjoint union of successful fallback windows and every aborting window.
Thus the final count is
`successCount 32 (List.ofFn scalar) + if scalar = fallback then abortCount
32 54 else 0`. The disjointness is the actual Option `some`/`none`
separation. The real sampler and its rejection behavior are unchanged.

These arithmetic recurrences are not a proved stored dynamic program.
They supply no execution/work bound, full-fiber rank/unrank implementation,
uniform-rank generator, conditional inverse sampler, or its expected work.
They do not make actual Poseidon2 field windows uniform, prove a full
accepted-verifier comparison, or supply a state-restoration/Fiat--Shamir
knowledge transfer. No such claim appears in the reviewed module contracts.

## Exact new exports and final audit

The Spec fiber module has nine exports: `disjoint_event_card`,
`successCount_nil`, `success_fiber_card`, `abortCount_zero`,
`abort_fiber_card`, `successCount_one`, `successCount_two`,
`abortCount_step`, and `candidateList_eq_fieldCandidates`.
The consumer has five: `ofFn_scalarOfList`, `fieldDecode_eq_some_iff`,
`field_success_fiber_card`, `field_abort_fiber_card`, and
`totalized_fiber_card`. Together with the three PiDEC exports, these are
exactly the 17 newly registered names. No export is missing or added to the
claimed scope by the audit list.

The complete fiber consumer build passed with 2,432 jobs, terminal exit zero
and a 3s wrapper time; the Spec and consumer module times were 1.2s and 1.3s.
The final dependency-aware NIFS audit passed 3,730 jobs in 2s with exit zero.
Independent parsing found 378 headers, 378 complete records and 378 distinct
names. They match the registration order exactly. The old 361 registrations
remain the same prefix. There are no source errors or axioms other than
`propext`, `Classical.choice` and `Quot.sound`.

All four manifest files match their current bytes and SHA-256. Its new-export
list matches the 17 appended registrations in order. The static log reports
all checks passed, and the coordinator reports terminal exit zero. The
16:20 protected-review log is byte-identical to the 15:35 log; protected
contents and absence results are unchanged. No old external review suite
was rerun here.

The stopped selected commitment and totalized verifier-comparison modules
remain absent from active source. Neither is among these exports. Their
failed-draft and no-adapter status is not changed by the new row generator
or fiber counts. The complete commitment/matrix-entry contracts, actual
producer and representation/runtime links, inverse selection, and full
Fiat--Shamir transfer remain open. No model or protocol profile changed.

## Frozen source and record identities

Source paths are relative to `formal/nightstream-fprime/`.
Hashes identify bytes; they are not protocol authority.

| Source | Bytes | SHA-256 |
|---|---:|---|
| `NightstreamFPrime/Export/Stage1/PiDECOrdinarySourceWork.lean` | 17,949 | `00f449536847cbf0fcebc445ff09d6efd45fe7e5260607177bc2453f0df94e83` |
| `NightstreamFPrime/Spec/Folding/Nifs/NonInteractive/PiRlcSampler/FieldDecoderFiberCount.lean` | 23,610 | `460f2fb881f174eccbf24a904535fc442675a71f68777fda9f94eddfcf8a87d5` |
| `NightstreamFPrime/Lifecycle/PiRLC/v1_1/SamplerFiberCount.lean` | 6,612 | `16d07b7a165590720b130e63d430cdb887ab76b3c6d4aa17d04b4cbd501c80cf` |
| `tests/AxiomsNifsClosure.lean` | 42,363 | `25809724cae7840156f758d247f3efbf88ff4957f302d3b5b280c777e4e878cb` |

| Record under `/tmp/` | SHA-256 |
|---|---|
| `nightstream-nifs-rows-fibers-axioms-1.log` | `fc24b13e362c1decf87a4cddebba76a1cc5a0044793127e9bb8138ede884cab4` |
| `nightstream-nifs-rows-fibers-code-files.json` | `8b8a23e4e2f861bb50168ae3471a899cc209fd93b7e9915d4f731de4e77d8e24` |
| `nightstream-nifs-rows-fibers-static-1.log` | `ad9e1e52d1607f377312108c20dbf84566406a2fdee0bfc46b65be21824f33e0` |
| `nightstream-nifs-sampler-fiber-count-2.log` | `2918ff6955050033df75d1bd3a31ebd19e94a8952bd6ba1709ebd072817fe56c` |
| `nightstream-nifs-pidec-ordinary-source-work-3.log` | `a5a9f97e721346e60d0edac2b4bb489af3aa502f429b2c9d7160f90ad28ae9af` |
