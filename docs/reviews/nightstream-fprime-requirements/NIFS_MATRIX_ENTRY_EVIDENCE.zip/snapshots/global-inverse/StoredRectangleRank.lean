import NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.FieldPreimageRectangle
import NightstreamFPrime.Spec.Folding.PiRLC.PaperForkExtractionWork

/-!
Direct arithmetic rank/unrank for one of the four decoder rectangles.
The values refine the existing rectangle equivalence. The named clock
counts calls, projections, arithmetic, literals, dispatch and constructors;
proofs and clock instrumentation are excluded. No random input law is assumed.
-/

namespace NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredRectangleRank

open ProductionAlphabet FieldPairLaw FieldPreimageRectangle
open _root_.NightstreamFPrime.Spec.Folding.PiRLC.PaperForkExtractionWork (Result)

private def classSize : ChunkClass → Result Nat
  | .reject => ⟨1, 3⟩
  | .residue _ => ⟨acceptedQuotientCount, 3⟩
  | .accepted => ⟨rejectionBucket, 3⟩
  | .all => ⟨chunkModulus, 3⟩

private theorem classSize_value (kind : ChunkClass) : (classSize kind).value = kind.size := by
  cases kind <;> rfl

private theorem classSize_work (kind : ChunkClass) : (classSize kind).work = 3 := by
  cases kind <;> rfl

private theorem classSize_pos (kind : ChunkClass) : 0 < kind.size := by
  cases kind <;> decide

private def classUnrank (kind : ChunkClass) (index : Fin kind.size) : Result Chunk :=
  match kind with
  | .reject => ⟨⟨rejectionBucket, by decide⟩, 4⟩
  | .residue digit =>
      let i := index.val
      let d := digit.val
      ⟨⟨i * alphabetSize + d, by
        have bound : i < acceptedQuotientCount := index.isLt
        have digitBound : d < alphabetSize := digit.isLt
        unfold acceptedQuotientCount alphabetSize chunkModulus at bound digitBound ⊢
        omega⟩, 9⟩
  | .accepted =>
      ⟨⟨index.val, by
        have bound := index.isLt
        change index.val < rejectionBucket at bound
        have : rejectionBucket < chunkModulus := by decide
        omega⟩, 4⟩
  | .all => ⟨index, 2⟩

private theorem classUnrank_value (kind : ChunkClass) (index : Fin kind.size) :
    (classUnrank kind index).value = (kind.indexEquiv index).val := by
  apply Fin.ext
  rw [ChunkClass.index_value]
  cases kind <;> rfl

private theorem classUnrank_work (kind : ChunkClass) (index : Fin kind.size) :
    (classUnrank kind index).work ≤ 9 := by
  cases kind with
  | reject => change (4 : Nat) ≤ 9; decide
  | residue _ => change (9 : Nat) ≤ 9; decide
  | accepted => change (4 : Nat) ≤ 9; decide
  | all => change (2 : Nat) ≤ 9; decide

private def classRank (kind : ChunkClass) (chunk : Chunk) : Result Nat :=
  match kind with
  | .reject => ⟨0, 3⟩
  | .residue _ => ⟨chunk.val / alphabetSize, 5⟩
  | .accepted => ⟨chunk.val, 3⟩
  | .all => ⟨chunk.val, 3⟩

private theorem classRank_value (kind : ChunkClass) (chunk : Chunk)
    (member : kind.Member chunk) :
    (classRank kind chunk).value = (kind.indexEquiv.symm ⟨chunk, member⟩).val := by
  cases kind <;> rfl

private theorem classRank_unrank (kind : ChunkClass) (index : Fin kind.size) :
    (classRank kind (kind.indexEquiv index).val).value = index.val := by
  rw [classRank_value kind _ (kind.indexEquiv index).property]
  exact congrArg Fin.val (kind.indexEquiv.symm_apply_apply index)

private theorem classRank_work (kind : ChunkClass) (chunk : Chunk) :
    (classRank kind chunk).work ≤ 5 := by
  cases kind <;> simp only [classRank] <;> decide

private theorem commonCoordinates (low high : ChunkClass)
    (block : Fin (pairModulus - 1)) (li : Fin low.size) (hi : Fin high.size) :
    let pair := li.val + low.size * hi.val
    let rank := pair + (low.size * high.size) * block.val
    rank < (pairModulus - 1) * (low.size * high.size) ∧
    rank / (low.size * high.size) = block.val ∧
    rank % (low.size * high.size) = pair ∧
    pair % low.size = li.val ∧ pair / low.size = hi.val := by
  dsimp only
  have lp := classSize_pos low
  have hp := classSize_pos high
  have areaPositive := Nat.mul_pos lp hp
  have pairBound : li.val + low.size * hi.val < low.size * high.size := by
    have := li.isLt
    have := hi.isLt
    nlinarith
  have rankBound : li.val + low.size * hi.val + (low.size * high.size) * block.val <
      (pairModulus - 1) * (low.size * high.size) := by
    have := block.isLt
    nlinarith
  refine ⟨rankBound, ?_, ?_, ?_, ?_⟩
  · rw [Nat.add_mul_div_left _ _ areaPositive, Nat.div_eq_of_lt pairBound, Nat.zero_add]
  · rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt pairBound]
  · rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt li.isLt]
  · rw [Nat.add_mul_div_left _ _ lp, Nat.div_eq_of_lt li.isLt, Nat.zero_add]

/-- Decode one local rank. Common coordinates use low, high, then block.
The common branch has 32 local operations plus its four callees; the extra
branch has 17 local operations plus the two size callees. -/
def unrank (low high : ChunkClass) (rank : Fin (size low high)) : Result F :=
  let ls := classSize low
  let hs := classSize high
  let l := ls.value
  let h := hs.value
  let area := l * h
  let blocks := pairModulus - 1
  let common := blocks * area
  let r := rank.val
  if inside : r < common then
    have areaPositive : 0 < area := by
      simpa only [area, l, h, ls, hs, classSize_value] using
        Nat.mul_pos (classSize_pos low) (classSize_pos high)
    have lowPositive : 0 < l := by simpa only [l, ls, classSize_value] using classSize_pos low
    let block := r / area
    let pair := r % area
    let li := pair % l
    let hi := pair / l
    have blockBound : block < pairModulus - 1 := (Nat.div_lt_iff_lt_mul areaPositive).mpr inside
    have pairBound : pair < area := Nat.mod_lt _ areaPositive
    let lo := classUnrank low ⟨li, by
      have bound := Nat.mod_lt pair lowPositive
      simpa only [li, l, ls, classSize_value] using bound⟩
    let highChunk := classUnrank high ⟨hi, by
      have bound : hi < h := (Nat.div_lt_iff_lt_mul lowPositive).mpr (by
        simpa only [area, Nat.mul_comm] using pairBound)
      simpa only [h, hs, classSize_value] using bound⟩
    let lowValue := lo.value
    let highValue := highChunk.value
    let word := lowValue.val + chunkModulus * highValue.val
    let value := word + pairModulus * block
    ⟨⟨value, by
      have lb := lowValue.isLt
      have hb := highValue.isLt
      have wordBound : word < pairModulus := by
        unfold word pairModulus
        nlinarith
      have modulus := goldilocks_decomposition
      unfold value
      nlinarith⟩, ls.work + hs.work + lo.work + highChunk.work + 32⟩
  else
    ⟨⟨goldilocksModulus - 1, by have : 0 < goldilocksModulus := by decide; omega⟩,
      ls.work + hs.work + 17⟩

theorem unrank_value (low high : ChunkClass) (rank : Fin (size low high)) :
    (unrank low high rank).value = (rectangleEquiv low high rank).val := by
  rcases rank_cases low high rank with ⟨block, li, hi, rfl⟩ | ⟨bothZero, rfl⟩
  · have coordinates := commonCoordinates low high block li hi
    dsimp only at coordinates
    apply Fin.ext
    rw [common_unrank_value]
    simp only [unrank, classSize_value, common_rank_value, dif_pos coordinates.1,
      coordinates.2.1, coordinates.2.2.1, coordinates.2.2.2.1,
      coordinates.2.2.2.2, classUnrank_value]
  · apply Fin.ext
    rw [extra_unrank_value]
    simp only [unrank, classSize_value, extra_rank_value, lt_self_iff_false, dif_neg]

theorem unrank_member (low high : ChunkClass) (rank : Fin (size low high)) :
    Member low high (unrank low high rank).value := by
  rw [unrank_value]
  exact (rectangleEquiv low high rank).property

theorem unrank_work_le (low high : ChunkClass) (rank : Fin (size low high)) :
    (unrank low high rank).work ≤ 56 := by
  have commonWork (li : Fin low.size) (hi : Fin high.size) :
      (classSize low).work + (classSize high).work +
        (classUnrank low li).work + (classUnrank high hi).work + 32 ≤ 56 := by
    have left := classUnrank_work low li
    have right := classUnrank_work high hi
    rw [classSize_work, classSize_work]
    omega
  unfold unrank
  dsimp only
  split
  · exact commonWork _ _
  · rw [classSize_work, classSize_work]
    decide

private def rawRank (low high : ChunkClass) (field : F) : Result Nat :=
  let ls := classSize low
  let hs := classSize high
  let l := ls.value
  let h := hs.value
  let area := l * h
  let blocks := pairModulus - 1
  let common := blocks * area
  let value := field.val
  if value = goldilocksModulus - 1 then
    ⟨common, ls.work + hs.work + 16⟩
  else
    let lo : Chunk := ⟨value % chunkModulus, Nat.mod_lt _ (by decide)⟩
    let hi : Chunk := ⟨(value / chunkModulus) % chunkModulus, Nat.mod_lt _ (by decide)⟩
    let block := value / pairModulus
    let lr := classRank low lo
    let hr := classRank high hi
    let li := lr.value
    let highIndex := hr.value
    let pair := li + l * highIndex
    let rank := pair + area * block
    ⟨rank, ls.work + hs.work + lr.work + hr.work + 34⟩

private theorem commonFieldCoordinates (block : Fin (pairModulus - 1))
    (lo hi : Chunk) :
    let word := lo.val + chunkModulus * hi.val
    let field := word + pairModulus * block.val
    field ≠ goldilocksModulus - 1 ∧ field / pairModulus = block.val ∧
      field % chunkModulus = lo.val ∧ (field / chunkModulus) % chunkModulus = hi.val := by
  dsimp only
  have positive : 0 < chunkModulus := by decide
  have pairPositive : 0 < pairModulus := by decide
  have wordBound : lo.val + chunkModulus * hi.val < pairModulus := by
    have := lo.isLt
    have := hi.isLt
    unfold pairModulus
    nlinarith
  have wholeBound : lo.val + chunkModulus * hi.val + pairModulus * block.val <
      goldilocksModulus - 1 := by
    have := block.isLt
    rw [goldilocks_decomposition, Nat.add_sub_cancel]
    nlinarith
  refine ⟨Nat.ne_of_lt wholeBound, ?_, ?_, ?_⟩
  · rw [Nat.add_mul_div_left _ _ pairPositive, Nat.div_eq_of_lt wordBound, Nat.zero_add]
  · have expanded : lo.val + chunkModulus * hi.val + pairModulus * block.val =
        lo.val + chunkModulus * (hi.val + chunkModulus * block.val) := by
      unfold pairModulus
      ring
    rw [expanded, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt lo.isLt]
  · have expanded : lo.val + chunkModulus * hi.val + pairModulus * block.val =
        lo.val + chunkModulus * (hi.val + chunkModulus * block.val) := by
      unfold pairModulus
      ring
    rw [expanded, Nat.add_mul_div_left _ _ positive, Nat.div_eq_of_lt lo.isLt,
      Nat.zero_add, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hi.isLt]

private theorem rawRank_unrank (low high : ChunkClass) (rank : Fin (size low high)) :
    (rawRank low high (rectangleEquiv low high rank).val).value = rank.val := by
  rcases rank_cases low high rank with ⟨block, li, hi, rfl⟩ | ⟨bothZero, rfl⟩
  · have coordinates := commonFieldCoordinates block
      (low.indexEquiv li).val (high.indexEquiv hi).val
    dsimp only at coordinates
    have lowSame : (⟨((rectangleEquiv low high
        (commonRank low high block li hi)).val.val) % chunkModulus,
        Nat.mod_lt _ (by decide)⟩ : Chunk) = (low.indexEquiv li).val := by
      apply Fin.ext
      rw [common_unrank_value]
      exact coordinates.2.2.1
    have highSame : (⟨(((rectangleEquiv low high
        (commonRank low high block li hi)).val.val) / chunkModulus) % chunkModulus,
        Nat.mod_lt _ (by decide)⟩ : Chunk) = (high.indexEquiv hi).val := by
      apply Fin.ext
      rw [common_unrank_value]
      exact coordinates.2.2.2
    have notExtra : (rectangleEquiv low high (commonRank low high block li hi)).val.val ≠
        goldilocksModulus - 1 := by rw [common_unrank_value]; exact coordinates.1
    have blockSame : (rectangleEquiv low high (commonRank low high block li hi)).val.val /
        pairModulus = block.val := by rw [common_unrank_value]; exact coordinates.2.1
    simp only [rawRank, classSize_value, if_neg notExtra, lowSame, highSame, blockSame,
      classRank_unrank, common_rank_value]
  · simp only [rawRank, classSize_value, extra_unrank_value, if_pos rfl, extra_rank_value]

private theorem rawRank_value (low high : ChunkClass) (field : F) (member : Member low high field) :
    (rawRank low high field).value = ((rectangleEquiv low high).symm ⟨field, member⟩).val := by
  have inverse := (rectangleEquiv low high).apply_symm_apply ⟨field, member⟩
  have result := rawRank_unrank low high ((rectangleEquiv low high).symm ⟨field, member⟩)
  simpa only [inverse] using result

private theorem rawRank_work (low high : ChunkClass) (field : F) :
    (rawRank low high field).work ≤ 50 := by
  have commonWork (lo hi : Chunk) :
      (classSize low).work + (classSize high).work +
        (classRank low lo).work + (classRank high hi).work + 34 ≤ 50 := by
    have left := classRank_work low lo
    have right := classRank_work high hi
    rw [classSize_work, classSize_work]
    omega
  unfold rawRank
  dsimp only
  split
  · rw [classSize_work, classSize_work]
    decide
  · exact commonWork _ _

/-- Four wrapper operations: call, value projection, Fin and Result. -/
def rank (low high : ChunkClass) (field : F) (member : Member low high field) :
    Result (Fin (size low high)) :=
  let value := rawRank low high field
  ⟨⟨value.value, by
    rw [rawRank_value low high field member]
    exact ((rectangleEquiv low high).symm ⟨field, member⟩).isLt⟩, value.work + 4⟩

theorem rank_value (low high : ChunkClass) (field : F) (member : Member low high field) :
    (rank low high field member).value = (rectangleEquiv low high).symm ⟨field, member⟩ := by
  apply Fin.ext
  exact rawRank_value low high field member

theorem rank_work_le (low high : ChunkClass) (field : F) (member : Member low high field) :
    (rank low high field member).work ≤ 54 := Nat.add_le_add_right (rawRank_work low high field) 4

theorem rank_unrank (low high : ChunkClass) (index : Fin (size low high)) :
    (rank low high (unrank low high index).value (unrank_member low high index)).value = index := by
  rw [rank_value, unrank_value]
  exact (rectangleEquiv low high).symm_apply_apply index

theorem unrank_rank (low high : ChunkClass) (field : F) (member : Member low high field) :
    (unrank low high (rank low high field member).value).value = field := by
  rw [unrank_value, rank_value]
  exact congrArg Subtype.val ((rectangleEquiv low high).apply_symm_apply ⟨field, member⟩)

end NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredRectangleRank
