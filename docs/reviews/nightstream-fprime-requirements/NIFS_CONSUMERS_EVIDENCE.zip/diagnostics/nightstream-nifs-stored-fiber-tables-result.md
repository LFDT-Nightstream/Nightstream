# Stored decoder-fiber tables: checked result

Worker 2, 2026-09-10. The complete two-file criterion passed its third full
check. Both active source files are frozen. The coordinator runs all builds
and owns the combined audit and milestone. No Lean or Rust command was run
by this worker.

## Exact checked source

All paths below are relative to
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime`.

| Owner | Lines | Bytes | SHA-256 |
| --- | ---: | ---: | --- |
| `Spec/Folding/Nifs/NonInteractive/PiRlcSampler/StoredFiberTables.lean` | 552 | 29211 | `12a3abb502c9d4f0a4e0aabab8cc20de3b3ae55082eb7c82cdf9c37b4c31322d` |
| `Lifecycle/PiRLC/v1_1/StoredSamplerFiberTables.lean` | 55 | 2724 | `a96bb90fa216c727cb4a732e76448734dfb3b64e43b31ba10d0a48aeb6fd8ee3` |

These hashes identify source bytes. They are not mathematical authority.
The proof authority is the checked source and its permitted-axiom audit.

## Complete contract

The input is an actual stored `Vector Coefficient 54`. The program builds an
actual stored vector of 33 rows, each with 55 paired success/abort cells.
The dimensions derive from the selected 32 field lanes and 54 output symbols.
No caller-supplied function with free access substitutes for the input array.

For every level `n < 33` and index `j < 55`, the returned cell has exactly

```text
success = successCount n ((List.ofFn target.get).drop j)
aborts  = abortCount n (54 - j).
```

The proof uses the existing complete `FieldDecoderFiberCount` recurrences.
It includes level zero and the saturated column. At `j = 54`, success is
`q^n` and abort is zero. At one missing symbol, success in the low candidate
leaves the high candidate unrestricted. With two or more missing symbols,
the recurrence keeps the low/high order. Abort counting permits every
accepted digit; it does not require a failed prefix to match the target.

The raw-zero bonuses refer to alphabet index zero, whose balanced value is
-2. They do not refer to balanced field zero. Thus the extra field preimage
`q-1` of raw pair `(0,0)` is counted in the correct success and abort classes.
The complete unused field suffix remains part of each fiber.

Success and abort events are disjoint. Their sum is at most `q^n` at every
stored cell. All selected stored sums are less than `2^2048`, from
`q < 2^64` and `n <= 32`. Each of the six recurrence weights, including its
maximum raw-zero bonus where applicable, is at most `q`.

The structural positivity theorem proves `successCount n target > 0` when
`target.length <= 2*n`. Hence every complete 54-symbol target has a positive
successful 32-field fiber. A separate theorem proves a positive abort count
when at least one accept is needed, using the all-rejection branch.

The Lifecycle consumer proves the exact cardinality for the existing
comparison-only scalarwise totalization, for an arbitrary valid fallback:

```text
card {fields | totalizedFieldDecode fallback fields = target.get}
  = initial.success + [target.get = fallback] * initial.aborts.
```

It also proves that this cardinality is positive and less than `2^2048`.
Fallback equality occurs in theorem statements. No executable comparison of
function-valued scalars is charged as a free operation. Actual sampling still
aborts; no equality of failed protocol states is asserted.

## Named-work result and corrected clock

The derived build bound is **425407 named operations**. One stored table read
has a separate exact cost of seven operations. Constructing the stored input
from an external representation and calling the public programs remain caller
work.

The clock counts arithmetic, dispatch, calls, value/index projections,
executed literals/constants, and constructors. It excludes proof terms,
local variable references, and work-counter reads and arithmetic.
An arithmetic operation acts on a `Nat`; this is not a machine-bit cost.

The independent review found that round 1 omitted executed literal/constant
charges. The coordinator accepted the following correction before round 2:

| Program or branch | Old charge | Checked charge |
| --- | ---: | ---: |
| makeWeights | 13 | 25 |
| baseCell | 5 | 8 |
| stepCell: saturated / one left / at least two left | 9 / 26 / 45 | 12 / 31 / 53 |
| empty row/table prefix | capacity+4 | capacity+5 |
| row-prefix step | capacity+2*prefix+13 | unchanged |
| baseRow / nextRow wrapper | 3 / 4 | 4 / 5 |
| table-prefix step | capacity+2*prefix+18 | capacity+2*prefix+20 |
| build wrapper | 6 | 7 |
| read | 7 | unchanged |

`Array.emptyWithCapacity` is one named allocation primitive. The reserved-slot
allowance is additional; there is no separate invented allocator call. The
empty-prefix charge consists of dispatch, the capacity literal, allocation,
Vector construction, and Result construction, plus reserved slots.

Each push has allowance `capacity + 2*prefixLength + 3`. This covers the call,
possible allocation and reserved slots, a read/write for each copied entry,
and the appended write. Stored table copies move row references, and stored
row copies move cell references; they do not copy every integer limb. The
bound does not assume uniqueness or an in-place compiler optimization.

The complete derivation is:

```text
rowPrefixBound(55)   = 55+5 + 55*(53 + 3*55 + 13) = 12765
rowWork             = 12765 + 5                  = 12770
tablePrefixBound(33)= 33+5 + 33*(12770+3*33+20)   = 425375
buildWork           = 25 + 425375 + 7            = 425407.
```

The independent count review is retained at
`/tmp/nightstream-nifs-stored-fiber-tables-review.md`.

## All three full checks

Each invocation targeted both files through the complete Lifecycle consumer:

```bash
timeout --signal=KILL 1500s bash scripts/validate.sh build NightstreamFPrime.Lifecycle.PiRLC.v1_1.StoredSamplerFiberTables
```

The coordinator ran this command from
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime`.

| Round | Terminal result | Retained log and scope |
| --- | --- | --- |
| 1 | exit 1; Spec 35 s | `/tmp/nightstream-nifs-stored-fiber-tables-1.log`; explicit array bounds, Nat normalization, dependent vector casts, and row-prefix proof expansion failed; consumer not reached |
| 2 | exit 1; Spec 34 s | `/tmp/nightstream-nifs-stored-fiber-tables-2.log`; prior value/index errors were resolved; two local stepCell clock tactics failed; consumer not reached |
| 3 | exit 0; Spec 33 s, consumer 1.4 s, wrapper 35 s | `/tmp/nightstream-nifs-stored-fiber-tables-3.log`; complete target passed, 2434 jobs |

The final clock proof changes its three goals to the explicit numeric
inequalities `12 <= 53`, `31 <= 53`, and `53 <= 53` after branch selection.
The prefix proofs use their private structural interfaces before closing the
concrete dimensions. No counter setting was increased, no narrower criterion
was substituted, and no fourth check was run. The final log retains ordinary
linter warnings. No claim of a one-second Spec check is made.

Failed source records remain unchanged:

- `/tmp/nightstream-nifs-stored-fiber-tables-round-1.lean`, SHA-256
  `5623d084e39d6e93b127816d25699d359f051a51ac4e14e0a0198f4af8adc6c8`;
- `/tmp/nightstream-nifs-stored-fiber-tables-round-2.lean`, SHA-256
  `6f483f570668325ce67fd41adeebc252eab73e5cb0b7e35b0bd4b049d5d452f8`;
- `/tmp/nightstream-nifs-stored-sampler-fiber-tables-round-1.lean`, identical
  to the final consumer, SHA-256
  `a96bb90fa216c727cb4a732e76448734dfb3b64e43b31ba10d0a48aeb6fd8ee3`.

All 15 exports are registered by the coordinator. The combined audit with
402 records was running when this note was written; this note does not claim
its result in advance.

Spec exports: `count_sum_le`, `successCount_pos`, `abortCount_pos`,
`field_window_count_lt_twoPow2048`, `build_value`, `build_work_le`,
`build_sum_le`, `build_sum_lt_twoPow2048`, `recurrence_weights_le_modulus`,
`read_work`, `read_build_value`, `initial_success_pos`.

Lifecycle exports: `fiber_card`, `fiber_positive`, `fiber_lt_twoPow2048`.

## Remaining inverse and security obligations

The stored table proves counts and supplies positive exact normalizers. The
global 32-field weighted rank/unrank program, its partition and inverse
proofs, and its full stored-access/copy/arithmetic work remain open. Its
fallback branch must select from successful fallback windows and unrestricted
aborting windows as separate disjoint parts. It must preserve field order,
candidate order, and all unused suffix choices.

An exact `UniformBelow(N)` primitive still needs an explicit distribution and
time contract. The positive bound `0 < N < 2^2048` does not prove an unbiased
random generator or a worst-case bit-time bound. Exact conditional uniformity
on each complete fiber still needs proof. No arbitrary retry or query limit
is introduced.

For the selected 17-scalar batch, the global inverse still needs the product
fiber bijection, normalizer, conditional product law, and work accounting.
The existing forward comparison bounds do not supply these inverse proofs.
They also do not assign an independent field distribution to Poseidon2.

A uniform-fiber kernel resamples a uniform raw source when its output is
drawn from that source's actual decoded distribution. Feeding it a uniform
Scalar instead need not give uniform raw fields when fiber sizes differ;
the forward bias remains relevant. Joint resampling and complete-query cache
consistency still need proof for the cited Fiat-Shamir simulation.

The totalization is a comparison device. The coordinator separately owns the
actual-to-comparison acceptance adapter in `Lifecycle/Nifs/TotalizedComparison`
and its application consumer; this table result does not replace that work.
The exact overwrite-versus-additive absorption match, schedule and encoding
match to the cited security theorem, classical state-restoration knowledge
argument, and approved concrete Poseidon2/oracle transfer premise remain open.
This result selects no model and proves no Fiat-Shamir applicability, runtime
gas bound, random inverse, or proof-backend property.

Coordinator final gate: the combined NIFS audit passed with terminal exit 0, 402 complete records, 24 additions, only permitted axioms, 3763 jobs and 3 seconds. Static passed with terminal exit 0. The code is committed as 286dc71a543d28d52e430e9466ab5cecea01de7d. The exact logs are nightstream-nifs-consumers-axioms-1.log and nightstream-nifs-consumers-static-1.log.
