# Pre-pin optimized nonzero C/R/D parity result

The bounded phase-parity criterion passed. Only two isolated source files changed: the C/R driver now reads package identity from the loaded candidate binding, and the existing complete D checker has an optimized-only test entry. The old optional PaperExact comparison remains in its old test; no executed command selected it. No arithmetic implementation, producer, feature, environment input, profile, or production pin was added or changed by this patch.

The strict schema conversion passed in0.15s. It consumed every framed preimage word, checked public digest encoding and semantic block order, verified complete C-to-R and R-to-D input equality, and wrote only the converted comparison inputs. It did not synthesize expected arithmetic or run a prover.

Every gate passed on its first attempt:

| Gate | Full command seconds | Peak RSS KiB |
|---|---:|---:|
| Lean C input/result |8.74|3699496|
| Optimized Rust C |65.38|3383244|
| Lean cumulative C/R |15.17|3713588|
| Optimized Rust C/R + R mutations |20.18|3383800|
| Lean cumulative C/R/D |15.93|3712648|
| Optimized D complete parity + D mutations |72.38|3390452|

The Rust C command includes45.65s compilation; its verifier/data body was19.526s. D includes50.92s compilation; the test took21.42s. All native invocations used outer300s, and all Lean invocations used outer1500s, under the project policy. No source repair was needed during these gates.

C compared all15 complete phase fields. R compared the exact C handoff, all17 coefficient vectors/membership decisions/indexed combinations, parent and endpoint; its existing native mutations rejected. D compared every result family: accepted/bounded flags,16 digit vectors and ranges, all recompositions/equations, all child claims, endpoint and unbounded-parent rejection. It also checked the transition-ready preimage/hash, normal D verification, strict parent-B rejection, and every existing child commitment/public/point/Pad/matrix/shape/padding/digest/range mutation. The cumulative Lean outputs were separately checked against the emitted C/R/D fixtures and returned child family.

These are nonzero phase fixtures used as comparison data. They do not establish an actual full native prover run or witness-opening validity. That post-pin task remains separate. Main/bootstrap source and production identity pins were not edited. The build queue is released to root.

Exact commands, frozen source/output hashes, timings and log paths are retained in `/tmp/nightstream-unused-optimized-parity-result.json`; the two-file patch is `/tmp/nightstream-unused-optimized-parity.patch`.
