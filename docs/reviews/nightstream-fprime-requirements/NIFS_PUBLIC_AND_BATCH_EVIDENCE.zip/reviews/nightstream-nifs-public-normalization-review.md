# Independent stored public-check and normalization review

Reviewer: Worker 3 (`/root/conformance_review`), independent of the authors
of the reviewed Lean changes. Date: 2026-09-10.

No defect was found in the stated value or named-operation work claims.
The selected public-check premise is now discharged. The selected witness
checker still requires the two explicit commitment and CCS matrix-entry
contracts. The inverse module proves input normalization only.

This is a source review of frozen working files on parent commit
`97ec58522e587885d0da3154cfb752d18088ab92`. The hashes below identify the
actual reviewed contents; they do not establish protocol authority. This
record does not extend the original immutable `773f3d0f` review. No active
source was edited, and this reviewer ran no build, test, prover, backend or
PaperExact command. `FieldInverseWork` was being repaired and is excluded.

## Source identities

Paths in this table are relative to
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/`.

| Source | Lines | SHA-256 |
|---|---:|---|
| `Export/Stage1/PiCCSStoredPublicCheck.lean` | 949 | `34bda7bfa09bdc55a48bce92b2a4e12e63662c69ebbbd8976f726b5637540bf7` |
| `Export/Stage1/PiCCSStoredWitnessCheck.lean` | 358 | `7b1b92821e25fc76e7af47293860b39bc1941e22e4dbcbc2986a47ac26e3d9e9` |
| `Spec/Phi81Relation/EvaluationHomomorphism/StoredRingInverseWork.lean` | 185 | `3fb5b694bbae9a5cb5d25ad5034d8d51ad3c9f17bdbaaf2eaacc3064f2912e04` |
| `Export/Stage1/PiCCSInputCheck.lean` — statement and formula dependency | 569 | `cd46da12f09769fd36807dace85a2b046a33c0dcf60337fb9ac2d17695cf15a7` |
| `Spec/Folding/PiCCS/PaperJoint/StoredProbe.lean` — storage dependency | 75 | `591110514bc5bd3382edd413dfcdfbdb9bda6231b83d35b1548a37c0b1df8050` |
| `Spec/Phi81Relation/EvaluationHomomorphism/StoredRingInverse.lean` — executed constructor dependency | 95 | `9da9fca9ed9388cbd9be6b5991e8c4f5932c66a1ea46bbadd034d7f394cb4f62` |
| `Spec/ProductionRelation/SelectivePolynomial.lean` — retained term table | 410 | `c559ef308489964f477093c32711f1ce372d82c5636c75202b9ea22ef6122c03` |

The complete three primary files were read. Relevant storage, selected
statement, raw SumCheck, work-driver and upstream normalization definitions
were also checked. The source identities above were read again after the
review and were unchanged.

## Complete public check

`PiCCSStoredPublicCheck.check_value` at line 925 equates the value of the
executed counted check to `ProtocolPolynomial.FixedWidth.check extensionOps
9`, on the same input, coins, output coefficients and raw certificate.
`check_work_le` at line 937 applies to every `Input` and `StoredProbe`.
Neither theorem assumes an honest output, a successful certificate decode,
an opening, a unit, or a particular challenge value.

The domain is precise. The points carry proofs of dimension 28, and the
stored output arrays have the selected dimensions: 17 sources, separate
54-coefficient Pad rows, and 14 matrix families with 54 coefficients each.
Malformed output-array dimensions are excluded by these types. The raw
certificate remains an unrestricted finite list of messages, each with an
unrestricted finite coefficient list. The theorems include missing and
excess rounds, missing and excess coefficients, false round identities,
false terminal identities, and valid high zero coefficients at width 10.
They do not measure byte decoding or the construction of these stored values.

The rejection path was checked in the source:

- `exactLength` (lines 64–90) reads only the required prefix and one final
  constructor. Its value equals the full length test, but its execution
  does not call `List.length`.
- `checkRounds` (lines 128–230) consumes the verifier's challenge list.
  It requires exactly 10 coefficients before calling any Horner evaluator.
  An excess round rejects when the challenge list is empty. It does not
  traverse the excess tail.
- `checkRounds_value` proves equality to the existing raw decode/check
  predicate for arbitrary messages. The proof's references to
  `RawCertificate.decodeRounds` are semantic proof steps; the executed
  function does not call that full-list decoder.
- `check` (lines 907–920) computes the fixed-size initial and terminal
  claims and then checks the raw rounds. Thus even an immediate malformed
  certificate incurs those claim costs. The public bound includes them.

The initial and final polynomial formulas retain the selected ordering.
`padHorner` visits coefficient then running-source coordinates;
`matrixHorner` visits coefficient, matrix, then running-source coordinates.
Their value lemmas (lines 386–404) identify the existing canonical lists.
Pad is a separate family. The matrix fold includes all 14 matrices.
The terminal weights 864 and 12960 are the selected offsets
`16 * 54` and `16 * 54 + 16 * 14 * 54`. The one fresh source and all 17
norm terms are retained. `terminalClaim_value` at line 871 reaches the
existing `terminalFast_eq_paper` equality without a new formula premise.

`outputMessage` at line 464 is a semantic view. The algorithm reads the
candidate's stored arrays through `padRead` and `matrixRead`. It does not
substitute `Input.evalK`, `Input.evalA` or `Input.rounds` for the returned
probe. Prior claims and the prior point come from the input's running arrays.
The candidate coins are explicit. This check neither generates transcript
challenges nor proves their distribution or prior-state authentication.

## Public-check traversal and work

The work model is the existing named-operation model of
`StoredWitnessCheckWork`, not wall time. It counts field operations,
record/array reads, loop control, index movement and result construction.
The checked source equations include:

| Call | Returned work or proved bound |
|---|---:|
| Extension addition / multiplication | 8 / 13 |
| Horner evaluation of `n` coefficients | `25*n + 3` |
| One width-10 round identity and next claim | at most 781 |
| Exact-width scan at width 10 | at most 53 |
| Raw check with `r` verifier challenges | at most `849*r + 13` |
| Stored prior-point list of length `n` | `7*n + 3` |
| Point equality with left length `n` | at most `73*n + 4` |
| Selected public check | at most 1,435,806 |

The final numeral is arithmetic expansion of `workBound` at line 934,
not a measured runtime or a new acceptance limit. Its components are
475,210 for the initial claim, 936,804 for the terminal claim, 23,785 for
the 28-round check, and seven surrounding reads/returns.

The folds use `Fin.foldl`, whose Lean 4.30 implementation has a direct
numeric index (`Init/Data/Fin/Fold.lean:27`). `foldRight` reverses that index;
it does not build coordinate lists or accumulate accessor closures.
The only copied point list uses `List.ofFnM`; its actual implementation is
one `Fin.foldlM` followed by one reverse
(`Init/Data/List/OfFn.lean:40`). The source charge includes both passes.
Prior and candidate coefficient access uses stored `Vector` arrays, not
unpriced calls to arbitrary semantic functions.

The polynomial evaluator traverses the retained 74-term table. The
coefficient and exponent records are read directly. `portRead` charges its
actual branch chain, and `term_exponent_le` derives exponent bounds from
membership in the selected table and its existing total-degree theorem.
It introduces no restriction on a returned probe. The table-to-polynomial
equality is the existing `termData_toMonomial` theorem. The table is fixed
owner data; this call does not charge initial process loading of constants.

These counts are returned with the same computed values, and the value
refinements are proved. No compiled-code cost semantics or end-to-end
extractor runtime theorem follows from the counter equalities alone.

## Selected witness-check use

`PiCCSStoredWitnessCheck.statement_eq_key` at line 69 is a literal equality
to the selected `ProductionKey.key` statement, using the existing logical
relation and `Poseidon2HashChainV1Setup.productionAjtaiKey`.
`publicCheck_value` at line 256 combines that equality with the existing
input projection, the selected Phi81 kernel constant and the new complete
public-check theorem. The degree is the selected degree bound, proved equal
to nine. There is no new relation, profile, commitment map or authority.

`scalarProgram` at line 273 installs the actual public checker and stored
readers. `scalarBounds` at line 284 installs its proved bound.
`scalar_finish_source_iff` at line 295 and `scalar_check_work_le` at line
330 use these concrete links. The latter applies to all candidates,
including rejections. The parent driver executes the public gate before
ambient witness checking and skips that later work when the gate rejects.

Exactly two primitive contracts remain in the selected value/work theorem
interfaces: commitment checking and CCS matrix entry. Their quantifiers
cover arbitrary stored witnesses and all relevant coordinates. The value
contract for commitment checking asks for computation of the actual
commitment equality; it does not assume that the equality is true.
There is no additional public-gate premise or hidden opening-validity
premise. These remaining contracts are open implementation obligations,
not defects in the conditional theorem. This review does not close them.

## Normalization and CompPoly boundary

The inspected local CompPoly checkout is clean at
`050f0bc7e9780703beb8d178ec533e52bd87d649`. No upstream source was changed.
`StoredRingInverseWork` records the Apache-2.0 provenance and authors.
The exact reused algorithm definitions are:

- `CompPoly/Data/Array/Lemmas.lean:147`, reverse nonzero search.
- `CompPoly/Univariate/Raw/Core.lean:66` and `:71`, `lastNonzero` and `trim`.
- `CompPoly/Univariate/Basic.lean:177`, the canonical `ofArray` constructor.
- Lean 4.30 `Init/Prelude.lean:3374`, `Array.extract` and its prefix loop.

The three CompPoly files have SHA-256 values, in the same order:
`3e699da412933149d9f003a4b59f3e85bcba137bc96692ca97ed3393cff588fc`,
`8c276f3a02559c2e40a34bc764375541e9b34bd72e01d515f33666dee82e1e2e`,
and `38d3f305669bdc6379a8d5946a402c29378f489232ec881c922bd4e1e99407f9`.

`scan_value` identifies the descending array scan with the exact upstream
search. `copyLoop_value` identifies the executed copy with the core
`Array.extract.loop`. `trim_value` at line 142 combines these for every raw
array, including empty, zero and arbitrary trailing-zero arrays. It copies
through the last nonzero entry and preserves all earlier zero coefficients.

`copyLoop` charges each array push by `2 * output.size + budget + 8`.
The size is read before the recursive call. The `budget` is the requested
prefix length, not an imposed input limit. The proof invariant is
`output.size + remaining <= budget`. Initial capacity allocation is charged
separately. This is conservative with respect to shared-buffer copies;
it does not assume unique ownership or rely on compiler hoisting.

`trim_work_le` at line 151 proves the symbolic bound
`n*(3*n+8) + 7*n + 14` for raw array size `n`. `encode` constructs the
canonical polynomial from that very counted trim result. `encode_value`
at line 173 proves equality to `StoredRingInverse.encode`, which calls
the pinned `CPolynomial.ofArray` on the same stored 54-coefficient array.
`encode_work_le` at line 178 adds the constructor cost, giving 9,575 named
operations at degree 54. No unit or coprimality premise is required.

This module does not provide a counted complete inverse or change the
executed inverse algorithm. Modulus construction, Euclidean division,
cofactor updates, normalized extended GCD, final monic reduction,
base-field inversion and output coefficient copying remain separate work
obligations. The value equality and structural copy count alone are not a
machine-runtime theorem for CompPoly.

## Checked validation records

The following retained logs were read. Each contains successful completion,
terminal exit zero and no error line. Replayed linter warnings are present.
No validation command was rerun by this reviewer.

| Record under `/tmp/` | Target / reported elapsed | SHA-256 |
|---|---|---|
| `nightstream-nifs-public-gate-resume-2.log` | Public checker, module 2.3s; command 3s | `29ffaa168a5fd0eebe27ce6c975773cd165b763dfb260429a85eedac93abbd1b` |
| `nightstream-nifs-public-gate-integration-1.log` | Selected witness checker, module 1.7s; command 3s | `f35f5b8f89538fd9451d5fe64e337caf9d065634ff2a095e9510f6e1ed16751c` |
| `nightstream-nifs-inverse-normalization-resume-1.log` | Normalization, module 1.5s; command 2s | `44d9ff5ebf2369560368387582fda4480bed8e96fea840d26539452763c685d4` |

All three commands used the retained bounded 1,500-second Lean wrapper.
These are focused compile records. No final combined axiom/static audit
for this milestone was supplied to this review. No new global assumption
is present in the three reviewed source files, but final allowed-axiom
validation remains a separate gate. This finding does not approve broad
Stage 1 closure, a Fiat--Shamir transfer, or full extractor runtime.

## Separate review of four Rust test-only attributes

Worker 3 independently reviewed the root-authored attribute-only delta
after the native NIFS entry was made fail-closed. This section covers only
those four attributes, not an independent review of Worker 3's own guard
or regression implementation. No Rust file was edited during this review.

The full delta in `crates/neo-fold-clean/src/engine/r1cs_circuit/` is:

- `builder.rs:955`: `cfg(test)` on `record_program_range`.
- `builder.rs:1027`: `cfg(test)` on `assign_projection_identity_roles`.
- `builder.rs:1052`: `cfg(test)` on `record_projection_glue`.
- `encoding_trace.rs:856`: `cfg(test)` on `assign_projection_identity_roles`.

No function body, type, field, transcript operation or row-emission
operation changed. The source hashes reviewed are
`bea6f1dcb7a9750b2ad6a4be330ad27035b23e0f0bcb3dbae01b50d60f759111`
for `builder.rs`, and
`05c62d334076e0e48869046a99a863570cbd2ab9a091564e098a9109311852a0`
for `encoding_trace.rs`.

All call sites were checked. Program-range calls are in the now test-only
NIFS inner body/helpers and the already test-only `decider_ce_relation`
module (`paper/mod.rs:118`). Projection role/glue calls are inside the
test-only NIFS `pi_rlc` module. The encoding-trace role setter is called
only from the gated builder setter. These attributes therefore remove
unused private normal-build helpers while preserving their test-build
bodies. No normal-build caller was left without a method.

The retained `/tmp/nightstream-nifs-native-boundary-check-2.log` reports
successful release checking of `neo-fold-clean` and `neo-wasm` in 8.27s;
its SHA-256 is
`846619f1c6e7479db68a233431c51e2ded6a78026926b9dd9df9461b5fb38f99`.
The second format record contains only the existing nightly-only formatter
option warnings. This reviewer ran neither command. No defect was found
in these four attributes. This result does not add a backend execution
claim or close the separate extractor work obligations above.
