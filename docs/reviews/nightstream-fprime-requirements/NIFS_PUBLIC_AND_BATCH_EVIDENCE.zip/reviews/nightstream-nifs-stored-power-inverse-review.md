# Independent stored power-inverse review

Reviewer: Worker 3 (`/root/conformance_review`). Date: 2026-09-10.
The reviewed implementation was authored by the root and Worker 2.
No defect was found in its stated value or named-operation work claims.
No build, test or active source edit was made by this reviewer.

## Source scope

Paths are relative to
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/`.

| Source | SHA-256 |
|---|---|
| `Spec/Phi81Relation/EvaluationHomomorphism/StoredRingPowerInverse.lean` — 207 lines, read in full | `0bd2a8a5bd0c7900ec69d4e9dcee61f6ca3c386e8e4ae3732f4253670701447f` |
| `Spec/Phi81Relation/EvaluationHomomorphism/StoredRingArithmetic.lean` — consumed arithmetic boundary | `b8adc58eb144b8896d007b33034d0ba52ca2194e5813f424fc6c424f61a91e90` |
| `Spec/Phi81Relation/EvaluationHomomorphism/RingFPolynomial.lean` — quotient image boundary | `93a3ea2cbdc43061a3b61b9d0ba22c0b55516f824cf9e5f4887c4e24a8f69c9f` |
| `Spec/Phi81Relation/EvaluationHomomorphism/RingFFrobenius.lean` — power identity dependency | `c268a74b288e82f4a863595a036f996834221e9f37e6000f158192cabc644a92` |

Worker 3 authored the new Frobenius proofs and shared image-interface
changes. This record independently reviews their use by the new inverse,
not those authored proofs themselves. The shared arithmetic has a separate
Worker 2 review; its executed storage/value/work interface was also read
for this consumer check. Hashes identify source and are not authority.

## Exponent, fuel and value

`inverse` at line 183 receives only `StoredRing = Vector F 54`. It computes
`q^27` through the counted `naturalPower` function, subtracts two, and runs
the stored binary-power loop. It receives no inverse, unit witness,
coprimality evidence, oracle output or chosen solution as executable data.

`exponent_bound` at line 127 derives
`q^27 - 2 < 2^(64*27)` from the existing Goldilocks bound `q < 2^64`.
The public loop depth is `64*27+1 = 1729`. The private value theorem proves
`power (fuel+1)` correct when the exponent is below `2^fuel`. Therefore the
public call cannot use the insufficient-fuel identity return on a live
exponent. The extra terminal layer is part of the derived schedule, not an
arbitrary operator limit. Zero exponents terminate with the stored identity.

At each live step, the algorithm computes and stores the square, recurses
with integer division by two, and computes one additional stored product
only for odd exponents. `power_image` proves the even/odd identities in
`RingFPolynomial.QuotientRing`. It uses the actual intermediate arrays.
It does not use the default pointwise multiplication or power instance of
`RingF = Fin 54 -> F`.

`stored_power_product` at line 154 maps the supplied unit equation through
the existing multiplicative image. It then uses the Frobenius unit-product
identity and image injection to recover the actual `ringFMul` equation.
`inverse_mul_value` at line 188 consequently covers every stored input with
an existing `UnitWitness` for the selected `ForkStrongSet.ring`, not only a
particular challenge difference or test case. `inverse_eq_unitInverse` at
line 195 uses associativity and the two-sided unit equations to identify
the unique inverse.

The unit evidence is a correctness premise, not an execution parameter.
No irreducibility, field structure for the quotient, new low-norm theorem,
or new cryptographic premise is introduced. Behavior on nonunits is not
claimed to be an inverse. The algorithm still returns a stored value there.

## Storage and count grouping

Every computed ring value is a 54-coefficient vector. `multiply` constructs
all coefficients using the shared counted array builder, and `one` builds
the stored identity. Input arrays are read without mutation. Squaring passes
the same stored input twice; it does not overwrite that input. The explicit
bindings for square, recursive result and odd product avoid recomputing
their algorithms for coefficient projection. There is no growing tree of
function-valued ring multiplications.

The recursive work grouping follows the executed branches:

- fuel zero returns `one.work + 2`;
- a zero exponent with positive fuel returns `one.work + 5`;
- a live odd step retains square work, recursive work, odd-product work
  and the 16-operation step envelope;
- a live even step retains square work, recursive work and its smaller
  14-operation envelope.

`power_work_le` bounds all private inputs by
`fuel * (2*multiplyWork + 16) + oneWork + 5`. This conservative bound permits
two products at every available layer, including the terminal layer that
does not need them on the selected public call. It does not omit a recursive
product or charge a whole recursive call as one operation.

Exponent construction has returned count `27*4+2 = 110`. The evaluated
wrapper adds eight named operations. At the inspected shared arithmetic
hash, `multiplyWork = 167674` and `oneWork = 382`, so the source expression
`inverseWork` at line 200 expands to 579,844,861. This is a derived upper
bound on the same returned clock, not an executed timing result or limit.
`inverse_work_le` applies to every stored input, with no unit premise.

The clock counts the named natural-number arithmetic calls used for exponent
construction, division, parity and control. Public exponent operands are
bounded by the 1728-bit derivation. Their internal bit-operation costs are
not expanded by this theorem. The clock is not a machine-instruction,
allocator, wall-time or gas theorem. The `irreducible` attributes control
proof elaboration; they do not replace executable operations or add axioms.

## Validation and remaining integration

The retained focused log
`/tmp/nightstream-nifs-stored-ring-power-inverse-3.log` was read in full.
It reports successful build, module time 1.5s, command time 2s, bounded at
1500 seconds with terminal exit zero. Only linter warnings remain. Its
SHA-256 is
`bb8ef07d0ca8045a97c16fc161c908bbd9622bdb7ed1addb3006f09d5dab6e5e`.
The three public theorems are registered in `tests/AxiomsNifsClosure.lean`;
the earlier 328-record audit predates these three additions. No later
combined audit was supplied to this review.

This review supplies no runtime comparison with the existing xgcd candidate.
It also does not install this function in the outer extraction primitives.
That integration must retain the actual scalar input/output storage and
charge any required conversion; an arbitrary coefficient function cannot
receive a constant lookup cost from this result alone. Full extraction,
matrix-entry checking and Fiat--Shamir applicability remain separate goals.
The source is suitable for the next explicit runtime/integration checks;
this finding alone is not adoption or broad conformance approval.

## Follow-up: forced execution comparison

The final comparison source and record were subsequently supplied and
reviewed. This updates the earlier absence of runtime-comparison evidence;
the source review and integration limits above remain unchanged.

`tests/StoredRingPowerInverseComparison.lean` (48 lines) has SHA-256
`af059dfc5468d91d6e87f526365c3bae7731136bc748e66ad4a52c60662f6bea`.
Lines 19–24 place each candidate call as the argument to `IO.Ref.set`
between its start and end timestamps. The result references are created
before those intervals, and validation is performed after both intervals.
This forces the stored result before the end timestamp. The earlier
pure-let timing record is not used as timing evidence.

As a read-only order check, the retained generated C was also inspected.
It places the xgcd call and reference write at lines 284–285 between the
timestamp calls at 280 and 286, and the power call and write at 327–328
between 306 and 329. That C file has SHA-256
`1200888381a9022211f75af5701c7814492a78840e73ff1c4effb44ac93ed2ef`.
This supports the observed operation order; it is not a claim that the
timing log executed that generated C as a separate native binary.

The measured values are from the retained Lean `#eval` comparison:

| Input | xgcd nanoseconds | Counted power nanoseconds |
|---|---:|---:|
| Constant 2 | 17,448,296 | 10,371,750,916 |
| X | 15,131,994 | 10,492,454,722 |
| 1 + X | 150,011,375 | 13,063,242,515 |
| Dense `(1 + X)^53` | 88,147,120 | 13,173,788,970 |

Thus these calls show a large cost difference: approximately 0.015–0.150s
for xgcd and 10.37–13.17s for counted power. They are four observations in
this Lean execution environment, not averages, a deployment benchmark,
or a universal timing bound. The power implementation also computes its
returned clock; the xgcd reference does not have that instrumentation.

The successful vector equality checks every one of the 54 inverse
coefficients. The test then computes `StoredRingArithmetic.multiply` of
the power result and input and checks all 54 product coefficients against
`ringFOne`. It does not separately execute an xgcd product or use a second
independent multiplication implementation. The existing proved
`StoredRingArithmetic.multiply_value` supplies the exact `Spec.ringFMul`
link for that product check. No unit witness is passed into either executed
candidate.

All four returned power clocks are 292,431,123, below the proved bound
579,844,861. Equal recorded clocks do not imply equal elapsed times.
The final log `/tmp/nightstream-nifs-inverse-comparison-3.log` reports
successful completion with module time 48s and terminal exit zero after
50s under the 1500-second Lean cap. Its SHA-256 is
`8a68f8fcb038f089425d3abbcf435b67bdfcd0781ba96e9707e79fcee4a4218c`.
No command was rerun by this reviewer.

The validated stored-power candidate remains separate from the existing
inverse path. Selection, the complete outer representation/refinement link,
and any final audit after these additions remain open in this record.
