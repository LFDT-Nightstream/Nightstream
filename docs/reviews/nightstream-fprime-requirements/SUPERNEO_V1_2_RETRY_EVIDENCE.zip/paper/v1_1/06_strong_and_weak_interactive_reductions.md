# 6 Strong and weak interactive reductions

**Definition 16 (Weak Interactive Reductions).** Consider relations  $\mathcal{R}_1$ ,  $\mathcal{R}'_1$ , and  $\mathcal{R}_2$  over public parameters, structure, instance, and witness tuples such that  $\mathcal{R}_1 \subseteq \mathcal{R}'_1$ . Let  $\mathcal{U}_1$  be the ambient instance space of  $\mathcal{R}_1$ .

An interactive reduction  $\Pi : \mathcal{R}_1 \rightarrow \mathcal{R}_2$ , defined by PPT algorithms  $(\mathcal{G}, \mathcal{K}, \mathcal{P}, \mathcal{V})$  (Definition 9), is **weak** if it is complete, public coin, and there exists a function  $\phi : \mathcal{U}_1 \rightarrow \mathbb{C}$  (for an arbitrary space  $\mathbb{C}$ ) such that for any EPT adversary  $(\mathcal{A}, \mathcal{P}^*)$ , there exists an EPT extractor  $\mathcal{E}$  such that if the success probability of the adversary  $\epsilon(\mathcal{A}, \mathcal{P}^*) \geq 1/\text{poly}(\lambda)$ , then

$$\Pr \left[ (\text{pp}, \mathbf{s}, u_1, w_1) \in \mathcal{R}'_1 \left| \begin{array}{l} \text{pp} \leftarrow \mathcal{G}(1^\lambda, \text{sz}) \\ (\mathbf{s}, u_1, \text{st}) \leftarrow \mathcal{A}(\text{pp}) \\ (\text{pk}, \text{vk}) \leftarrow \mathcal{K}(\text{pp}, \mathbf{s}) \\ w_1 \leftarrow \mathcal{E}(\text{pp}, \mathbf{s}, u_1, \text{st}) \end{array} \right. \right] \geq \epsilon(\mathcal{A}, \mathcal{P}^*) - \text{negl}(\lambda).$$

and if  $\mathcal{A} := (\mathcal{B}, \mathcal{B}')$  such that

$$\Pr \left[ \begin{array}{c} u_1, u'_1 \neq \perp \\ \Downarrow \\ \phi(u_1) = \phi(u'_1) \end{array} \left| \begin{array}{l} \text{pp} \leftarrow \mathcal{G}(1^\lambda, \text{sz}) \\ (\mathbf{s}, \text{st}^*) \leftarrow \mathcal{B}(\text{pp}) \\ (u_1, \text{st}) \leftarrow \mathcal{B}'(\text{st}^*) \\ (u'_1, \text{st}') \leftarrow \mathcal{B}'(\text{st}^*) \end{array} \right. \right] = 1,$$

then

$$\Pr \left[ \begin{array}{c} w_1, w'_1 \neq \perp \\ \wedge w_1 \neq w'_1 \end{array} \left| \begin{array}{l} \text{pp} \leftarrow \mathcal{G}(1^\lambda, \text{sz}) \\ (\mathbf{s}, \text{st}^*) \leftarrow \mathcal{B}(\text{pp}) \\ (u_1, \text{st}) \leftarrow \mathcal{B}'(\text{st}^*) \\ w_1 \leftarrow \mathcal{E}(\text{pp}, \mathbf{s}, u_1, \text{st}) \\ (u'_1, \text{st}') \leftarrow \mathcal{B}'(\text{st}^*) \\ w'_1 \leftarrow \mathcal{E}(\text{pp}, \mathbf{s}, u'_1, \text{st}') \end{array} \right. \right] \leq \text{negl}(\lambda)$$

**Definition 17 (Strong Interactive Reductions).** Consider relations  $\mathcal{R}_1$ ,  $\mathcal{R}_2$ , and  $\mathcal{R}'_2$  over public parameters, structure, instance, and witness tuples such that  $\mathcal{R}_2 \subseteq \mathcal{R}'_2$ . Let  $\mathcal{U}_2$  be the ambient instance space of  $\mathcal{R}_2$ .

An interactive reduction  $\Pi : \mathcal{R}_1 \rightarrow \mathcal{R}_2$ , defined by PPT algorithms  $(\mathcal{G}, \mathcal{K}, \mathcal{P}, \mathcal{V})$  (Definition 9), is **strong** if it is complete, public coin, and there exists a function  $\phi : \mathcal{U}_2 \rightarrow \mathbb{C}$  (for an arbitrary space  $\mathbb{C}$ ) such that

(i) For any EPT adversary  $(\mathcal{A}, \mathcal{P}^*)$ ,

$$\Pr \left[ \begin{array}{c} u_2, u'_2 \neq \perp \\ \Downarrow \\ \phi(u_2) = \phi(u'_2) \end{array} \middle| \begin{array}{l} \mathbf{pp} \leftarrow \mathcal{G}(1^\lambda, \mathbf{sz}) \\ (\mathbf{s}, u_1, \mathbf{st}_1) \leftarrow \mathcal{A}(\mathbf{pp}) \\ (\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s}) \\ (u_2, w_2) \leftarrow \langle \mathcal{P}^*, \mathcal{V} \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st}_1) \\ (u'_2, w'_2) \leftarrow \langle \mathcal{P}^*, \mathcal{V} \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st}_1) \end{array} \right] = 1$$

(ii) For any EPT adversary  $(\mathcal{A}, \mathcal{P}^*)$ , there exists an EPT extractor  $\mathcal{E}$  such that if

$$\epsilon'(\mathcal{A}, \mathcal{P}^*) := \Pr \left[ (\mathbf{pp}, \mathbf{s}, \langle \mathcal{P}^*, \mathcal{V} \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st})) \in \mathcal{R}'_2 \middle| \begin{array}{l} \mathbf{pp} \leftarrow \mathcal{G}(1^\lambda, \mathbf{sz}) \\ (\mathbf{s}, u_1, \mathbf{st}) \leftarrow \mathcal{A}(\mathbf{pp}) \\ (\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s}) \end{array} \right]$$

$\geq 1/\text{poly}(\lambda)$ , and

$$\Pr \left[ \begin{array}{c} w_2, w'_2 \neq \perp \\ \wedge \\ w_2 \neq w'_2 \end{array} \middle| \begin{array}{l} \mathbf{pp} \leftarrow \mathcal{G}(1^\lambda, \mathbf{sz}) \\ (\mathbf{s}, u_1, \mathbf{st}) \leftarrow \mathcal{A}(\mathbf{pp}) \\ (\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s}) \\ (u_2, w_2) \leftarrow \langle \mathcal{P}^*, \mathcal{V} \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st}) \\ (u'_2, w'_2) \leftarrow \langle \mathcal{P}^*, \mathcal{V} \rangle((\mathbf{pk}, \mathbf{vk}), u_1, \mathbf{st}) \end{array} \right] \leq \text{negl}(\lambda)$$

then we have that

$$\Pr \left[ (\mathbf{pp}, \mathbf{s}, u_1, w_1) \in \mathcal{R}_1 \middle| \begin{array}{l} \mathbf{pp} \leftarrow \mathcal{G}(1^\lambda, \mathbf{sz}) \\ (\mathbf{s}, u_1, \mathbf{st}) \leftarrow \mathcal{A}(\mathbf{pp}) \\ (\mathbf{pk}, \mathbf{vk}) \leftarrow \mathcal{K}(\mathbf{pp}, \mathbf{s}) \\ w_1 \leftarrow \mathcal{E}(\mathbf{pp}, \mathbf{s}, u_1, \mathbf{st}) \end{array} \right] \geq \epsilon'(\mathcal{A}, \mathcal{P}^*) - \text{negl}(\lambda).$$

**Theorem 12 (Strong-Weak Composition).** Consider relations  $\mathcal{R}_1, \mathcal{R}_2, \mathcal{R}'_2$  and  $\mathcal{R}_3$  over public parameters, structure, instance, and witness tuples such that  $\mathcal{R}_2 \subseteq \mathcal{R}'_2$ . Let  $\mathcal{U}_2$  be the ambient instance space of  $\mathcal{R}_2$ . Consider interactive reductions (Definition 9)  $\Pi_1 : \mathcal{R}_1 \rightarrow \mathcal{R}_2$  ( $\mathcal{R}'_2$ ),  $\Pi_2 : \mathcal{R}_2$  ( $\mathcal{R}'_2$ )  $\rightarrow \mathcal{R}_3$  such that

- (i)  $\Pi_1$  is **strong** (Definition 17) with respect to a function  $\phi : \mathcal{U}_2 \rightarrow \mathbb{C}$  and
- (ii)  $\Pi_2$  is **weak** (Definition 16) with respect to the **same** function  $\phi$ ,

then the sequential composition  $\Pi_2 \circ \Pi_1 : \mathcal{R}_1 \rightarrow \mathcal{R}_3$  is a **reduction of knowledge**.

*Proof.* For brevity, we defer the proof to Appendix B.1. □
