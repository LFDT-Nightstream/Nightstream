# Supplementary Material

## A.1 Local P1 correction register

This repository copy is an independently corrected derivative of SuperNeo v1.1, not an author-issued revision. It preserves the v1.1 protocol architecture and changes only four P1 items:

| Area | Local correction |
|---|---|
| Coordinate extraction | Theorem 7 uses loss  $\ell/|\mathcal{C}|$ , where  $\mathcal{C}$  is the one-coordinate challenge set. |
| RLC proof | Appendix B.3 keeps native witnesses in  $\mathbb{L}^{n_L}$  separate from packed commitment openings in  $R_{\mathbb{F}}^{n_R}$ . |
| Concrete security | Section 8 separates reported Module-SIS work factors from the composed knowledge-error bound. |
| Post-quantum scope | The source states that its extractors and rewinding arguments are classical and do not prove quantum-prover extraction or QROM Fiat--Shamir security. |

The pinned original is `docs/superneo-paper-v1_1.zip`. The repository script `docs/generate-superneo-v1_1-errata-patch.sh` generates the single cumulative `superneo-paper-errata.patch` in this folder and verifies that it reproduces this working copy exactly.

## A.2 Original AI Disclaimer

Portions of this manuscript were edited with the assistance of an AI writing tool (Github copilot), which was used to improve grammar, wording, and formatting consistency. All technical content—including definitions, theorems, and proofs—was produced and verified by the authors, who take full responsibility for the correctness and originality of the work.
