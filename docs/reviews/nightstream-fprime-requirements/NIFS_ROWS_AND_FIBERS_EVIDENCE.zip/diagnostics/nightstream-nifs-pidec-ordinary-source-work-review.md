# Independent PiDEC commitment-row source review

Reviewer: Worker 3, `/root/conformance_review`.
Reviewed frozen source:
`/home/nicoarq/develop/Nightstream-nifs-proof-links/formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PiDECOrdinarySourceWork.lean`.
It has 354 lines, 17,949 bytes, and SHA-256
`00f449536847cbf0fcebc445ff09d6efd45fe7e5260607177bc2453f0df94e83`.

Result: **no defect found in the corrected value and named-work claims;
ready for the third full check**. This is source review before that check,
not a validation result. No source edit, build, test, generator, or backend
command was performed. This next source is outside the earlier
`4049d613…` five-file matrix/preimage milestone.

The executed input is one coordinate in `Fin 1188`. The program constructs
16 child terms directly, in child order zero through fifteen. Each child
column is derived from its selected remapped start and the coordinate.
The weight program computes its own natural power of two and reduces it to
Goldilocks. It receives no weight table or semantic source callback.
The recursion advances a natural index; it builds no reindexed accessor chain.

The returned A linear combination has constant zero and those 16 terms.
B has constant one and no terms. C has constant zero and one parent term
with coefficient one. Thus the lengths are A=16, B=0, C=1; B is not a zero
linear combination. The complete row represents the same binary-weight
commitment recomposition for every one of the 1,188 coordinates.

The semantic chain starts at the existing PiDEC commitment constraints,
uses their exact affine recipe lowering, and applies the existing Spartan
column map. The start constants in `parentColumn` and `childColumn` are proved
equal to that map, not supplied as new authority. `commitmentRow_value`
targets `PiDECOrdinaryDirectSource.commitmentProgramRow PiDECInputCheck.relation`.
The full list/constraint expressions appear in proofs only; the executed
row constructor calls neither the full packet nor its list accessor.
The final `dite_true` change is confined to the lowering proof.

The current operation convention counts value construction, dispatch and
predecessor extraction, calls, value reads, and arithmetic. Passing an
existing local argument has no separate read charge. Clock arithmetic and
clock-field reads are instrumentation and are excluded. The corrected
source makes the following counts explicit:

| Program | Named operations outside child clocks |
|---|---:|
| parentColumn | constant, Fin-value read, addition, Result: 4 |
| childColumn | two literals, Fin-value read, multiplication, two additions, Result: 7 |
| powerTwo base | dispatch, literal one, Result: 3 |
| powerTwo step | dispatch, predecessor, call, value read, literal two, multiplication, Result: 7 |
| weight | power call/read, modulus literal, reduction, F constructor, Result: 6 |
| childTerm | two calls, two value reads, pair, Result: 6 |
| childTerms base | dispatch, nil, Result: 3 |
| childTerms step | dispatch/predecessor, two calls, index literal/addition, two value reads, cons, Result: 10 |
| final row wrapper | two Nat literals, two calls, two value reads, four F literals, two nils, pair/cons, three affine records, Row, Result: 19 |

The child remains a natural argument in `childColumn`; removing the old
extra argument-read charge is consistent with that convention. The final
row constructs all three linear combinations directly, so there is no
uncharged `LinearCombination.one` or `ofVar` helper call in execution.

`powerTwo_work` is `7*k+3`. For the selected child indices, `k<16`, so the
power costs at most 108 and weight at most 114. A child term costs at most
`7+114+6=127`; each list step therefore costs at most 137. The complete row
bound is `16*137+3+4+19=2218`. The private index premise is discharged by the
actual sixteen-child loop, not added to the public row theorem.

No further count or value defect was found in these frozen bytes. The
proposed bound is not a measured runtime, compiled-instruction, allocator,
bit-complexity or gas theorem. The review does not prove the third build,
an axiom audit, complete selected row dispatch/substitution, or the final
selected matrix-entry integration. Those records remain separate.
