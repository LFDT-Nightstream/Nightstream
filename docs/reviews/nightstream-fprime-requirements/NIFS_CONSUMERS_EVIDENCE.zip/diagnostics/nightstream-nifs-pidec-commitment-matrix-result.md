PiDEC commitment matrix compiler: full criterion passed on round 3.

The active owner is `formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PiDECCommitmentMatrixWork.lean` in `/home/nicoarq/develop/Nightstream-nifs-proof-links`. It has 546 lines and 31,057 bytes. SHA256: `daacaf6cccad805757b70ead43c866de82774f0cba5f302fce1c06f44ece638f`.

The required source-data export is in `formal/nightstream-fprime/NightstreamFPrime/Export/Stage1/PiDECOrdinarySourceWork.lean`: 367 lines, 18,711 bytes, SHA256 `be961c483a67eae357001cf117461b9e30c613d981e37490ded262fb4db5e2fb`. Its runtime and prior value/length/work theorems are unchanged. The sole addition is `commitmentRow_data`, which exposes the full ordered row using public source-column and radix-weight definitions.

Paper authority: corrected SuperNeo v1.1 [Section 7.5, verifier step 2](/home/nicoarq/develop/Nightstream/docs/superneo-paper-v1_1/07_superneo_folding_scheme_for_ccs.md) and [Appendix B.4, equations 46–47](/home/nicoarq/develop/Nightstream/docs/superneo-paper-v1_1/11_appendix_B_deferred_theorems_and_proofs.md). These specify commitment recomposition. The unchanged Nightstream profile uses Goldilocks, b = 2, k_rho = 16, B = 65536 and 16 children; it does not use the paper's reference k_rho = 14 parameters.

The checked exports are:

- `PiDECOrdinarySourceWork.commitmentRow_data`.
- `PiDECCommitmentMatrixWork.commitmentForms_value`.
- `PiDECCommitmentMatrixWork.commitmentForms_lengths`.
- `PiDECCommitmentMatrixWork.commitmentForms_work_le`.

`commitmentForms : Fin 1188 → Result (OrdinaryRow.Forms PiDECInputCheck.logicalWidth)` calls the actual counted source row once. It constructs the two retained blocks once, with fields proved equal to the selected owners: parent commitment `(field, 1188, 188579034)` and proof `(field, 49248, 195244650)`. It executes with the proved width literal 254260583; the final equality cast changes only an erased type index.

The program traverses the returned A/B/C term lists. It preserves coefficients, duplicate columns, zero constants and order. Its exact value is `PiDECMatrixProgram.commitmentDirectForms PiDECInputCheck.relation (PerApplicationMatrixProgram.piDecGeometry Poseidon2HashChainV1Package.application) index`. Exact entry lengths are selector 1, A 657, B 1 and C 42. The source row has A 16 terms, B constant one with no terms, and C one parent term. Each retained field slot contributes 41 entries.

The source-data theorem proves that every generated term lies in one of the two supported source ranges. `substitution_location_form?` and `substitution_agrees_on_target` connect their forms to the exact seven-range selected substitution, including uniqueness. Successful retained lookups are proved for every generated coordinate. The private empty-result branch does not add a new accepted input case: the public input is a typed generated row, and its lookups return the proved forms.

The existing `piDecCommitmentPackageSourceRow?_eq_some`, `PerApplicationSourceProjection.base_row` and `PiDECMatrixProgram.commitmentBlock_row?` provide the package/source-projection bridge. The new value theorem reaches that bridge's exact direct-form result. No package-wide row search or function-valued source callback executes inside this program.

The complete named-operation bound is derived as follows:

| Executed component | Bound |
|---|---:|
| One retained field form | 7 × 41² + 49 × 41 + 25 = 13801 |
| Unpack a stored optional result | retained work + 9 |
| Select source block and slot, call/read/return | +9, hence sourceForm ≤ 13819 |
| Scale 41 entries | 14 × 41 + 13 = 587 |
| Append a 41-entry head | 10 × 41 + 13 = 423 |
| One term step | 13819 + 587 + 423 + 14 = 14843 |
| Empty term list | empty 3 + wrapper 5 = 8 |
| One affine combination with n terms | 14843n + 8 + singleton 5 + append 23 + wrapper 9 = 14843n + 45 |
| Complete four-form row | 14843 × (16 + 0 + 1) + 3 × 45 + selector 5 + wrapper 14 = 252485 |
| Source generation | 2218 |
| Two retained block records | 10 |
| Run wrapper | 12 |
| Width literal/call/value/Result wrapper | 4 |
| Complete commitmentForms call | 252485 + 2218 + 10 + 12 + 4 = 254729 |

The unpack bound includes its counted None branch; it is a conservative bound over the executed implementation. Calls, data reads, scalar literals/arithmetic, dispatch and constructors are counted. Callee work is added separately. Clock instrumentation and erased proofs are excluded. This is not a machine-instruction, allocation-byte, bit-complexity or wall-time theorem.

Root ran the same complete module target in all three rounds, through the normal 1500-second validation wrapper. No limits were raised and no narrower check replaced the criterion.

| Round | Result | Source hash | Log |
|---|---|---|---|
| 1 | Exit 1; matrix module 29s. The source-data dependency passed in 1.9s. Parent-column/support reduction, lookup-length kernel conversion, unreduced work lets, and selected casts failed. | `9ab47fbec8610116e6050c5d9db1b99f1146a203fa7f0d067516e367934ea962` | `/tmp/nightstream-nifs-pidec-commitment-matrix-work-1.log` |
| 2 | Exit 1; module 45s. Only sourceForm_length_le had kernel deep recursion. | `493b61ec5d31084299e5a2be2b3d433a59238b7c9194e6c62dc8412cc14fb5f4` | `/tmp/nightstream-nifs-pidec-commitment-matrix-work-2.log` |
| 3 | Exit 0; module 17s, wrapper 18s. Full criterion passed. | `daacaf6cccad805757b70ead43c866de82774f0cba5f302fce1c06f44ece638f` | `/tmp/nightstream-nifs-pidec-commitment-matrix-work-3.log` |

The repairs changed proofs, explicit type arguments and local transparency only. The final length proof handles the conditional over symbolic stored results before substituting actual lookups and source-index subtractions. The exact kernel cause was not independently isolated; no claim is made that Nat.sub alone caused the earlier failure.

Remaining boundary: this closes one 1188-row ordinary block. It does not yet provide the complete selected row dispatcher, all other row generators, or the full matrixEntry primitive. CoefficientWork already counts expansion of a supplied sparse form, but its caller must still supply complete selected row generation and list-length bounds. The selected witness checker remains unchanged with commitmentCheck and matrixEntry contracts. Root owns audit registration and the combined milestone. Active source is frozen; no worker builds, archive edits or commits were made.
