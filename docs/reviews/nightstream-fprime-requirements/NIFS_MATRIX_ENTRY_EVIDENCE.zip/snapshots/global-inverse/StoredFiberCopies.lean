import NightstreamFPrime.Spec.Folding.PiRLC.PaperForkExtractionWork
import Init.Data.Vector.OfFn

/-!
Counted stored-vector/list conversions used by inverse preparation, ranking,
and output construction. Array reads and all possible prefix copies are
charged. Semantic function views occur only in the value theorems.
-/

namespace NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredFiberCopies

open _root_.NightstreamFPrime.Spec.Folding.PiRLC.PaperForkExtractionWork (Result)

private def copyFrom (values : Array α) (start : Nat) :
    (count : Nat) → start + count ≤ values.size → Result (List α)
  | 0, _ => ⟨[], 3⟩
  | count + 1, within =>
      let value := values[start]'(by omega)
      let tail := copyFrom values (start + 1) count (by omega)
      ⟨value :: tail.value, tail.work + 9⟩

private theorem copyFrom_value (values : Array α) (start count : Nat)
    (within : start + count ≤ values.size) :
    (copyFrom values start count within).value = (values.toList.drop start).take count := by
  induction count generalizing start with
  | zero => simp only [copyFrom, List.take_zero]
  | succ count ih =>
      have inside : start < values.toList.length := by rw [Array.length_toList]; omega
      rw [List.drop_eq_getElem_cons inside]
      simp only [copyFrom, ih, List.take_succ_cons, Array.getElem_toList]

private theorem copyFrom_work (values : Array α) (start count : Nat)
    (within : start + count ≤ values.size) :
    (copyFrom values start count within).work = 9 * count + 3 := by
  induction count generalizing start with
  | zero => rfl
  | succ count ih => simp only [copyFrom, ih]; omega

attribute [irreducible] copyFrom

/-- Copy each stored entry once in its original order. -/
def toList (values : Vector α count) : Result (List α) :=
  let copied := copyFrom values.toArray 0 count (by simp only [Nat.zero_add, Vector.size_toArray])
  ⟨copied.value, copied.work + 5⟩

theorem toList_value (values : Vector α count) : (toList values).value = values.toList := by
  change (copyFrom values.toArray 0 count _).value = _
  rw [copyFrom_value]
  simp only [List.drop_zero, Vector.toList_toArray]
  exact List.take_of_length_le (by simp only [Vector.length_toList])

theorem toList_work (values : Vector α count) : (toList values).work = 9 * count + 8 := by
  change (copyFrom values.toArray 0 count _).work + 5 = _
  rw [copyFrom_work]
  omega

private def appendList (capacity : Nat) (buffer : Array α) : List α → Result (Array α)
  | [] => ⟨buffer, 2⟩
  | value :: rest =>
      let next := buffer.push value
      let result := appendList capacity next rest
      ⟨result.value, result.work + capacity + 2 * buffer.size + 9⟩

private theorem appendList_value (capacity : Nat) (buffer : Array α) (values : List α) :
    (appendList capacity buffer values).value.toList = buffer.toList ++ values := by
  induction values generalizing buffer with
  | nil => simp only [appendList, List.append_nil]
  | cons value rest ih =>
      simp only [appendList, ih, Array.toList_push, List.append_assoc, List.singleton_append]

private theorem appendList_work (capacity : Nat) (buffer : Array α) (values : List α)
    (within : buffer.size + values.length ≤ capacity) :
    (appendList capacity buffer values).work ≤ 2 + values.length * (3 * capacity + 9) := by
  induction values generalizing buffer with
  | nil => simp only [appendList, List.length_nil, Nat.zero_mul, Nat.add_zero, Nat.le_refl]
  | cons value rest ih =>
      have nextWithin : (buffer.push value).size + rest.length ≤ capacity := by
        simp only [Array.size_push]
        simp only [List.length_cons] at within
        omega
      have bounded := ih (buffer.push value) nextWithin
      change (appendList capacity (buffer.push value) rest).work + capacity +
        2 * buffer.size + 9 ≤ _
      simp only [List.length_cons] at within ⊢
      nlinarith

attribute [irreducible] appendList

/-- One reserved allocation, followed by counted pushes. The push allowance
is capacity + 2*oldSize + 3; the other six step operations are list dispatch,
head/tail reads, the recursive call, value projection, and Result.
The public caller charges the supplied capacity argument. -/
def ofList (values : List α) (length : values.length = count) : Result (Vector α count) :=
  let buffer : Array α := Array.emptyWithCapacity count
  let result := appendList count buffer values
  ⟨⟨result.value, by
    rw [Array.size_eq_length_toList, appendList_value]
    change values.length = count
    exact length⟩,
    result.work + count + 5⟩

theorem ofList_value (values : List α) (length : values.length = count) :
    (ofList values length).value.toList = values := by
  change (appendList count (Array.emptyWithCapacity count) values).value.toList = _
  rw [appendList_value]
  rfl

theorem ofList_work_le (values : List α) (length : values.length = count) :
    (ofList values length).work ≤ 3 * count ^ 2 + 10 * count + 7 := by
  have bounded := appendList_work count (Array.emptyWithCapacity count) values (by
    change 0 + values.length ≤ count
    omega)
  change (appendList count (Array.emptyWithCapacity count) values).work + count + 5 ≤ _
  rw [length] at bounded
  nlinarith

end NightstreamFPrime.Spec.Folding.Nifs.NonInteractive.PiRlcSampler.StoredFiberCopies
