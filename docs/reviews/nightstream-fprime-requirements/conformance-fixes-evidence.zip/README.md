# Conformance fix evidence

These are this task's local command records, including failures. They do not
come from an approved checker and do not grant independent review approval.
The 91 candidate checks use the exact pre-pin patch and new files recorded in
reviewed-source.json. Later commands use the stored package and corrected pins;
see executions.json and the repository's CONFORMANCE_FIXES.md.

manifest.json identifies the final code commit, every included original record,
and the selected input bytes. Full opening carriers, third-party libraries, build products and derived
dependency-graph data are not duplicated here. Their original records and
input identities remain available in the external evidence store. The original inputs remain in the
external evidence store. Input identities describe bytes, not proof authority.
The selected serialized phase inputs and results are included. Fixture-generation
commands and the final source patch are included for reproduction.
